﻿using System;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a record of cash denomination details for a specific date.
    /// Used to track the quantity of each currency note in the register on a given day.
    /// </summary>
    public class CashDenominationDetail
    {
        /// <summary>
        /// Primary key identifier for the record.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The date associated with this cash record.
        /// Uniquely identifies the day of this cash denomination snapshot.
        /// </summary>
        public DateTime Date { get; set; }

        // The following properties represent the quantity of each Australian currency note denomination:

        /// <summary>
        /// Number of $100 notes.
        /// </summary>
        public int Note100 { get; set; }

        /// <summary>
        /// Number of $50 notes.
        /// </summary>
        public int Note50 { get; set; }

        /// <summary>
        /// Number of $20 notes.
        /// </summary>
        public int Note20 { get; set; }

        /// <summary>
        /// Number of $10 notes.
        /// </summary>
        public int Note10 { get; set; }

        /// <summary>
        /// Number of $5 notes.
        /// </summary>
        public int Note5 { get; set; }

        /// <summary>
        /// Number of $2 coins (or notes, depending on usage).
        /// </summary>
        public int Note2 { get; set; }

        /// <summary>
        /// Number of $1 coins (or notes, depending on usage).
        /// </summary>
        public int Note1 { get; set; }
    }
}

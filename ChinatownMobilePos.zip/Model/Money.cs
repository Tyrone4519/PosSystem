﻿using System;
using System.ComponentModel.DataAnnotations;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a record of counted physical cash by denomination on a specific date.
    /// Useful for cash drawer reconciliation, end-of-day cashing up, or reporting purposes.
    /// </summary>
    public class Money
    {
        /// <summary>
        /// Primary key identifier for the money record.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The date this cash count was recorded.
        /// Required to ensure proper tracking of daily cash.
        /// </summary>
        [Required]
        public DateTime Date { get; set; }

        // --- Count of each denomination (likely in Australian dollars) ---

        /// <summary>
        /// Count of $1 coins or notes.
        /// </summary>
        public int Count_1 { get; set; }

        /// <summary>
        /// Count of $2 coins.
        /// </summary>
        public int Count_2 { get; set; }

        /// <summary>
        /// Count of $5 notes.
        /// </summary>
        public int Count_5 { get; set; }

        /// <summary>
        /// Count of $10 notes.
        /// </summary>
        public int Count_10 { get; set; }

        /// <summary>
        /// Count of $20 notes.
        /// </summary>
        public int Count_20 { get; set; }

        /// <summary>
        /// Count of $50 notes.
        /// </summary>
        public int Count_50 { get; set; }

        /// <summary>
        /// Count of $100 notes.
        /// </summary>
        public int Count_100 { get; set; }

        /// <summary>
        /// Calculates the total cash amount based on denomination counts.
        /// Computed as: (1×Count_1 + 2×Count_2 + 5×Count_5 + ... + 100×Count_100)
        /// </summary>
        public double TotalAmount =>
            Count_1 * 1 + Count_2 * 2 + Count_5 * 5 +
            Count_10 * 10 + Count_20 * 20 +
            Count_50 * 50 + Count_100 * 100;

        /// <summary>
        /// Indicates whether high denomination notes (e.g., $50, $100) have already been removed/deducted.
        /// Used to track if cash float adjustment or banking has occurred.
        /// </summary>
        public bool DeductedHighNotes { get; set; } = false;

        /// <summary>
        /// Name of the staff member who performed the cash count.
        /// Optional for accountability or tracking.
        /// </summary>
        public string? StaffName { get; set; }
    }
}

﻿namespace ChinatownMobilePos.Model
{
    /// <summary>
    /// Represents a daily task assigned to a staff member.
    /// Typically used for tracking work progress, notes, and status throughout the day.
    /// </summary>
    public class DailyTask
    {
        /// <summary>
        /// Primary key identifier for the task.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name of the staff member responsible for this task.
        /// </summary>
        public string StaffName { get; set; }

        /// <summary>
        /// Description or notes related to the task.
        /// Could include instructions, context, or follow-up requirements.
        /// </summary>
        public string Note { get; set; }

        /// <summary>
        /// Current status of the task (e.g., "Pending", "Completed", "In Progress").
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// The date the task is assigned or scheduled to be performed.
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Optional date indicating when the task was transferred (e.g., delegated or rescheduled).
        /// </summary>
        public DateTime? TransferDate { get; set; }

        /// <summary>
        /// Timestamp for when the task record was created in the system.
        /// Used for auditing and chronological sorting.
        /// </summary>
        public DateTime CreatedAt { get; set; }
    }
}

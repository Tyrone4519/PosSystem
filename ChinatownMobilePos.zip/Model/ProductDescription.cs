﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a specific description or variant of a product.
    /// Commonly used to store attributes like size, color, model compatibility, or other identifiers.
    /// </summary>
    public class ProductDescription
    {
        /// <summary>
        /// Primary key identifier for the product description entry.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Foreign key linking this description to a specific product.
        /// </summary>
        [Required]
        public int ProductId { get; set; }

        /// <summary>
        /// Description text providing detail about the variant or attribute.
        /// For example: "Black - iPhone 14", "Large Size", or "USB-C".
        /// </summary>
        [Required]
        public string DescriptionText { get; set; }

        /// <summary>
        /// Navigation property linking to the related Product entity.
        /// Enables access to parent product details.
        /// </summary>
        [ForeignKey("ProductId")]
        public virtual Product Product { get; set; }
    }
}

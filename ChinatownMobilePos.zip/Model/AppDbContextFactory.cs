﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using ChinatownMobilePos.Data;

namespace ChinatownMobilePos.Helpers
{
    /// <summary>
    /// Provides a static method to create an instance of AppDbContext with predefined options.
    /// Typically used in environments where dependency injection is not available, such as WPF, Xamarin, or manual instantiation.
    /// </summary>
    public static class AppDbContextFactory
    {
        /// <summary>
        /// MySQL connection string pointing to the database server.
        /// Uses the root user with no password, following XAMPP default setup.
        /// </summary>
        private static readonly string _connectionString = "server=192.168.0.151;port=3306;database=chinatownpos;user=root;password=;";
        // Alternative localhost connection (commented for switching if needed)
        // private static readonly string _connectionString = "server=localhost;port=3306;database=chinatownpos;user=root;password=;";

        /// <summary>
        /// Creates and returns a new AppDbContext instance with the configured MySQL connection.
        /// </summary>
        public static AppDbContext CreateDbContext()
        {
            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseMySql(_connectionString, ServerVersion.AutoDetect(_connectionString));

            return new AppDbContext(optionsBuilder.Options);
        }
    }

    /// <summary>
    /// Provides design-time support for Entity Framework Core tools such as migrations and scaffolding.
    /// EF Core CLI (e.g., `dotnet ef migrations add`) requires this class to instantiate the DbContext during design time.
    /// </summary>
    public class DesignTimeDbContextFactory : IDesignTimeDbContextFactory<AppDbContext>
    {
        /// <summary>
        /// Creates and returns a new AppDbContext instance used by EF Core at design time.
        /// This method is automatically called by `dotnet ef` tooling.
        /// </summary>
        /// <param name="args">Command-line arguments passed by the EF Core CLI.</param>
        /// <returns>An AppDbContext configured with the same MySQL connection as the runtime context.</returns>
        public AppDbContext CreateDbContext(string[] args)
        {
            var connectionString = "server=192.168.0.151;port=3306;database=chinatownpos;user=root;password=;";
            // Alternative localhost connection (commented)
            // var connectionString = "server=localhost;port=3306;database=chinatownpos;user=root;password=;";

            var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();
            optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));

            return new AppDbContext(optionsBuilder.Options);
        }
    }
}

﻿using ChinatownMobilePos.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents an invoice document issued to a customer.
    /// Includes customer details, transaction totals, and a list of individual invoice items.
    /// </summary>
    public class Invoice
    {
        /// <summary>
        /// Primary key for the invoice.
        /// Typically a unique alphanumeric invoice number (e.g., "INV-10001").
        /// Limited to 30 characters.
        /// </summary>
        [Key]
        [MaxLength(30)]
        public string InvoiceNo { get; set; }

        /// <summary>
        /// Name of the customer the invoice is issued to.
        /// </summary>
        [MaxLength(100)]
        public string CustomerName { get; set; }

        /// <summary>
        /// Date when the invoice was created.
        /// Automatically set to current time upon initialization.
        /// </summary>
        public DateTime Date { get; set; } = DateTime.Now;

        /// <summary>
        /// Customer's billing or shipping address.
        /// </summary>
        public string Address { get; set; }

        /// <summary>
        /// Customer's contact phone number.
        /// </summary>
        public string Phone { get; set; }

        /// <summary>
        /// Customer's email address.
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Total before tax (subtotal of all invoice items).
        /// </summary>
        public decimal Subtotal { get; set; }

        /// <summary>
        /// Total amount of GST (Goods and Services Tax) applied to all items.
        /// </summary>
        public decimal GSTTotal { get; set; }

        /// <summary>
        /// Final total amount, including GST.
        /// GrandTotal = Subtotal + GSTTotal
        /// </summary>
        public decimal GrandTotal { get; set; }

        /// <summary>
        /// List of individual line items associated with this invoice.
        /// </summary>
        public List<InvoiceItem> Items { get; set; } = new();
    }
}

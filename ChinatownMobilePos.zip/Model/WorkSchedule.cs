﻿using System;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a scheduled work shift for a staff member on a specific date.
    /// Includes time tracking, wage calculation, and payment status.
    /// </summary>
    public class WorkSchedule
    {
        /// <summary>
        /// Primary key identifier for the work schedule record.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name of the staff member assigned to this shift.
        /// Should match entries in the Staff table.
        /// </summary>
        public string StaffName { get; set; }

        /// <summary>
        /// Date of the scheduled work shift.
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Time the shift starts (e.g., 09:00).
        /// </summary>
        public TimeSpan StartTime { get; set; }

        /// <summary>
        /// Time the shift ends (e.g., 17:30).
        /// </summary>
        public TimeSpan EndTime { get; set; }

        /// <summary>
        /// Total working hours for the shift.
        /// Usually calculated as (EndTime - StartTime) in decimal hours.
        /// </summary>
        public decimal WorkHours { get; set; }

        /// <summary>
        /// Hourly wage rate for the staff member at the time of this shift.
        /// </summary>
        public decimal HourlyRate { get; set; }

        /// <summary>
        /// Total wage for this workday.
        /// Computed as WorkHours × HourlyRate.
        /// </summary>
        public decimal WageAmount { get; set; }

        /// <summary>
        /// Indicates whether the wage for this shift has been paid to the staff member.
        /// </summary>
        public bool IsPaid { get; set; }

        /// <summary>
        /// Optional notes or comments related to the shift (e.g., overtime, changes, remarks).
        /// </summary>
        public string? Note { get; set; }
    }
}

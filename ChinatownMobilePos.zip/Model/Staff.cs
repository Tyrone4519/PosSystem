﻿using System;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents an employee or user account in the system.
    /// Includes login credentials, work schedule, role, pay rate, and status tracking.
    /// </summary>
    public class Staff
    {
        /// <summary>
        /// Primary key identifier for the staff member.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Full name of the staff member for display purposes.
        /// </summary>
        public string StaffName { get; set; }

        /// <summary>
        /// Username used for logging into the system.
        /// </summary>
        public string Username { get; set; }

        /// <summary>
        /// Hashed password string for authentication (e.g., SHA256 or similar).
        /// </summary>
        public string PasswordHash { get; set; }

        /// <summary>
        /// Role assigned to the staff member, determining permissions.
        /// Common values: "Manager", "Staff", "Viewer".
        /// </summary>
        public string Role { get; set; }

        /// <summary>
        /// Date the staff record was created or last updated (typically used as join date).
        /// </summary>
        public DateTime UpdateTime { get; set; }

        /// <summary>
        /// Optional date of resignation, if the staff has left the company.
        /// </summary>
        public DateTime? ResignDate { get; set; }

        /// <summary>
        /// Optional daily start time of the staff's working hours.
        /// </summary>
        public TimeSpan? WorkTimeStart { get; set; }

        /// <summary>
        /// Optional daily end time of the staff's working hours.
        /// </summary>
        public TimeSpan? WorkTimeEnd { get; set; }

        /// <summary>
        /// Optional hourly wage assigned to the staff member.
        /// Useful for payroll or shift cost calculation.
        /// </summary>
        public decimal? HourlyRate { get; set; }

        /// <summary>
        /// Indicates whether the staff account is active and allowed to log in.
        /// </summary>
        public bool IsActive { get; set; }

        /// <summary>
        /// Optional notes or remarks related to the staff member.
        /// </summary>
        public string Note { get; set; }
    }
}

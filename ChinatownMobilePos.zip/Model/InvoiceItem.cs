﻿// File: Models/InvoiceItem.cs

using System.ComponentModel.DataAnnotations;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a single line item on an invoice.
    /// Includes product description, quantity, pricing, and tax (GST).
    /// </summary>
    public class InvoiceItem
    {
        /// <summary>
        /// Primary key identifier for the invoice item.
        /// </summary>
        [Key]
        public int Id { get; set; }

        /// <summary>
        /// Reference to the associated invoice number.
        /// Typically corresponds to an external Invoice record.
        /// </summary>
        public string InvoiceNo { get; set; }

        /// <summary>
        /// Description of the item being sold (e.g., product name or service).
        /// Limited to 100 characters.
        /// </summary>
        [MaxLength(100)]
        public string Description { get; set; }

        /// <summary>
        /// Quantity of the item sold.
        /// </summary>
        public int Quantity { get; set; }

        /// <summary>
        /// Price per unit of the item, excluding GST.
        /// </summary>
        public decimal UnitPrice { get; set; }

        /// <summary>
        /// GST (Goods and Services Tax) amount applied to this item.
        /// </summary>
        public decimal GST { get; set; }

        /// <summary>
        /// Computed total for this invoice item, including GST.
        /// Calculated as (Quantity × UnitPrice) + GST.
        /// </summary>
        public decimal Total => Quantity * UnitPrice + GST;
    }
}

﻿namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a supplier or vendor who provides goods such as devices, accessories, or SIM cards.
    /// Used for tracking inventory sources and purchase history.
    /// </summary>
    public class Supplier
    {
        /// <summary>
        /// Primary key identifier for the supplier.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name of the supplier company or individual.
        /// </summary>
        public string Name { get; set; }
    }
}

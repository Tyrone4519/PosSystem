﻿namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a device entry, typically referring to a mobile phone or related hardware.
    /// Used to store device names that may be associated with contracts or inventory.
    /// </summary>
    public class Device
    {
        /// <summary>
        /// Primary key identifier for the device.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name or model of the device (e.g., "iPhone 14", "Samsung Galaxy S23").
        /// </summary>
        public string Name { get; set; }
    }
}

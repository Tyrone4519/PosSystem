﻿using System.ComponentModel.DataAnnotations;
using System.Collections.Generic;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a product category or classification type.
    /// Each type groups related products under a common sale context (e.g., Accessories, Devices, SIM Cards).
    /// </summary>
    public class ProductType
    {
        /// <summary>
        /// Primary key identifier for the product type.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Name of the product type (e.g., "Accessory", "Prepaid SIM", "Phone").
        /// Required and limited to 100 characters.
        /// </summary>
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        /// <summary>
        /// Defines the sale category this type belongs to.
        /// For example: "Retail", "Repair", "Recharge".
        /// This allows filtering or grouping by business logic.
        /// </summary>
        [Required]
        [MaxLength(50)]
        public string SaleType { get; set; }

        /// <summary>
        /// Navigation property representing the list of products under this product type.
        /// </summary>
        public ICollection<Product> Products { get; set; }
    }
}

﻿/// <summary>
/// Represents an individual item in stock, such as a device or SIM card.
/// Includes inventory tracking information, supplier details, and pricing breakdown.
/// </summary>
public class StockItem
{
    /// <summary>
    /// Primary key identifier for the stock item.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Name of the staff member who registered or entered the item into inventory.
    /// </summary>
    public string? StaffName { get; set; }

    /// <summary>
    /// Date the item was received into stock.
    /// </summary>
    public DateTime? DateIn { get; set; }

    /// <summary>
    /// Name of the supplier from whom the item was purchased.
    /// </summary>
    public string? Supplier { get; set; }

    /// <summary>
    /// Name or model of the device (e.g., "iPhone 13", "Galaxy S22").
    /// </summary>
    public string? DeviceName { get; set; }

    /// <summary>
    /// IMEI (International Mobile Equipment Identity) number — unique identifier for mobile devices.
    /// </summary>
    public string? IMEI { get; set; }

    /// <summary>
    /// SIM card number or Serial Number (SN) for accessories or other devices.
    /// </summary>
    public string? SimOrSerialNumber { get; set; }

    /// <summary>
    /// Contract-related status of the item.
    /// Example values: "Contracted", "Available".
    /// </summary>
    public string? ContractStatus { get; set; }

    /// <summary>
    /// Outright sale status of the item.
    /// Example values: "In Stock", "Sold".
    /// </summary>
    public string? OutrightStatus { get; set; }

    /// <summary>
    /// Additional notes or comments related to the item.
    /// Useful for recording damage, transfer, or special conditions.
    /// </summary>
    public string? Notes { get; set; }

    // --- Pricing Section ---

    /// <summary>
    /// Purchase cost of the item (excluding GST).
    /// </summary>
    public decimal? PurchasePrice { get; set; }

    /// <summary>
    /// Goods and Services Tax (GST) amount, typically calculated as PurchasePrice / 11.
    /// </summary>
    public decimal? GST { get; set; }

    /// <summary>
    /// Original base price before GST, typically calculated as PurchasePrice - GST.
    /// </summary>
    public decimal? OriginalPrice { get; set; }
}

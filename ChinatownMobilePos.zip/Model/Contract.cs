﻿using System;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a mobile contract record, typically for postpaid or device plans.
    /// Contains customer, plan, and device-related information tied to a single agreement.
    /// </summary>
    public class Contract
    {
        /// <summary>
        /// Primary key identifier for the contract.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The date the contract was signed or activated.
        /// Nullable in case of draft or pending entries.
        /// </summary>
        public DateTime? ContractDate { get; set; }

        /// <summary>
        /// Name of the staff member who processed the contract.
        /// </summary>
        public string? StaffName { get; set; }

        /// <summary>
        /// Name of the customer who signed the contract.
        /// </summary>
        public string? CustomerName { get; set; }

        /// <summary>
        /// Customer's mobile number (MSISDN).
        /// </summary>
        public string? MobileNumber { get; set; }

        /// <summary>
        /// 4-digit PIN for customer identity verification.
        /// </summary>
        public string? PIN { get; set; }

        /// <summary>
        /// Plan price, stored as a string to accommodate currency symbols (e.g., "$45").
        /// </summary>
        public string? PlanAmount { get; set; }

        /// <summary>
        /// Mobile phone purchase price (Mobile Phone Price, MPP), stored as a string.
        /// </summary>
        public string? MPP { get; set; }

        /// <summary>
        /// Duration of the contract in months (e.g., 12, 24, 36).
        /// Nullable to allow SIM-only or undefined contracts.
        /// </summary>
        public int? TermMonths { get; set; }

        /// <summary>
        /// Discount amount applied to the contract.
        /// Stored as a string to support formatted values like "$10 off".
        /// </summary>
        public string? Discount { get; set; }

        /// <summary>
        /// Type of contract: e.g., New, Upgrade, Kickers, MBB, FWA, APP, etc.
        /// Helps classify contract categories.
        /// </summary>
        public string? ContractType { get; set; }

        /// <summary>
        /// Name or model of the device associated with the contract.
        /// Can be null for SIM-only contracts.
        /// </summary>
        public string? Device { get; set; }

        /// <summary>
        /// IMEI (device serial number) of the handset.
        /// Used for future stock tracking or warranty purposes.
        /// </summary>
        public string? IMEI { get; set; }

        /// <summary>
        /// Sales or system-generated order number (e.g., 2-2827865687782z).
        /// </summary>
        public string? OrderNumber { get; set; }

        /// <summary>
        /// Customer's date of birth.
        /// Optional for verification or identity confirmation.
        /// </summary>
        public DateTime? DateOfBirth { get; set; }

        /// <summary>
        /// Customer email address.
        /// Useful for contact or digital invoice delivery.
        /// </summary>
        public string? Email { get; set; }

        /// <summary>
        /// General notes regarding the contract or customer.
        /// Optional.
        /// </summary>
        public string? Note { get; set; }

        /// <summary>
        /// Follow-up notes for future actions, such as pending delivery or post-sale service.
        /// </summary>
        public string? FollowUpNote { get; set; }

        /// <summary>
        /// The timestamp when the contract record was created in the system.
        /// Automatically initialized to the current time.
        /// </summary>
        public DateTime? CreatedAt { get; set; } = DateTime.Now;
    }
}

﻿namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a detailed sales and service performance summary for a single staff member within a report period.
    /// Linked to a parent ReportSummary record.
    /// </summary>
    public class StaffReportDetail
    {
        /// <summary>
        /// Primary key identifier for the staff report detail record.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Foreign key linking to the associated ReportSummary entry.
        /// </summary>
        public int ReportSummaryId { get; set; } // Foreign key

        /// <summary>
        /// Name of the staff member being reported.
        /// </summary>
        public string StaffName { get; set; }

        // ----------- Accessories Section -----------

        /// <summary>
        /// Number of accessory items sold by this staff member.
        /// </summary>
        public int AccessoriesSalesCount { get; set; }

        /// <summary>
        /// Total revenue generated from accessory sales by this staff member.
        /// </summary>
        public double AccessoriesRevenue { get; set; }

        // ----------- Starter Pack Section -----------

        /// <summary>
        /// Number of prepaid starter packs sold by this staff member.
        /// </summary>
        public int StarterPackSalesCount { get; set; }

        /// <summary>
        /// Revenue generated from starter pack sales by this staff member.
        /// </summary>
        public double StarterPackRevenue { get; set; }

        // ----------- Outright Sales Section -----------

        /// <summary>
        /// Number of outright devices sold by the staff member (non-contract).
        /// </summary>
        public int OutrightSalesCount { get; set; }

        /// <summary>
        /// Revenue generated from outright sales.
        /// </summary>
        public double OutrightRevenue { get; set; }

        // ----------- Service Section -----------

        /// <summary>
        /// Number of contract activations or signups completed by this staff member.
        /// </summary>
        public int ContractCount { get; set; }

        /// <summary>
        /// Number of repair jobs handled by the staff member.
        /// </summary>
        public int RepairCount { get; set; }
    }
}

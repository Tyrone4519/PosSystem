﻿/// <summary>
/// Represents a prepaid mobile starter pack product, typically sold in telecom retail.
/// Tracks brand, plan details, remaining stock, tax, and update timestamps.
/// </summary>
public class PrepaidStarterPack
{
    /// <summary>
    /// Primary key identifier for the prepaid starter pack entry.
    /// </summary>
    public int Id { get; set; }

    /// <summary>
    /// Brand of the starter pack (e.g., Optus, Telstra, Vodafone).
    /// </summary>
    public string Brand { get; set; }

    /// <summary>
    /// Name of the prepaid plan (e.g., "$30 Combo", "Prepaid Plus").
    /// </summary>
    public string PlanName { get; set; }

    /// <summary>
    /// Remaining number of units in stock for this plan.
    /// Helps track inventory levels.
    /// </summary>
    public int RemainingStock { get; set; }

    /// <summary>
    /// Optional description of the plan, such as data allowance or validity period.
    /// </summary>
    public string Description { get; set; } = string.Empty;

    /// <summary>
    /// GST (Goods and Services Tax) applicable to this pack.
    /// </summary>
    public decimal GST { get; set; } = 0;

    /// <summary>
    /// Timestamp of the last update to this record (e.g., stock adjustment or price change).
    /// Automatically set to the current time when modified.
    /// </summary>
    public DateTime LastUpdated { get; set; } = DateTime.Now;
}

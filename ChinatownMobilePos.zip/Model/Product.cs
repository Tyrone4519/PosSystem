﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a product entity in the inventory or sales system.
    /// Each product is linked to a specific product type and may have multiple descriptions or variants.
    /// </summary>
    public class Product
    {
        /// <summary>
        /// Primary key identifier for the product.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The name or title of the product (e.g., "iPhone 14 Case").
        /// Required and limited to 100 characters.
        /// </summary>
        [Required]
        [MaxLength(100)]
        public string Name { get; set; }

        /// <summary>
        /// Foreign key referencing the associated ProductType.
        /// Required to classify the product under a specific category.
        /// </summary>
        [Required]
        [ForeignKey("ProductType")]
        public int ProductTypeId { get; set; }

        /// <summary>
        /// Navigation property to the product type (e.g., Accessories, Devices, SIM Cards).
        /// </summary>
        public ProductType ProductType { get; set; }

        /// <summary>
        /// Collection of additional descriptions or variants related to this product.
        /// For example: size, color, model compatibility, etc.
        /// </summary>
        public virtual ICollection<ProductDescription> ProductDescriptions { get; set; }

        /// <summary>
        /// Retail price of the product.
        /// Must be greater than or equal to zero.
        /// </summary>
        [Range(0, double.MaxValue)]
        public decimal Price { get; set; }
    }
}

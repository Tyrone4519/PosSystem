﻿using Microsoft.EntityFrameworkCore;
using ChinatownMobilePos.Models;
using ChinatownMobilePos.Model;
using System;
using System.Linq;
using ChinatownMobilePos.Forms;

namespace ChinatownMobilePos.Data
{
    /// <summary>
    /// Represents the application's database context.
    /// Inherits from Entity Framework's DbContext and provides access to all the database tables.
    /// </summary>
    public class AppDbContext : DbContext
    {
        // Define database tables as DbSet<TEntity>
        public DbSet<Supplier> Suppliers { get; set; }
        public DbSet<Device> Devices { get; set; }
        public DbSet<Contract> Contracts { get; set; }
        public DbSet<ChinatownMobilePos.Models.Invoice> Invoices { get; set; }
        public DbSet<Staff> Staffs { get; set; }
        public DbSet<DailyTask> DailyTasks { get; set; }
        public DbSet<RepairRecord> RepairRecords { get; set; }
        public DbSet<WorkSchedule> WorkSchedules { get; set; }
        public DbSet<DailySale> DailySales { get; set; }
        public DbSet<InvoiceItem> InvoiceItems { get; set; }
        public DbSet<CashDenominationDetail> CashDenominationDetails { get; set; }
        public DbSet<PrepaidStarterPack> PrepaidStarterPacks { get; set; }
        public DbSet<StockItem> StockItems { get; set; }
        public DbSet<Money> Moneys { get; set; }
        public DbSet<ReportSummary> ReportSummaries { get; set; }
        public DbSet<StaffReportDetail> StaffReportDetails { get; set; }
        public DbSet<ProductType> ProductTypes { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<ProductDescription> ProductDescriptions { get; set; }

        /// <summary>
        /// Constructor accepting DbContext options (e.g., connection string and provider).
        /// Typically used in dependency injection scenarios.
        /// </summary>
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        /// <summary>
        /// Parameterless constructor.
        /// Will use OnConfiguring() method to define connection if not provided externally.
        /// </summary>
        public AppDbContext() : base() { }

        /// <summary>
        /// Configures the database connection if not already set externally.
        /// Uses MySQL as the database provider with an IP-based or localhost connection string.
        /// </summary>
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                // MySQL connection string with no password (default root access)
                var connectionString = "server=192.168.0.151;port=3306;database=chinatownpos;user=root;password=;";
                // Alternate local connection for development
                // var connectionString = "server=localhost;port=3306;database=chinatownpos;user=root;password=;";
                optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));
            }
        }

        /// <summary>
        /// Customize model creation here using Fluent API if needed.
        /// Currently defers to base implementation.
        /// </summary>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            // Add Fluent API configurations here if necessary
        }

        /// <summary>
        /// Overrides SaveChanges to add automatic timestamping for PrepaidStarterPack entities.
        /// Sets 'LastUpdated' to current DateTime whenever modified.
        /// </summary>
        public override int SaveChanges()
        {
            // Track all modified PrepaidStarterPack entries
            var updatedStarterPacks = ChangeTracker.Entries<PrepaidStarterPack>()
                .Where(e => e.State == EntityState.Modified);

            // Set LastUpdated timestamp to current time
            foreach (var entry in updatedStarterPacks)
            {
                entry.Entity.LastUpdated = DateTime.Now;
            }

            return base.SaveChanges();
        }
    }

    /// <summary>
    /// Helper class that provides a singleton-like static access to AppDbContext.
    /// Useful for contexts where dependency injection is not available.
    /// </summary>
    public static class DbContextHelper
    {
        private static AppDbContext _context;

        /// <summary>
        /// Returns a shared instance of AppDbContext.
        /// Creates a new one if not already initialized.
        /// Ensures the connection string is consistent with AppDbContext.
        /// </summary>
        public static AppDbContext GetContext()
        {
            if (_context == null)
            {
                var optionsBuilder = new DbContextOptionsBuilder<AppDbContext>();

                // Use the same MySQL connection string defined earlier
                var connectionString = "server=192.168.0.151;port=3306;database=chinatownpos;user=root;password=;";
                // Alternate connection for local development
                // var connectionString = "server=localhost;port=3306;database=chinatownpos;user=root;password=;";

                optionsBuilder.UseMySql(connectionString, ServerVersion.AutoDetect(connectionString));

                _context = new AppDbContext(optionsBuilder.Options);
            }
            return _context;
        }
    }
}

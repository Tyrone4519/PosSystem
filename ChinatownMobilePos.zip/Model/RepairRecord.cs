﻿using System;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a record of a device repair.
    /// Includes repair details such as device name, parts used, labor cost, sale price, and status.
    /// </summary>
    public class RepairRecord
    {
        /// <summary>
        /// Primary key identifier for the repair record.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Date the repair was logged or performed.
        /// </summary>
        public DateTime Date { get; set; }

        /// <summary>
        /// Name of the technician or staff member who performed the repair.
        /// </summary>
        public string RepairerName { get; set; }

        /// <summary>
        /// Description or name of the device that was repaired.
        /// </summary>
        public string Device { get; set; }

        /// <summary>
        /// List or description of parts used during the repair.
        /// Can include multiple items (e.g., screen, battery, motherboard).
        /// </summary>
        public string PartsUsed { get; set; }

        /// <summary>
        /// Name of the supplier that provided the parts.
        /// </summary>
        public string Supplier { get; set; }

        /// <summary>
        /// Labor cost for the repair, excluding parts.
        /// </summary>
        public double LaborCost { get; set; }

        /// <summary>
        /// Total price charged to the customer for the repair.
        /// </summary>
        public double SalePrice { get; set; }

        /// <summary>
        /// Indicates whether the customer has picked up the repaired device.
        /// </summary>
        public bool IsPickedUp { get; set; }

        /// <summary>
        /// Indicates whether the customer has paid for the repair service.
        /// </summary>
        public bool IsPaid { get; set; }

        /// <summary>
        /// Additional notes regarding the repair job (e.g., diagnostic info, warranty, condition).
        /// </summary>
        public string Note { get; set; }
    }
}

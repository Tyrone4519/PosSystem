﻿using System;
using System.Collections.Generic;

namespace ChinatownMobilePos.Models
{
    /// <summary>
    /// Represents a summary report for a given time period.
    /// Aggregates sales and operational data across various categories, such as accessories, repairs, contracts, and staff performance.
    /// </summary>
    public class ReportSummary
    {
        /// <summary>
        /// Primary key identifier for the report summary.
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// The start date of the reporting period.
        /// </summary>
        public DateTime StartDate { get; set; }  // Report period start

        /// <summary>
        /// The end date of the reporting period.
        /// </summary>
        public DateTime EndDate { get; set; }    // Report period end

        /// <summary>
        /// Type of report: e.g., "Week", "Month".
        /// Useful for categorizing summaries based on frequency.
        /// </summary>
        public string ReportType { get; set; }   // Week / Month

        // ----------- Accessories Section -----------

        /// <summary>
        /// Total number of accessory items sold during the period.
        /// </summary>
        public int AccessoriesSalesCount { get; set; }

        /// <summary>
        /// Total revenue from accessories sales.
        /// </summary>
        public double AccessoriesRevenue { get; set; }

        // ----------- Starter Pack Section -----------

        /// <summary>
        /// Number of prepaid starter packs sold.
        /// </summary>
        public int StarterPackSalesCount { get; set; }

        /// <summary>
        /// Revenue generated from prepaid starter packs.
        /// </summary>
        public double StarterPackRevenue { get; set; }

        // ----------- Outright Sales Section -----------

        /// <summary>
        /// Count of outright device/unit sales (non-contract).
        /// </summary>
        public int OutrightSalesCount { get; set; }

        /// <summary>
        /// Total revenue from outright sales.
        /// </summary>
        public double OutrightRevenue { get; set; }

        // ----------- Service Sections -----------

        /// <summary>
        /// Total number of device repairs completed.
        /// </summary>
        public int RepairCount { get; set; }

        /// <summary>
        /// Total number of contract activations (e.g., postpaid mobile plans).
        /// </summary>
        public int ContractCount { get; set; }

        /// <summary>
        /// Detailed performance breakdown by staff member during the report period.
        /// </summary>
        public List<StaffReportDetail> StaffDetails { get; set; } = new();
    }
}

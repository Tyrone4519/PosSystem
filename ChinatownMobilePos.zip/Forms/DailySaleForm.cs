﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using Microsoft.EntityFrameworkCore;
using ClosedXML.Excel;

namespace ChinatownMobilePos.Forms
{
    public partial class DailySaleForm : Form
    {
        private DateTimePicker dtpDate;
        private TextBox txtNoteSearch;
        private ComboBox cmbStaff;
        private ComboBox cmbType;
        private DataGridView dgvSales;
        private Label lblTotalCash;
        private Label lblDifference;
        private Button btnSave;
        private Button btnExport;
        private NumericUpDown[] noteInputs;
        private readonly int[] denominations = { 100, 50, 20, 10, 5, 2, 1 };
        private BindingList<DailySale> saleBindingList = new();
        private readonly AppDbContext db;
        private CheckBox chkHeaderSelect;
        private Label lblTotalEFT;
        private Label lblTotalTT;
        private Label lblTotalOMI;
        private Label lblTotalCashNet;

        public DailySaleForm()
        {
            InitializeComponent();
            db = DbContextHelper.GetContext();
            InitializeLayout();
            LoadData();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            using var addForm = new AddSaleForm();
            var result = addForm.ShowDialog();

            if (result == DialogResult.OK && addForm.CreatedSales?.Any() == true)
            {
                try
                {
                    foreach (var sale in addForm.CreatedSales)
                    {
                        db.DailySales.Attach(sale);
                        db.Entry(sale).State = EntityState.Added;
                        saleBindingList.Add(sale);
                    }

                    db.SaveChanges();
                    UpdateCashStats(); 
                    MessageBox.Show("Sales added successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Failed to save sales: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void InitializeLayout()
        {
            this.Text = "Daily Sales";
            this.BackColor = Color.FromArgb(245, 239, 220); 
            this.Font = new Font("Segoe UI", 9F, FontStyle.Bold);
            this.Dock = DockStyle.Fill;

            var offsetPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(20, 40, 20, 20) };
            this.Controls.Add(offsetPanel);

            var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            offsetPanel.Controls.Add(mainLayout);

            var leftPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                Padding = new Padding(10),
                BackColor = Color.FromArgb(245, 239, 220)
            };
            leftPanel.Controls.Add(new Label { Text = "Money", Font = new Font("Segoe UI", 10, FontStyle.Bold) });
            mainLayout.Controls.Add(leftPanel, 0, 0);

            var rightPanel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 3 };
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 200));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40)); // 合计栏
            mainLayout.Controls.Add(rightPanel, 1, 0);

            // --- Filter Panel
            var filterContainer = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(240, 220, 200), Padding = new Padding(10) };
            rightPanel.Controls.Add(filterContainer, 0, 0);

            var filterLayout = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 5, ColumnCount = 3, AutoSize = true };
            for (int i = 0; i < 3; i++) filterLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33f));
            int[] rowHeights = { 40, 40, 40, 0, 10 };
            foreach (int h in rowHeights) filterLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, h));

            var lblSearch = new Label { Text = "Search:", Anchor = AnchorStyles.Left, AutoSize = true };
            txtNoteSearch = new TextBox { Dock = DockStyle.Fill, Height = 32 };
            txtNoteSearch.TextChanged += (s, e) => LoadData();
            var searchPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            searchPanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            searchPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            searchPanel.Controls.Add(lblSearch, 0, 0);
            searchPanel.Controls.Add(txtNoteSearch, 1, 0);
            filterLayout.Controls.Add(searchPanel, 0, 0);

            var lblDate = new Label { Text = "Date:", Anchor = AnchorStyles.Left, AutoSize = true };
            dtpDate = new DateTimePicker { Dock = DockStyle.Fill, ShowCheckBox = true };
            dtpDate.ValueChanged += (s, e) => LoadData();
            var datePanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            datePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            datePanel.Controls.Add(lblDate, 0, 0);
            datePanel.Controls.Add(dtpDate, 1, 0);
            filterLayout.Controls.Add(datePanel, 1, 0);

            var statsPanel = new Panel { BackColor = Color.LightGoldenrodYellow, Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(5) };
            lblTotalCash = new Label { Font = new Font("Segoe UI", 9, FontStyle.Bold), AutoSize = true };
            lblDifference = new Label { Font = new Font("Segoe UI", 9, FontStyle.Bold), AutoSize = true };
            var statsFlow = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.TopDown };
            statsFlow.Controls.Add(lblTotalCash);
            statsFlow.Controls.Add(lblDifference);
            statsPanel.Controls.Add(statsFlow);
            filterLayout.Controls.Add(statsPanel, 2, 0);

            var lblPayment = new Label { Text = "Payment:", Anchor = AnchorStyles.Left, AutoSize = true };
            cmbStaff = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStaff.Items.AddRange(new string[] { "All", "EFT", "OMI", "TT", "Cash" });
            cmbStaff.SelectedIndexChanged += (s, e) => LoadData();
            var paymentPanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            paymentPanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            paymentPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            paymentPanel.Controls.Add(lblPayment, 0, 0);
            paymentPanel.Controls.Add(cmbStaff, 1, 0);
            filterLayout.Controls.Add(paymentPanel, 0, 1);

            var labelRow = new FlowLayoutPanel { AutoSize = true, Padding = new Padding(0, 0, 0, 5) };
            foreach (int denom in denominations)
            {
                labelRow.Controls.Add(new Label
                {
                    Text = $"{denom}:",
                    Width = 55,
                    TextAlign = ContentAlignment.MiddleRight,
                    Margin = new Padding(10, 0, 0, 0)
                });
            }
            filterLayout.Controls.Add(labelRow, 1, 1);

            noteInputs = new NumericUpDown[denominations.Length];
            var inputRow = new FlowLayoutPanel { AutoSize = true };
            for (int i = 0; i < denominations.Length; i++)
            {
                noteInputs[i] = new NumericUpDown
                {
                    Width = 60,
                    Maximum = 1000,
                    TextAlign = HorizontalAlignment.Right,
                    Margin = new Padding(10, 0, 0, 0)
                };
                noteInputs[i].ValueChanged += (s, e) => UpdateCashStats();
                inputRow.Controls.Add(noteInputs[i]);
            }
            filterLayout.Controls.Add(inputRow, 1, 2);

            var buttonPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, Dock = DockStyle.Fill, AutoSize = true };
            filterLayout.Controls.Add(buttonPanel, 2, 1);

            void AddStyledButton(FlowLayoutPanel panel, string text, Color color, EventHandler clickHandler)
            {
                var btn = new Button
                {
                    Text = text,
                    Width = 105,
                    Height = 32,
                    FlatStyle = FlatStyle.Flat,
                    BackColor = color,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 9, FontStyle.Bold)
                };
                btn.FlatAppearance.BorderSize = 0;
                btn.Click += clickHandler;
                panel.Controls.Add(btn);
            }

            AddStyledButton(buttonPanel, "Export", Color.Peru, (s, e) => ExportSales());
            AddStyledButton(buttonPanel, "Invoice", Color.IndianRed, (s, e) => MessageBox.Show("Invoice not implemented"));
            AddStyledButton(buttonPanel, "Save", Color.SeaGreen, (s, e) => SaveChanges());
            AddStyledButton(buttonPanel, "Add", Color.RoyalBlue, BtnAdd_Click);
            var btnDelete = new Button
            {
                Text = "Delete",
                Width = 105,
                Height = 32,
                FlatStyle = FlatStyle.Flat,
                BackColor = Color.Firebrick,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnDelete.FlatAppearance.BorderSize = 0;
            btnDelete.Click += (s, e) =>
            {
                var toDelete = new List<DailySale>();

                foreach (DataGridViewRow row in dgvSales.Rows)
                {
                    if (row.Cells["Select"] is DataGridViewCheckBoxCell chk &&
                        chk.Value is bool isChecked && isChecked &&
                        row.DataBoundItem is DailySale sale)
                    {
                        var entry = db.Entry(sale);
                        if (entry.State == EntityState.Detached)
                            db.Attach(sale);

                        db.DailySales.Remove(sale);
                        toDelete.Add(sale);
                    }
                }

                if (toDelete.Any())
                {
                    try
                    {
                        db.SaveChanges();
                        foreach (var sale in toDelete)
                            saleBindingList.Remove(sale);

                        UpdateCashStats();
                        MessageBox.Show($"{toDelete.Count} record(s) deleted successfully.");
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Delete failed: " + ex.Message);
                    }
                }
                else
                {
                    MessageBox.Show("Please select at least one row to delete.");
                }
            };
            buttonPanel.Controls.Add(btnDelete);


            var lblType = new Label { Text = "Type:", Anchor = AnchorStyles.Left, AutoSize = true };
            cmbType = new ComboBox { Dock = DockStyle.Fill, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbType.Items.AddRange(new string[] { "All", "Simcard", "Accessories", "Recharge", "Handset", "Repair", "Other" });
            cmbType.SelectedIndexChanged += (s, e) => LoadData();
            var typePanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            typePanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            typePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            typePanel.Controls.Add(lblType, 0, 0);
            typePanel.Controls.Add(cmbType, 1, 0);
            filterLayout.Controls.Add(typePanel, 0, 2);

            var productButtonPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.TopDown, Dock = DockStyle.Fill, AutoSize = true };
            filterLayout.Controls.Add(productButtonPanel, 2, 2);
            AddStyledButton(productButtonPanel, "ProductT", Color.MediumSlateBlue, (s, e) => new ProductTypeForm().ShowDialog());
            AddStyledButton(productButtonPanel, "Product", Color.Teal, (s, e) => new ProductForm().ShowDialog());
            AddStyledButton(productButtonPanel, "DESC", Color.MediumPurple, (s, e) => new ProductDescriptionForm().ShowDialog());

            filterLayout.Controls.Add(new Panel(), 2, 4);
            filterContainer.Controls.Add(filterLayout);

            // --- DataGridView Panel
            var dgvPanel = new Panel { Dock = DockStyle.Fill, AutoScroll = true, Padding = new Padding(0, 0, 0, 5) };

            dgvSales = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = true,
                EditMode = DataGridViewEditMode.EditProgrammatically,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                RowTemplate = { Height = 28 },
                ScrollBars = ScrollBars.Both,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.Maroon,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
                EnableHeadersVisualStyles = false
            };

            dgvPanel.Controls.Add(dgvSales);
            rightPanel.Controls.Add(dgvPanel, 0, 1);

            // --- Totals Panel
            var totalsPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                Padding = new Padding(10, 5, 0, 0),
                BackColor = Color.FromArgb(250, 240, 200),
                AutoScroll = true
            };

            lblTotalEFT = new Label { AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(0, 5, 20, 0) };
            lblTotalTT = new Label { AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(0, 5, 20, 0) };
            lblTotalOMI = new Label { AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(0, 5, 20, 0) };
            lblTotalCashNet = new Label { AutoSize = true, Font = new Font("Segoe UI", 9, FontStyle.Bold), Margin = new Padding(0, 5, 20, 0) };

            totalsPanel.Controls.Add(lblTotalEFT);
            totalsPanel.Controls.Add(lblTotalTT);
            totalsPanel.Controls.Add(lblTotalOMI);
            totalsPanel.Controls.Add(lblTotalCashNet);
            rightPanel.Controls.Add(totalsPanel, 0, 2);
        }



        private void LoadData()
        {
            var query = db.DailySales.AsQueryable();

            if (dtpDate.Checked)
                query = query.Where(s => s.Date == dtpDate.Value.Date);

            if (!string.IsNullOrEmpty(txtNoteSearch.Text))
                query = query.Where(s => s.Note != null && s.Note.ToLower().Contains(txtNoteSearch.Text.ToLower()));

            if (!string.IsNullOrEmpty(cmbStaff.Text) && cmbStaff.Text != "All")
            {
                switch (cmbStaff.Text)
                {
                    case "EFT":
                        query = query.Where(s => s.PaymentEFT > 0);
                        break;
                    case "OMI":
                        query = query.Where(s => s.PaymentOMI > 0);
                        break;
                    case "TT":
                        query = query.Where(s => s.PaymentTT > 0);
                        break;
                    case "Cash":
                        query = query.Where(s => s.PaymentCash > 0);
                        break;
                }
            }

            if (!string.IsNullOrEmpty(cmbType.Text) && cmbType.Text != "All")
                query = query.Where(s => s.SaleType == cmbType.Text);

            var sales = query.OrderByDescending(s => s.CreatedAt).ToList();


            saleBindingList = new BindingList<DailySale>(sales);
            dgvSales.DataSource = saleBindingList;
            CustomizeGrid();
            UpdateCashStats();
            UpdatePaymentTotals();

            var selectedDate = dtpDate.Value.Date;
            var cash = db.CashDenominationDetails.FirstOrDefault(x => x.Date == selectedDate);
            if (cash != null)
            {
                noteInputs[0].Value = cash.Note100;
                noteInputs[1].Value = cash.Note50;
                noteInputs[2].Value = cash.Note20;
                noteInputs[3].Value = cash.Note10;
                noteInputs[4].Value = cash.Note5;
                noteInputs[5].Value = cash.Note2;
                noteInputs[6].Value = cash.Note1;
            }
            else
            {
                for (int i = 0; i < noteInputs.Length; i++)
                    noteInputs[i].Value = 0;
            }
        }


        private void CustomizeGrid()
        {
            dgvSales.AutoGenerateColumns = false;
            dgvSales.Columns.Clear();

            dgvSales.EditMode = DataGridViewEditMode.EditOnEnter;
            dgvSales.AllowUserToAddRows = false;
            dgvSales.AllowUserToDeleteRows = true;

            var selectCol = new DataGridViewCheckBoxColumn
            {
                Name = "Select",
                HeaderText = "",
                Width = 30,
                ReadOnly = false,
                TrueValue = true,
                FalseValue = false
            };
            dgvSales.Columns.Add(selectCol);

            void AddColumn(string name, string header, int index, int width = 100, string? format = null, bool visible = true, bool readOnly = true)
            {
                var col = new DataGridViewTextBoxColumn
                {
                    DataPropertyName = name,
                    HeaderText = header,
                    Name = name,
                    DisplayIndex = index,
                    Visible = visible,
                    ReadOnly = readOnly,
                    Width = width
                };

                if (!string.IsNullOrEmpty(format))
                {
                    col.DefaultCellStyle.Format = format;
                }

                dgvSales.Columns.Add(col);
            }

            AddColumn("Id", "Id", 99, visible: false);
            AddColumn("GroupId", "GroupID", 1, 60);
            AddColumn("Date", "Date", 2, 90, "yyyy-MM-dd");
            AddColumn("StaffName", "Staff", 3, 60);
            AddColumn("Quantity", "Qty", 4, 30);
            AddColumn("Product", "Product", 5, 180, readOnly: false);
            AddColumn("ProductDescriptionText", "Description", 6, 200, readOnly: false);
            AddColumn("Note", "Note", 7, 300, readOnly: false);
            AddColumn("IMEI", "IMEI", 8, 130);
            AddColumn("PaymentEFT", "EFT", 9, 50);
            AddColumn("PaymentTT", "TT", 10, 50);
            AddColumn("PaymentOMI", "OMI", 11, 50);
            AddColumn("PaymentCash", "Cash", 12, 50, readOnly: false);
            AddColumn("PaymentCashout", "Out", 13, 50);
            AddColumn("CreatedAt", "CreatedAt", 14, 120, "yyyy-MM-dd HH:mm");
            AddColumn("SaleType", "Sale Type", 15, 100);
            AddColumn("ProductType", "ProductType", 16, 100);

            if (chkHeaderSelect == null)
            {
                chkHeaderSelect = new CheckBox
                {
                    Size = new Size(15, 15)
                };

                chkHeaderSelect.CheckedChanged += (s, e) =>
                {
                    foreach (DataGridViewRow row in dgvSales.Rows)
                    {
                        row.Cells["Select"].Value = chkHeaderSelect.Checked;
                    }
                };

                dgvSales.Controls.Add(chkHeaderSelect);
            }

            dgvSales.DataBindingComplete -= DgvSales_DataBindingComplete;
            dgvSales.DataBindingComplete += DgvSales_DataBindingComplete;

            dgvSales.CellEndEdit -= DgvSales_CellEndEdit;
            dgvSales.CellEndEdit += DgvSales_CellEndEdit;

            // 注册动态格式化事件
            dgvSales.CellFormatting -= DgvSales_CellFormatting;
            dgvSales.CellFormatting += DgvSales_CellFormatting;

        }


        private void DgvSales_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            var row = dgvSales.Rows[e.RowIndex];
            var cell = row.Cells[e.ColumnIndex];
            var sale = row.DataBoundItem as DailySale;

            if (sale == null) return;


            cell.Style.BackColor = Color.LightGoldenrodYellow;

            try
            {
                if (db.Entry(sale).State == EntityState.Detached)
                {
                    db.DailySales.Attach(sale);
                }

                db.Entry(sale).State = EntityState.Modified;
                db.SaveChanges();

                cell.Style.BackColor = Color.LightGreen;
            }
            catch (Exception ex)
            {

                cell.Style.BackColor = Color.IndianRed;
                MessageBox.Show("Saved fail: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            UpdateCashStats();
        }

        private void DgvSales_CellFormatting(object? sender, DataGridViewCellFormattingEventArgs e)
        {
            var columnName = dgvSales.Columns[e.ColumnIndex].Name;

            if (dgvSales.Rows[e.RowIndex].DataBoundItem is not DailySale sale)
                return;

            decimal? value = columnName switch
            {
                "PaymentCash" => sale.PaymentCash,
                "PaymentEFT" => sale.PaymentEFT,
                "PaymentTT" => sale.PaymentTT,
                "PaymentOMI" => sale.PaymentOMI,
                "PaymentCashout" => sale.PaymentCashout,
                _ => null
            };

            if (value.HasValue && value.Value > 0)
            {
                Color bg = columnName switch
                {
                    "PaymentCash" => Color.LightGreen,
                    "PaymentEFT" => Color.LightCyan,
                    "PaymentTT" => Color.LightGray,
                    "PaymentOMI" => Color.Lavender,
                    "PaymentCashout" => Color.LightCoral,
                    _ => dgvSales.DefaultCellStyle.BackColor
                };

                e.CellStyle.BackColor = bg;
            }
        }


        private void DgvSales_DataBindingComplete(object? sender, DataGridViewBindingCompleteEventArgs e)
        {
            var rect = dgvSales.GetCellDisplayRectangle(0, -1, true);
            chkHeaderSelect.Location = new Point(
                rect.X + (rect.Width - chkHeaderSelect.Width) / 2,
                rect.Y + (rect.Height - chkHeaderSelect.Height) / 2
            );
            chkHeaderSelect.BringToFront();
        }


        private void UpdateCashStats()
        {
            decimal paymentCashSum = saleBindingList.Sum(s => s.PaymentCash.GetValueOrDefault());
            decimal paymentOutSum = saleBindingList.Sum(s => s.PaymentCashout.GetValueOrDefault());
            decimal drawerTotal = 0;

            for (int i = 0; i < denominations.Length; i++)
                drawerTotal += denominations[i] * (int)noteInputs[i].Value;

            decimal difference = drawerTotal - paymentCashSum + paymentOutSum;

            lblTotalCash.Text = $"Drawer Total: ${drawerTotal:N2}";
            lblDifference.Text = $"Difference: {difference:+$0.00; -$0.00; $0.00}";
            lblDifference.ForeColor = difference switch
            {
                < 0 => Color.Red,
                > 0 => Color.Orange,
                _ => Color.Green
            };

            UpdatePaymentTotals();
        }

        private void UpdatePaymentTotals()
        {
            decimal eft = saleBindingList.Sum(s => s.PaymentEFT.GetValueOrDefault());
            decimal tt = saleBindingList.Sum(s => s.PaymentTT.GetValueOrDefault());
            decimal omi = saleBindingList.Sum(s => s.PaymentOMI.GetValueOrDefault());
            decimal cash = saleBindingList.Sum(s => s.PaymentCash.GetValueOrDefault());
            decimal cashOut = saleBindingList.Sum(s => s.PaymentCashout.GetValueOrDefault());
            decimal netCash = cash - cashOut;

            lblTotalEFT.Text = $"EFT Total: ${eft:N2}";
            lblTotalTT.Text = $"TT Total: ${tt:N2}";
            lblTotalOMI.Text = $"OMI Total: ${omi:N2}";
            lblTotalCashNet.Text = $"Cash(Cash-Out): ${netCash:N2}";
        }


        private void SaveChanges()
        {
            var selectedDate = dtpDate.Value.Date;

            var existing = db.CashDenominationDetails
                .FirstOrDefault(x => x.Date == selectedDate);

            if (existing == null)
            {
                existing = new CashDenominationDetail { Date = selectedDate };
                db.CashDenominationDetails.Add(existing);
            }

            existing.Note100 = (int)noteInputs[0].Value;
            existing.Note50 = (int)noteInputs[1].Value;
            existing.Note20 = (int)noteInputs[2].Value;
            existing.Note10 = (int)noteInputs[3].Value;
            existing.Note5 = (int)noteInputs[4].Value;
            existing.Note2 = (int)noteInputs[5].Value;
            existing.Note1 = (int)noteInputs[6].Value;

            db.SaveChanges();
            MessageBox.Show("Cash denominations saved successfully.");
        }


        private void ExportSales()
        {
            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("Sales");
            ws.Cell(1, 1).InsertTable(saleBindingList);
            var dlg = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() == DialogResult.OK)
                workbook.SaveAs(dlg.FileName);
        }
    }
}

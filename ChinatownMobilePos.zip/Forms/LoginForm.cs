﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Model;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class LoginForm : Form
    {
        private TextBox txtUsername;
        private TextBox txtPassword;
        private Button btnLogin;
        private Button btnCancel;
        private Label lblMessage;

        private readonly AppDbContext _context;

        public string LoggedInUser { get; private set; }
        public Staff LoggedInStaff { get; private set; }

        public LoginForm()
        {
            InitializeComponent();
            _context = new AppDbContext();
            InitializeLoginLayout();
        }

        private void InitializeLoginLayout()
        {
            this.Text = "Login";
            this.Size = new Size(300, 300);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = Color.White;

            Label lblTitle = new Label
            {
                Text = "Login",
                Font = new Font("Segoe UI", 14, FontStyle.Bold),
                Location = new Point(110, 20),
                AutoSize = true
            };
            this.Controls.Add(lblTitle);

            Label lblUsername = new Label
            {
                Text = "Username:",
                Location = new Point(15, 60),
                AutoSize = true
            };
            txtUsername = new TextBox
            {
                Location = new Point(110, 58),
                Width = 140
            };

            Label lblPassword = new Label
            {
                Text = "Password:",
                Location = new Point(15, 95),
                AutoSize = true
            };
            txtPassword = new TextBox
            {
                Location = new Point(110, 93),
                Width = 140,
                UseSystemPasswordChar = true
            };

            btnLogin = new Button
            {
                Text = "Login",
                Location = new Point(50, 140),
                Width = 80,
                Height = 40
            };
            btnLogin.Click += BtnLogin_Click;

            btnCancel = new Button
            {
                Text = "Cancel",
                Location = new Point(150, 140),
                Width = 80,
                Height = 40
            };
            btnCancel.Click += (s, e) => this.Close();

            lblMessage = new Label
            {
                ForeColor = Color.Red,
                AutoSize = true,
                Location = new Point(30, 190)
            };

            this.Controls.AddRange(new Control[] {
                lblUsername, txtUsername,
                lblPassword, txtPassword,
                btnLogin, btnCancel,
                lblMessage
            });
        }

        private void BtnLogin_Click(object sender, EventArgs e)
        {
            string user = txtUsername.Text.Trim();
            string pass = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(user) || string.IsNullOrEmpty(pass))
            {
                lblMessage.Text = "Please enter both username and password.";
                return;
            }

            var staff = _context.Staffs
                .FirstOrDefault(s => s.Username == user && s.PasswordHash == pass && s.IsActive == true);

            if (staff != null)
            {
                LoggedInUser = staff.StaffName;
                LoggedInStaff = staff;
                MessageBox.Show("Login successful!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                lblMessage.Text = "Invalid username or password, or account is inactive.";
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Model;

namespace ChinatownMobilePos.Forms
{
    public partial class DailyTaskForm : Form
    {
        private readonly AppDbContext db;
        private BindingList<DailyTask> taskList = new();
        private DataGridView dgv;
        private TextBox txtSearch;
        private ComboBox cmbStaffFilter, cmbStatusFilter;
        private DateTimePicker dateFilter;
        private CheckBox chkEnableDate;

        public DailyTaskForm()
        {
            InitializeComponent();
            db = new AppDbContext();
            SetupLayout();
            LoadTasks();
        }

        private void SetupLayout()
        {
            this.BackColor = Color.FromArgb(245, 239, 220); 
            this.Padding = new Padding(200, 80, 40, 40);

            var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            this.Controls.Add(mainLayout);

            var leftPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                WrapContents = false
            };

            Color btnColor = Color.DarkGoldenrod;
            Font btnFont = new Font("Segoe UI", 9F, FontStyle.Bold);

            var btnAdd = new Button { Text = "Add", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnDelete = new Button { Text = "Delete", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnSave = new Button { Text = "Save", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };

            btnAdd.Click += (s, e) => AddTaskViaPopup();
            btnDelete.Click += (s, e) => DeleteSelectedTask();
            btnSave.Click += (s, e) => SaveChanges();

            leftPanel.Controls.AddRange(new[] { btnAdd, btnDelete, btnSave });

            var filterPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40,
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight
            };

            filterPanel.Controls.Add(new Label { Text = "Search Note:", AutoSize = true });
            txtSearch = new TextBox { Width = 200 };
            txtSearch.TextChanged += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(txtSearch);

            filterPanel.Controls.Add(new Label { Text = "Staff:", AutoSize = true });
            cmbStaffFilter = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStaffFilter.Items.Add("");
            cmbStaffFilter.Items.AddRange(db.Staffs.Select(s => s.StaffName).Distinct().ToArray());
            cmbStaffFilter.SelectedIndexChanged += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(cmbStaffFilter);

            filterPanel.Controls.Add(new Label { Text = "Status:", AutoSize = true });
            cmbStatusFilter = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStatusFilter.Items.AddRange(new[] { "", "In Progress", "Finished", "Transfer" });
            cmbStatusFilter.SelectedIndexChanged += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(cmbStatusFilter);

            chkEnableDate = new CheckBox { Text = "Filter Date:", AutoSize = true };
            chkEnableDate.CheckedChanged += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(chkEnableDate);

            dateFilter = new DateTimePicker { Width = 130 };
            dateFilter.ValueChanged += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(dateFilter);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = true,
                AutoGenerateColumns = false,
                BackgroundColor = Color.White
            };

            var rightPanel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2 };
            rightPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightPanel.Controls.Add(filterPanel, 0, 0);
            rightPanel.Controls.Add(dgv, 0, 1);

            mainLayout.Controls.Add(leftPanel, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);
        }
        private void LoadTasks()
        {
            taskList = new BindingList<DailyTask>(db.DailyTasks.ToList());
            dgv.DataSource = taskList;
            CustomizeGrid();
        }

        private void CustomizeGrid()
        {
            dgv.Columns.Clear();

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Id",
                HeaderText = "ID",
                Name = "Id",
                ReadOnly = true
            });

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "StaffName",
                HeaderText = "Staff",
                Name = "StaffName",
                DataSource = db.Staffs.Select(s => s.StaffName).ToList(),
                DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton
            });

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "Note",
                HeaderText = "Note",
                Name = "Note",
                AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill
            });

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                DataPropertyName = "Status",
                HeaderText = "Status",
                Name = "Status",
                DataSource = new[] { "In Progress", "Finished", "Transfer" }
            });

            dgv.Columns.Add(new CalendarColumn
            {
                DataPropertyName = "Date",
                HeaderText = "Task Date",
                Name = "Date"
            });

            dgv.Columns.Add(new CalendarColumn
            {
                DataPropertyName = "TransferDate",
                HeaderText = "Transfer Date",
                Name = "TransferDate"
            });

            dgv.Columns.Add(new DataGridViewTextBoxColumn
            {
                DataPropertyName = "CreatedAt",
                HeaderText = "Created At",
                Name = "CreatedAt",
                ReadOnly = true,
                DefaultCellStyle = new DataGridViewCellStyle { Format = "yyyy-MM-dd HH:mm" }
            });

            dgv.CellValueChanged += Dgv_CellValueChanged;
            dgv.CellFormatting += Dgv_CellFormatting;
            dgv.CellValidating += Dgv_CellValidating;
        }

        private void Dgv_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgv.Rows[e.RowIndex];
            var status = row.Cells["Status"].Value?.ToString();

            row.DefaultCellStyle.BackColor = status switch
            {
                "In Progress" => Color.LightCoral,
                "Finished" => Color.LightGreen,
                "Transfer" => Color.Khaki,
                _ => row.DefaultCellStyle.BackColor
            };
        }

        private void Dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var row = dgv.Rows[e.RowIndex];
            var status = row.Cells["Status"].Value?.ToString();

            row.DefaultCellStyle.BackColor = status switch
            {
                "In Progress" => Color.LightCoral,
                "Finished" => Color.LightGreen,
                "Transfer" => Color.Khaki,
                _ => Color.White
            };
        }

        private void Dgv_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {
            if (dgv.Columns[e.ColumnIndex].DataPropertyName == "TransferDate")
            {
                var row = dgv.Rows[e.RowIndex];
                var status = row.Cells["Status"].Value?.ToString();
                var value = e.FormattedValue?.ToString();

                if (status == "Transfer" && string.IsNullOrWhiteSpace(value))
                {
                    row.ErrorText = "Transfer Date is required when status is Transfer.";
                    e.Cancel = true;
                }
                else
                {
                    row.ErrorText = "";
                }
            }
        }
        private void ApplyFilter()
        {
            var keyword = txtSearch.Text.ToLower();
            var staff = cmbStaffFilter.Text;
            var status = cmbStatusFilter.Text;
            var selectedDate = dateFilter.Value.Date;
            var useDate = chkEnableDate.Checked;

            var filtered = db.DailyTasks.ToList().Where(t =>
            {
                var actualDate = t.Status == "Transfer" && t.TransferDate.HasValue
                                 ? t.TransferDate.Value.Date
                                 : t.Date.Date;

                return
                    (string.IsNullOrEmpty(keyword) || (t.Note ?? "").ToLower().Contains(keyword)) &&
                    (string.IsNullOrEmpty(staff) || t.StaffName == staff) &&
                    (string.IsNullOrEmpty(status) || t.Status == status) &&
                    (!useDate || actualDate == selectedDate);
            }).ToList();

            taskList = new BindingList<DailyTask>(filtered);
            dgv.DataSource = taskList;
            CustomizeGrid();
        }

        private void AddTaskViaPopup()
        {
            var dialog = new AddDailyTaskForm(db.Staffs.Select(s => s.StaffName).ToList());
            if (dialog.ShowDialog() == DialogResult.OK)
            {
                var newTask = dialog.NewTask;
                newTask.CreatedAt = DateTime.Now;
                db.DailyTasks.Add(newTask);
                db.SaveChanges();
                LoadTasks();
            }
        }

        private void DeleteSelectedTask()
        {
            if (dgv.CurrentRow?.DataBoundItem is DailyTask selected)
            {
                taskList.Remove(selected);
                var entity = db.DailyTasks.FirstOrDefault(t => t.Id == selected.Id);
                if (entity != null)
                    db.DailyTasks.Remove(entity);
            }
        }

        private void SaveChanges()
        {
            foreach (var task in taskList)
            {
                if (task.Status == "Transfer" && task.TransferDate == null)
                {
                    MessageBox.Show($"Transfer Date is required for Transfer tasks:\n{task.Note}", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var existing = db.DailyTasks.FirstOrDefault(t => t.Id == task.Id);
                if (existing == null)
                {
                    task.CreatedAt = DateTime.Now;
                    db.DailyTasks.Add(task);
                }
                else
                {
                    db.Entry(existing).CurrentValues.SetValues(task);
                }
            }

            db.SaveChanges();
            MessageBox.Show("Changes saved successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadTasks();
        }
    }
}

﻿using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class StaffForm : Form
    {
        private readonly AppDbContext _context;

        private TextBox txtName;
        private TextBox txtUsername;
        private TextBox txtPassword;
        private ComboBox cmbRole;
        private TextBox txtWorkStart;
        private TextBox txtWorkEnd;
        private TextBox txtHourlyRate;
        private TextBox txtNote;
        private CheckBox chkActive;
        private CheckBox chkShowAll;

        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;

        private DataGridView dgvStaffs;

        public StaffForm()
        {
            InitializeComponent();
            _context = new AppDbContext();
            SetupLayout();
            LoadStaffs();
        }

        private void SetupLayout()
        {
            this.BackColor = Color.FromArgb(245, 239, 220);

            Font labelFont = new Font("Segoe UI", 9F);
            Font buttonFont = new Font("Segoe UI", 9F, FontStyle.Bold);

            Panel offsetPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(200, 80, 40, 40)
            };
            this.Controls.Add(offsetPanel);

            TableLayoutPanel leftPanel = new TableLayoutPanel
            {
                RowCount = 16,
                ColumnCount = 2,
                AutoSize = true,
                Dock = DockStyle.Left,
                Padding = new Padding(10, 10, 10, 40),
                Margin = new Padding(20, 20, 20, 40)
            };
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 130));
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            txtName = new TextBox();
            txtUsername = new TextBox();
            txtPassword = new TextBox();
            cmbRole = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbRole.Items.AddRange(new[] { "Manager", "Staff", "Technician", "Other" });
            txtWorkStart = new TextBox();
            txtWorkEnd = new TextBox();
            txtHourlyRate = new TextBox();
            txtNote = new TextBox();
            chkActive = new CheckBox();
            chkShowAll = new CheckBox { Text = "Show All Staff", AutoSize = true, Checked = false };
            chkShowAll.CheckedChanged += (s, e) => LoadStaffs();

            btnAdd = new Button { Text = "Add Staff", Width = 120, Height = 35, BackColor = Color.DarkGoldenrod, ForeColor = Color.White, Font = buttonFont };
            btnDelete = new Button { Text = "Delete", Width = 120, Height = 35, BackColor = Color.DarkGoldenrod, ForeColor = Color.White, Font = buttonFont };
            btnUpdate = new Button { Text = "Update", Width = 120, Height = 35, BackColor = Color.DarkGoldenrod, ForeColor = Color.White, Font = buttonFont };

            btnAdd.Click += BtnAdd_Click;
            btnDelete.Click += BtnDelete_Click;
            btnUpdate.Click += BtnUpdate_Click;

            void AddRow(string label, Control ctrl)
            {
                ctrl.Dock = DockStyle.Fill;
                ctrl.Margin = new Padding(3, 5, 3, 5);
                leftPanel.Controls.Add(new Label
                {
                    Text = label,
                    TextAlign = ContentAlignment.MiddleRight,
                    Font = labelFont,
                    Dock = DockStyle.Fill
                }, 0, leftPanel.RowCount - 1);
                leftPanel.Controls.Add(ctrl, 1, leftPanel.RowCount - 1);
                leftPanel.RowCount++;
            }

            AddRow("Name:", txtName);
            AddRow("Username:", txtUsername);
            AddRow("Password:", txtPassword);
            AddRow("Role:", cmbRole);
            AddRow("Work Start (hh:mm):", txtWorkStart);
            AddRow("Work End (hh:mm):", txtWorkEnd);
            AddRow("Hourly Rate:", txtHourlyRate);
            AddRow("Note:", txtNote);
            AddRow("Active:", chkActive);

            FlowLayoutPanel buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight,
                AutoSize = true,
                Margin = new Padding(3, 10, 3, 3)
            };
            buttonPanel.Controls.AddRange(new[] { btnAdd, btnDelete, btnUpdate });

            leftPanel.Controls.Add(buttonPanel, 0, leftPanel.RowCount);
            leftPanel.SetColumnSpan(buttonPanel, 2);
            leftPanel.RowCount++;

            dgvStaffs = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = false,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells,
                ScrollBars = ScrollBars.Both
            };
            dgvStaffs.CellClick += DgvStaffs_CellClick;

            var rightPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            rightPanel.RowStyles.Add(new RowStyle(SizeType.AutoSize));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightPanel.Controls.Add(chkShowAll, 0, 0);
            rightPanel.Controls.Add(dgvStaffs, 0, 1);

            TableLayoutPanel mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2
            };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 400));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            mainLayout.Controls.Add(leftPanel, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);

            offsetPanel.Controls.Add(mainLayout);
        }

        private void LoadStaffs()
        {
            var query = _context.Staffs.AsQueryable();

            if (!chkShowAll.Checked)
            {
                query = query.Where(s => s.IsActive);
            }

            var staffs = query
                .Select(s => new
                {
                    s.Id,
                    s.StaffName,
                    s.Username,
                    s.PasswordHash,
                    s.Role,
                    s.UpdateTime,
                    WorkTimeStart = s.WorkTimeStart.HasValue ? s.WorkTimeStart.ToString() : "",
                    WorkTimeEnd = s.WorkTimeEnd.HasValue ? s.WorkTimeEnd.ToString() : "",
                    s.HourlyRate,
                    s.Note,
                    s.IsActive
                })
                .ToList();

            dgvStaffs.DataSource = staffs;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                var staff = new Staff
                {
                    StaffName = txtName.Text,
                    Username = txtUsername.Text,
                    PasswordHash = txtPassword.Text,
                    Role = cmbRole.Text,
                    Note = txtNote.Text,
                    UpdateTime = DateTime.Now,
                    WorkTimeStart = TimeSpan.TryParse(txtWorkStart.Text, out var wts) ? wts : (TimeSpan?)null,
                    WorkTimeEnd = TimeSpan.TryParse(txtWorkEnd.Text, out var wte) ? wte : (TimeSpan?)null,
                    HourlyRate = decimal.TryParse(txtHourlyRate.Text, out var rate) ? rate : (decimal?)null,
                    IsActive = chkActive.Checked
                };

                _context.Staffs.Add(staff);
                _context.SaveChanges();
                LoadStaffs();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error saving staff: " + ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgvStaffs.SelectedRows.Count > 0)
            {
                int id = (int)dgvStaffs.SelectedRows[0].Cells["Id"].Value;
                var staff = _context.Staffs.Find(id);
                if (staff != null)
                {
                    _context.Staffs.Remove(staff);
                    _context.SaveChanges();
                    LoadStaffs();
                }
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dgvStaffs.SelectedRows.Count > 0)
            {
                int id = (int)dgvStaffs.SelectedRows[0].Cells["Id"].Value;
                var staff = _context.Staffs.Find(id);
                if (staff != null)
                {
                    staff.StaffName = txtName.Text;
                    staff.Username = txtUsername.Text;
                    staff.PasswordHash = txtPassword.Text;
                    staff.Role = cmbRole.Text;
                    staff.Note = txtNote.Text;
                    staff.WorkTimeStart = TimeSpan.TryParse(txtWorkStart.Text, out var wts) ? wts : (TimeSpan?)null;
                    staff.WorkTimeEnd = TimeSpan.TryParse(txtWorkEnd.Text, out var wte) ? wte : (TimeSpan?)null;
                    staff.HourlyRate = decimal.TryParse(txtHourlyRate.Text, out var rate) ? rate : (decimal?)null;
                    staff.IsActive = chkActive.Checked;

                    _context.SaveChanges();
                    LoadStaffs();
                }
            }
        }

        private void DgvStaffs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && dgvStaffs.SelectedRows.Count > 0)
            {
                var row = dgvStaffs.SelectedRows[0];
                txtName.Text = row.Cells["StaffName"].Value?.ToString();
                txtUsername.Text = row.Cells["Username"].Value?.ToString();
                txtPassword.Text = row.Cells["PasswordHash"].Value?.ToString();
                cmbRole.Text = row.Cells["Role"].Value?.ToString();
                txtWorkStart.Text = row.Cells["WorkTimeStart"].Value?.ToString();
                txtWorkEnd.Text = row.Cells["WorkTimeEnd"].Value?.ToString();
                txtHourlyRate.Text = row.Cells["HourlyRate"].Value?.ToString();
                txtNote.Text = row.Cells["Note"].Value?.ToString();
                chkActive.Checked = Convert.ToBoolean(row.Cells["IsActive"].Value);
            }
        }
    }
}

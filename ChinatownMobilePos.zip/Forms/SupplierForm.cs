﻿using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class SupplierForm : Form
    {
        public static List<string> DefaultSupplierList { get; } = new List<string>
        {
            "VF/Post", "VF/Prepaid", "VF/Rmob", "VF/Preorder", "PPS/Optus", "Yes Group", "Printa Net", "Technologica", "C-Direct", "Apple Store",
            "Huawei", "Samsung", "Mobile Citi", "RM", "iTalkBB", "HTV", "Milan", "Others", "JBs", "Officework", "Roadhound", "SimConnect",
            "CX Daimai", "Allphone MC", "Lebara", "Fairfield", "Crazy"
        };

        private ListBox lstSuppliers;
        private TextBox txtNewSupplier;
        private Button btnAdd, btnDelete, btnClose;
        private readonly AppDbContext db;

        public SupplierForm()
        {
            InitializeComponent();
            db = new AppDbContext();
            SetupLayout();
        }

        private void SetupLayout()
        {
            this.Text = "Manage Suppliers";
            this.Width = 800;
            this.Height = 600;

            lstSuppliers = new ListBox
            {
                Dock = DockStyle.Top,
                Height = 425
            };

            // Load from DB
            var current = db.Suppliers.Select(s => s.Name).ToList();
            if (current.Count == 0)
            {
                db.Suppliers.AddRange(DefaultSupplierList.Select(name => new Supplier { Name = name }));
                db.SaveChanges();
                current = DefaultSupplierList;
            }
            lstSuppliers.Items.AddRange(current.ToArray());

            txtNewSupplier = new TextBox { Dock = DockStyle.Top, PlaceholderText = "Enter new supplier..." };

            btnAdd = new Button { Text = "Add Supplier", Dock = DockStyle.Top, Height = 35 };
            btnAdd.Click += (s, e) =>
            {
                if (!string.IsNullOrWhiteSpace(txtNewSupplier.Text))
                {
                    var name = txtNewSupplier.Text.Trim();
                    if (!db.Suppliers.Any(x => x.Name == name))
                    {
                        db.Suppliers.Add(new Supplier { Name = name });
                        db.SaveChanges();
                        lstSuppliers.Items.Add(name);
                    }
                    txtNewSupplier.Clear();
                }
            };

            btnDelete = new Button { Text = "Delete Selected", Dock = DockStyle.Top, Height = 35 };
            btnDelete.Click += (s, e) =>
            {
                if (lstSuppliers.SelectedItem != null)
                {
                    string selected = lstSuppliers.SelectedItem.ToString();
                    var entry = db.Suppliers.FirstOrDefault(x => x.Name == selected);
                    if (entry != null)
                    {
                        db.Suppliers.Remove(entry);
                        db.SaveChanges();
                        lstSuppliers.Items.Remove(selected);
                    }
                }
            };

            btnClose = new Button { Text = "Close", Dock = DockStyle.Bottom, Height = 35 };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { btnClose, btnDelete, btnAdd, txtNewSupplier, lstSuppliers });
        }
    }
}

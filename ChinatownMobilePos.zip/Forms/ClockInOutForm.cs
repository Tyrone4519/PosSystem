﻿// ClockInOutForm.cs
using System;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class ClockInOutForm : Form
    {
        private readonly Staff _currentStaff;
        private readonly AppDbContext _db;

        public ClockInOutForm(Staff staff)
        {
            InitializeComponent();
            _db = DbContextHelper.GetContext();
            _currentStaff = staff;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            HandleClockOut();
        }

        private void HandleClockOut()
        {
            var today = DateTime.Today;

            var record = _db.CashDenominationDetails.FirstOrDefault(c => c.Date == today);

            if (record != null)
            {
                int cashOutAmount = (record.Note100 * 100) + (record.Note50 * 50);

                // 设置面额为0
                record.Note100 = 0;
                record.Note50 = 0;
                _db.SaveChanges();

                // 添加一条 DailySale
                var sale = new DailySale
                {
                    Id = Guid.NewGuid().ToString(),
                    Date = today,
                    StaffName = _currentStaff?.StaffName ?? "Unknown",
                    SaleType = "Other",
                    Note = "Cash Out",
                    PaymentCashout = cashOutAmount
                };

                _db.DailySales.Add(sale);
                _db.SaveChanges();

                MessageBox.Show("Clock out completed and cash out recorded.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            else
            {
                MessageBox.Show("No cash denomination data found for today.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

            this.Close(); 
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class DeviceForm : Form
    {
        public static List<string> DefaultDeviceList { get; } = new List<string>
        {
                        "SIMO","Alcalter POP 4","Alcate Pixi 4","Alcatel 4G PIXI 4.5","Alcatel A3","Alcatel A3 XL 4G","Alcatel Onetouch 2036X","Alcatel Onetouch 2045","Alcatel Onetouch 2052",
            "Alcatel Onetouch PIXI 3","Alcatel Onetouch POP2 (4) 4G","Alcatel U3","Alcatel U5","Alcatel 1C","Alcatel 1 2019 4G","Alcatel 1B 2020 4G","Aspera Jazz2 4G","Aspera F24",
            "Aspera F26","Aspera F30","Aspera F40","Aspera F42","Aspera F46","Boost Luna","Doro 6520","Google Pixel 3A 64GB","Google Pixel 3 64GB","Google Pixel 3 XL 64GB","Google Pixel 3 64GB",
            "Google Pixel 3 128GB","Google Pixel 3 XL 128GB","GOOGLE PIXEL 4 BLACK 64GB","GOOGLE PIXEL 4 WHITE 64GB","GOOGLE PIXEL 4 XL BLACK 64GB","Google Pixel 5 128GB","Google Pixel 6 pro",
            "HMD Pulse+","HMD Pulse Pro 4G","HTC Desire 510","HTC Desire 530","HTC Desire 610","HTC Desire 650","HTC U Play","HTC U ULTRA","HTC U11","Huawei G8","Huawei Mate9",
            "Huawei Mate10","Huawei Mate10 Pro","Huawei Mate10 Porsche","Huawei Mate 20 Blk","Huawei Mate 20 Pro Blk","Huawei Nova2","Huawei Nova2 Lite","Huawei Nova3e",
            "Huawei Nova3i","Huawei Nova 5T","Huawei P9","Huawei P10","Huawei P20","Huawei P20 Pro","Huawei P30","Huawei P30 Pro","Huawei P30 lite","Huawei P40","Huawei Y6 Dual Sim",
            "Huawei Y6 Elite","Huawei Y635","Huawei Y5 2018","Huawei Y5 2019 dual","Huawei Y7","Huawei Y9 prime 2019","Honor X9a","Honor X9b","i5s 16GB space grey","i5s 64GB space grey",
            "i5s","i5C","i6","i6 64GB","i6s","i6s 32BLK","i6s 32Gold","i6 plus 64GB gold","i7 32GB blk","i7 32GB Gold","i7 32GB Pink","i7 32GB Wht","i7 Plus 32GB Blk","i7 Plus 32GB Gold",
            "i7 Plus 32GB Pink","i7 Plus 32GB Wht","i7 Plus 128G","i8 64GB Space Gray","i8 64GB Gold","i8 64GB Red","I8 64GB Sliver","i8 256GB Space Grey","i8 256GB Gold",
            "i8 256GB sliver","i8Plus 64GB Red","i8Plus 64GB Gold","i8Plus 64GB Sliver","i8Plus 64GB Space Gray","i8Plus 256GB Gold","I8Plus 256GB Space Grey","i8Plus256GB Silver",
            "i8Plus256GB Red","iPhone X 64GB Grey","iPhone X 64GB Silver","iPhone X 256GB Grey","iPhone X 256GB Silver","iPhone XS Max 64GB Silver","iPhone XS Max 64GB Gold","iPhone XS Max 64GB Grey",
            "iPhone XS Max 256GB Silver","iPhone XS Max 256GB Gold","iPhone XS Max 256GB Grey","iPhone XS Max 512GB Silver","iPhone XS Max 512GB Gold","iPhone XS Max 512GB Grey","iPhone XS 64GB Silver",
            "iPhone XS 64GB Gold","iPhone XS 64GB Grey","iPhone XS 256GB Silver","iPhone XS 256GB Gold","iPhone XS 256GB Grey","iPhone XS 512GB Silver","iPhone XS 512GB Gold","iPhone XS 512GB Grey","iPhone XR 64GB White","iPhone XR 64GB Red","iPhone XR 64GB Black","iPhone XR 64GB White",
            "iPhone XR 64GB Coral","iPhone XR 128GB White","iPhone XR 128GB Black","iPhone XR 128GB Red","iPhone XR 128GB Blue","iPhone XR 128GB Coral","iPhone XR 128GB Yellow","iPhone XR 256GB Coral","iPhone XR 256GB Red","iPhone XR 256GB White","iPhone XR 256GB","iPhone XR 256GB",
            "iPhone 11 64GB White","iPhone 11 64GB Red","iPhone 11 64GB Black","iPhone 11 64GB Green","iPhone 11 64GB Yellow","iPhone 11 64GB Purple","iPhone 11 128GB White","iPhone 11 128GB Red","iPhone 11 128GB Black","iPhone 11 128GB Green","iPhone 11 128GB Yellow","iPhone 11 128GB Purple",
            "iPhone 11 256GB White","iPhone 11 256GB Red","iPhone 11 256GB Black","iPhone 11 256GB Green","iPhone 11 256GB Yellow","iPhone 11 256GB Purple","iPhone 11 Pro 64GB Space Grey","iPhone 11 Pro 64GB Midnight Green","iPhone 11 Pro 64GB Gold","iPhone 11 Pro 64GB Silver","iPhone 11 Pro 256GB Space Grey",
            "iPhone 11 Pro 256GB Midnight Green","iPhone 11 Pro 256GB Gold","iPhone 11 Pro 256GB Silver","iPhone 11 Pro 512GB Space Grey","iPhone 11 Pro 512GB Midnight Green","iPhone 11 Pro 512GB Gold","iPhone 11 Pro 512GB Silver","iPhone 11 Pro Max 64GB Space Grey","iPhone 11 Pro Max 64GB Midnight Green",
            "iPhone 11 Pro Max 64GB Gold","iPhone 11 Pro Max 64GB Silver","iPhone 11 Pro Max 256GB Space Grey","iPhone 11 Pro Max 256GB Midnight Green","iPhone 11 Pro Max 256GB Gold","iPhone 11 Pro Max 256GB Silver",
            "iPhone 11 Pro Max 512GB Space Grey","iPhone 11 Pro Max 512GB Midnight Green","iPhone 11 Pro Max 512GB Gold","iPhone 11 Pro Max 512GB Silver","iphone 12 Mini 64GB","iphone 12 Mini 128GB","iphone 12 Mini 256GB",
            "iphone 12 64GB","iphone 12 128GB","iphone 12 256GB","iphone 12 Pro 128GB","iphone 12 Pro 256GB","iphone 12 Pro 512GB","iphone 12 Pro Max 128GB","iphone 12 Pro Max 256GB","iphone 12 Pro Max 512GB","iphone 13 Mini 128GB","iphone 13 Mini 256GB","iphone 13 Mini 512GB","iphone 13 128GB",
            "iphone 13 256GB","iphone 13 512GB","iphone 13 Pro 128GB","iphone 13 Pro 256GB","iphone 13 Pro 512GB","iphone 13 Pro 1TB","iphone 13 Pro Max 128GB","iphone 13 Pro Max 256GB","iphone 13 Pro Max 512GB","iphone 13 Pro Max 1TB","iphone 14 128GB","iphone 14 256GB","iphone 14 512GB",
            "iphone 14 plus 128GB","iphone 14 plus 256GB","iphone 14 plus 512GB","iphone 14 pro 128GB","iphone 14 pro 256GB","iphone 14 pro 512GB","iphone 14 pro 1GB","iphone 14 pro max 128GB","iphone 14 pro max 256GB","iphone 14 pro max 512GB","iphone 14 pro max 1TB","iphone 15 128GB",
            "iphone 15 256GB","iphone 15 512GB","iphone 15 plus 128GB","iphone 15 plus 256GB","iphone 15 plus 512GB","iphone 15 pro 256GB","iphone 15 pro 512GB","iphone 15 pro 1T","iphone 15 pro max 256GB","iphone 15 pro max 512GB",
            "iphone 15 pro max 1T","iphone 16E 128GB","iphone 16E 256GB","iphone 16E 512GB","iphone 16 128GB","iphone 16 256GB","iphone 16 512GB","iphone 16 plus 128GB","iphone 16 plus 256GB","iphone 16 plus 512GB","iphone 16 pro 128GB","iphone 16 pro 256GB","iphone 16 pro 512GB","iphone 16 pro 1T","iphone 16 pro max 256GB","iphone 16 pro max 512GB","iphone 16 pro max 1T",
            "iPhone SE 64GB","iPhone SE 128GB","iPhone SE 256GB","ipad 32GB BLK","ipad 128GB BLK","ipad 6G 32GB","ipad 6G 128GB","ipad 256GB","iPad Mini Retina 32GB","Ipad Mini4 64GB Gold","Ipad air 64GB","iPad air 128GB","iPad air 256GB","iPad air 512","Ipad Pro 10.5inch 64GB","Ipad Pro 10.5inch 256GB","Ipad Pro 11 64GB","Ipad Pro 11 256GB","Ipad Pro 11 512GB","Ipad Pro 12.9inch 64GB","Ipad Pro 12.9inch 128GB",
            "Ipad Pro 12.9inch 256GB","Ipad Pro 128GB 9.7inch pink","iPad Wifi+Cel Sil","Internet - ADSL2+","Internet - FTTB","Internet - Landline + ADSL2+","Internet - Naked DSL","Internet - NBN","Internet - VDSL","Italk bb Internet+Phone","Italk bb Internet+Phone+TV","Italk bb Phone","Italk bb tv pad","KONKA KU9","Kosumi 3G","LG K42 4G","LG Velvet 5G","Meizu M6 Black",
            "Meizu M6 Gold","Motorola G 5g plus","Motorola E7","Motorola g8","Motorola g10","Motorola G14","Motorola G34 5G","Motorola G35 5G","Motorola E13","Motorola E22I GERY 4G","Motorola E32 4G","Moto edge 50 Fusion","MBB - HUAWEI Mobile Wifi","MBB - Optus USB 3G","MBB - Optus USB 4G","MBB - Optus Wifi 3G","MBB - Optus Wifi 4G","MBB - Telstra 3G USB","MBB - Telstra 3G WIFI MF65 WHITE",
            "MBB - Telstra 4G USB","MBB - Telstra 4G WIFI","MBB - VF Pocket Wifi 3G","MBB - VF Pocket Wifi 4G","MBB - VF Pocket Wifi 5 M7350 4G","MBB - VF USB 3G","MBB - VF USB 4G","MBB- Telstra 4G USB+WIFI","MBB - ZTE unlock wifi","MobiWire Sakari 3G","Nokia C01 plus","Nokia G20","Nokia 1.4","Nokia 3","Nokia 3.4","Nokia 2660 Flip","Nokia 3310","Nokia 2720 FLIP","Opel Flip 6",
            "OPPO A15","OPPO A16s","OPPO A38","OPPO A52","OPPO A53","OPPO A57 Blk","OPPO A57 Gold","OPPO A60 5G","OPPO A60 4G","OPPO A73 Gold","OPPO A73 Black","OPPO A74","OPPO A80 5G","OPPO A91","OPPO AX5 Blue","OPPO AX5 Pink","OPPO AX5s Red","OPPO AX5s Black","OPPO AX7","OPPO R11","OPPO R11s","OPPO R15 Pro","OPPO R15","OPPO R17 Pro Green","OPPO R9s","OPPO Reno 2Z",
            "OPPO RENO8 5G","OPPO RenoZ","OPPO Find X2 Lite 5G","OPPO Find X5","Optus X Lite","Optus X Sleek","Optus X Smart","Optus X Play","Optus X Swift 5G","Redmi 9A 64GB","Redmi Note8 64 GB","Realme C3",
            "Realme C11","Sakari 3G","SAM Galaxy A3","SAM Galaxy A5","SAM Galaxy A8","SAM Galaxy A16","SAM Galaxy Ace3","SAM Galaxy Core Prime","SAM Galaxy Tab A9+","SAM Galaxy Tab A8","SAM Galaxy Tab S2","SAM Galaxy Tab S4 64GB",
            "SAM Galaxy Z Flip","SAM Galaxy Z Flip 3","SAM Galaxy Z Flip 4","SAM Galaxy Z Flip 5","SAM Galaxy Z Flip 6","SAM Galaxy Z Fold 2","SAM Galaxy Z Fold 3","SAM Galaxy Z Fold 4","SAM Galaxy Z Fold 5","SAM Galaxy Z Fold 6",
            "SAM A05s","SAM A11","SAM A12","SAM A13","SAM A14","SAM A15","SAM A20","SAM A21s","SAM A22 5G","SAM A23","SAM A30","SAM A32","SAM A33","SAM A34","SAM A35","SAM A50","SAM A51","SAM A52","SAM A52B",
            "SAM A53","SAM A54","SAM A55","SAM A56","SAM A71 5G","SAM A73","SAM J1 Mini","SAM J3","SAM J2 Pro","SAM J5 Pro","SAM S5 16GB","SAM S5 16GB GOLD","SAM S7 Blk 32GB","SAM S7 Gold 32GB","SAM S7 Sliver 32GB",
            "SAM S8 BLK","SAM S8 Gold","SAM S8 Grey","SAM S8+ blk","SAM S8+ Gold","SAM S8+ Grey","Sam S9 64GB Blk","Sam S9 64GB Blu","Sam S9 64GB Pur","Sam S9 64GB Gold","Sam S9 256GB Blk","Sam S9+ 64GB Gold","Sam S9+ 64GB Blk","Sam S9+ 64GB Blu","Sam S9+ 64GB Pur",
            "Sam S9+ 256GB Blk","Sam S10E 128GB Prism Green","Sam S10E 128GB Prism White","Sam S10E 128GB Prism Black","Sam S10 128GB Prism Green","Sam S10 128GB Prism White","Sam S10 128GB Prism Black","Sam S10 512GB Prism Green","Sam S10 512GB Prism White", "Sam S10 512GB Prism Black","Sam S10+ 128GB Prism Green","Sam S10+ 128GB Prism White","Sam S10+ 128GB Prism Black",
            "Sam S10+ 512GB Prism Green","Sam S10+ 512GB Prism White","Sam S10+ 512GB Prism Black","Sam S20 128GB","Sam S20+ 128GB","Sam S20 Ultra 128GB","Sam S20 FE 128G","Sam S21","Sam S21 Plus","Sam S21 Ultra","Sam S21 FE","Sam S22","Sam S22 +","Sam S22 Ultra","Sam S23","Sam S23 +","Sam S23 Ultra","Sam S24","Sam S24 +","Sam S24 Ultra",
            "Sam S25","Sam S25 +","Sam S25 Ultra","Sam S25 Edge","SAM Note8 Blk","SAM Note8 Gold","SAM Note 9 Blk","SAM Note 9 Blue","SAM Note 10","SAM Note 10+","SAM Note 20","SAM Note 20 Ultra 5G","Sam Tab","Sam Tab A8","Sim pack","Sim pack Optus $10","Sim pack Optus $30","Sim pack Optus $40","Sim pack Optus $50","Sim pack Voda $29 mbb",
            "Sim pack Voda $10","Sim pack Voda $30","Sim pack Voda $40","Sim pack Voda $50","Sim pack Voda $150","Sim pack Voda $250","Sim pack Lebara $14.9","Sim pack Lebara $29.9","Sim pack Lebara $39.9","Sim pack Lebara $45","Sony Xperia XA","Sony Xperia XA1 Ultra","Sony Xperia XZ Premium","TCL 20B","TCL 20R 5G","TCL 20 Pro 5G",
            "TCL 30 SE","TCL 305","TCL 306","Telstra Tempo","Telstra 4GX","Telstra 4GX HD","Telstra 4GX Premium","Telstra Cruise","Telstra essential pro 3","Telstra Easy Call 4","Telstra essential- tab","Telstra essential- tab Plus","Telstra Flip","Telstra Lite","Telstra Lite Smart","Telstra Plues","Telstra 4GX Wifi","Telstra Smart Plus",
            "TV Box - HTV 5","TV Box - HomeX","VF Smart 4 mini","VF Smart A9","VF C9","VF E9","VF Smart mini 7","VF V Pro 4G","VF V ONE","VF 4G Home wireless","VF 5G HOME wireless","VF Wifi HUB","VF Wifi Tp-link","ZTE Blitz","ZTE Cruise","ZTE Smart E8","ZTE Smart first 7 3G","ZTE Zip 4G","Beats Pill+","Apple Airpods Pro","Apple Airpods",
            "Apple Airpods 3","Apple Watch","Samsung Watch","Huawei Watch","Huawei WIFI CUBE","Nokia 5G gateway 3.2"
        };

        private ListBox lstDevices;
        private TextBox txtNewDevice;
        private Button btnAdd, btnDelete, btnClose;
        private readonly AppDbContext db;

        public DeviceForm()
        {
            InitializeComponent();
            db = new AppDbContext();
            SetupLayout();
        }

        private void SetupLayout()
        {
            this.Text = "Manage Devices";
            this.Width = 800;
            this.Height = 600;

            lstDevices = new ListBox { Dock = DockStyle.Top, Height = 425 };

            try
            {
                // Load device list from DB
                var current = db.Devices.Select(d => d.Name).ToList();

                if (!current.Any())
                {
                    // Insert only non-duplicate, non-null, trimmed values (up to 255 chars)
                    var validDefaults = DefaultDeviceList
                        .Where(name => !string.IsNullOrWhiteSpace(name) && name.Trim().Length <= 255)
                        .Distinct()
                        .Except(db.Devices.Select(d => d.Name))
                        .Select(name => new Device { Name = name.Trim() })
                        .ToList();

                    db.Devices.AddRange(validDefaults);
                    db.SaveChanges();

                    current = db.Devices.Select(d => d.Name).ToList();
                }

                lstDevices.Items.AddRange(current.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading device list: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            txtNewDevice = new TextBox { Dock = DockStyle.Top, PlaceholderText = "Enter new device..." };

            btnAdd = new Button { Text = "Add Device", Dock = DockStyle.Top, Height = 35 };
            btnAdd.Click += (s, e) =>
            {
                var name = txtNewDevice.Text.Trim();
                if (!string.IsNullOrWhiteSpace(name) && name.Length <= 255)
                {
                    if (!db.Devices.Any(x => x.Name == name))
                    {
                        db.Devices.Add(new Device { Name = name });
                        try
                        {
                            db.SaveChanges();
                            lstDevices.Items.Add(name);
                            txtNewDevice.Clear();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error saving new device: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Device already exists.");
                    }
                }
            };

            btnDelete = new Button { Text = "Delete Selected", Dock = DockStyle.Top, Height = 35 };
            btnDelete.Click += (s, e) =>
            {
                if (lstDevices.SelectedItem != null)
                {
                    string selected = lstDevices.SelectedItem.ToString();
                    var entry = db.Devices.FirstOrDefault(x => x.Name == selected);
                    if (entry != null)
                    {
                        db.Devices.Remove(entry);
                        try
                        {
                            db.SaveChanges();
                            lstDevices.Items.Remove(selected);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error deleting device: " + ex.Message, "Database Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            };

            btnClose = new Button { Text = "Close", Dock = DockStyle.Bottom, Height = 35 };
            btnClose.Click += (s, e) => this.Close();

            this.Controls.AddRange(new Control[] { btnClose, btnDelete, btnAdd, txtNewDevice, lstDevices });
        }
    }
}

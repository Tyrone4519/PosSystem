﻿// MainForm.cs
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Forms;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class MainForm : Form
    {
        private Panel mainPanel;
        private Label userInfoLabel;
        private string currentUsername = null;
        private Staff currentStaff = null;
        private Button clockBtn;
        private Button loginBtn;
        private readonly AppDbContext db;

        public MainForm()
        {
            InitializeComponent();
            db = DbContextHelper.GetContext();
            CustomizeLayout();
        }

        private void CustomizeLayout()
        {
            this.Text = "Chinatown Mobile POS";
            this.WindowState = FormWindowState.Maximized;
            this.BackColor = Color.FromArgb(96, 24, 24);

            var topPanel = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = Color.FromArgb(64, 16, 16)
            };

            var titleLabel = new Label
            {
                Text = "Chinatown Mobile POS",
                Font = new Font("Georgia", 22, FontStyle.Bold),
                ForeColor = Color.Gold,
                AutoSize = true,
                Location = new Point(40, 10)
            };

            userInfoLabel = new Label
            {
                Text = "You need to login",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                ForeColor = Color.LightGoldenrodYellow,
                AutoSize = true,
                TextAlign = ContentAlignment.MiddleRight,
                Anchor = AnchorStyles.Top | AnchorStyles.Right,
                Location = new Point(topPanel.Width - 180, 20)
            };

            topPanel.Resize += (s, e) =>
            {
                userInfoLabel.Location = new Point(topPanel.Width - userInfoLabel.Width - 30, 20);
            };

            topPanel.Controls.Add(titleLabel);
            topPanel.Controls.Add(userInfoLabel);
            this.Controls.Add(topPanel);

            var leftPanel = new Panel
            {
                Dock = DockStyle.Left,
                Width = 180,
                BackColor = Color.FromArgb(80, 20, 20)
            };

            var navPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                Padding = new Padding(10, 70, 10, 10),
                AutoScroll = true
            };

            loginBtn = CreateStyledButton("Login", Color.DarkGoldenrod);
            loginBtn.Click += LoginOrLogout;
            navPanel.Controls.Add(loginBtn);

            string[] buttonNames = new[]
            {
                "Daily Sales", "Contract", "Daily Task", "Stock List",
                "Prepaid Stock", "Repair", "Invoice", "Time Table",
                "Staff", "Report"
            };

            foreach (var name in buttonNames)
            {
                var navBtn = CreateStyledButton(name, Color.FromArgb(160, 40, 40));
                navBtn.Click += (s, e) => LoadModule(name);
                navPanel.Controls.Add(navBtn);
            }

            clockBtn = CreateStyledButton("Clock Out", Color.Goldenrod);
            clockBtn.ForeColor = Color.Maroon;
            clockBtn.Click += (s, e) => HandleClock();
            navPanel.Controls.Add(clockBtn);

            leftPanel.Controls.Add(navPanel);
            this.Controls.Add(leftPanel);

            mainPanel = new Panel
            {
                Name = "MainContentPanel",
                Dock = DockStyle.Fill,
                BackColor = Color.White
            };
            this.Controls.Add(mainPanel);
        }

        private void LoginOrLogout(object sender, EventArgs e)
        {
            if (currentStaff == null)
            {
                var loginForm = new LoginForm();
                if (loginForm.ShowDialog() == DialogResult.OK)
                {
                    currentUsername = loginForm.LoggedInUser;
                    currentStaff = loginForm.LoggedInStaff;
                    userInfoLabel.Text = $"Hi, {currentStaff.StaffName}";
                    userInfoLabel.ForeColor = Color.Gold;
                    loginBtn.Text = "Logout";
                }
            }
            else
            {
                var confirm = MessageBox.Show("Are you sure you want to logout?", "Logout", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (confirm == DialogResult.Yes)
                {
                    currentUsername = null;
                    currentStaff = null;
                    userInfoLabel.Text = "Welcome, Guest";
                    userInfoLabel.ForeColor = Color.LightGoldenrodYellow;
                    loginBtn.Text = "Login";
                }
            }
        }

        private Button CreateStyledButton(string text, Color backColor)
        {
            return new Button
            {
                Text = text,
                Width = 160,
                Height = 36,
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                FlatAppearance = { BorderSize = 0 },
                Margin = new Padding(4)
            };
        }

        private void LoadModule(string moduleName)
        {
            mainPanel.Controls.Clear();

            Form formToLoad = moduleName switch
            {
                "Daily Sales" => new DailySaleForm(),
                "Contract" => new ContractForm(),
                "Daily Task" => new DailyTaskForm(),
                "Stock List" => new StockListForm(),
                "Prepaid Stock" => new PrepaidStockForm(),
                "Repair" => new RepairForm(),
                "Invoice" => new InvoiceForm(),
                "Time Table" => new TimeTableForm(),
                "Staff" => new StaffForm(),
                "Report" => new ReportForm(),
                _ => new LabelForm("Unknown module")
            };

            formToLoad.TopLevel = false;
            formToLoad.FormBorderStyle = FormBorderStyle.None;
            formToLoad.Dock = DockStyle.Fill;

            mainPanel.Controls.Add(formToLoad);
            formToLoad.Show();
        }

        private void HandleClock()
        {
            if (currentStaff == null)
            {
                MessageBox.Show("Please login first.");
                return;
            }

            var form = new ClockInOutForm(currentStaff);
            form.ShowDialog();
        }
    }

    public class LabelForm : Form
    {
        public LabelForm(string message)
        {
            this.BackColor = Color.White;
            Label lbl = new Label
            {
                Text = message,
                AutoSize = true,
                Font = new Font("Segoe UI", 14),
                Location = new Point(30, 30)
            };
            this.Controls.Add(lbl);
        }
    }
}

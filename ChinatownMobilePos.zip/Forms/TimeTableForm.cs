﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Models;
using ChinatownMobilePos.Data;
using Microsoft.EntityFrameworkCore;
using ClosedXML.Excel;

namespace ChinatownMobilePos.Forms
{
    public partial class TimeTableForm : Form
    {
        private readonly AppDbContext _context;

        private ComboBox cmbStaff, cmbStart, cmbEnd, cmbFilterStaff;
        private DateTimePicker datePicker, dateFilterPicker;
        private TextBox txtNote;
        private CheckBox chkIsPaid;
        private Button btnAdd, btnUpdate, btnDelete, btnExport, btnFilter;
        private DataGridView dgv;
        private BindingList<WorkSchedule> scheduleList = new();
        private bool isFiltering = false;

        public TimeTableForm()
        {
            InitializeComponent();
            _context = new AppDbContext();
            SetupLayout();
            LoadSchedules();
        }

        private void SetupLayout()
        {
            // === unified background ===
            this.BackColor = Color.FromArgb(245, 239, 220);

            // === outer padding panel ===
            var offsetPanel = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(200, 80, 40, 40)
            };
            this.Controls.Add(offsetPanel);

            // === root layout ===
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2
            };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 400));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            offsetPanel.Controls.Add(mainLayout);

            // === left form panel ===
            var leftPanel = new TableLayoutPanel
            {
                RowCount = 1,
                ColumnCount = 2,
                AutoSize = true,
                Dock = DockStyle.Top
            };
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 130));
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            // === button row ===
            var buttonPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true };

            Font btnFont = new Font("Segoe UI", 9F, FontStyle.Bold);
            Color btnColor = Color.DarkGoldenrod;
            Color textColor = Color.White;

            btnAdd = new Button { Text = "Add", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnUpdate = new Button { Text = "Update", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnDelete = new Button { Text = "Delete", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnExport = new Button { Text = "Export", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };

            btnAdd.Click += BtnAdd_Click;
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete.Click += BtnDelete_Click;
            btnExport.Click += BtnExport_Click;

            buttonPanel.Controls.AddRange(new[] { btnAdd, btnUpdate, btnDelete, btnExport });
            leftPanel.Controls.Add(buttonPanel);
            leftPanel.SetColumnSpan(buttonPanel, 2);
            leftPanel.RowCount++;

            // === entry fields ===
            var timeOptions = Enumerable.Range(-2, 21)
                                        .Select(i => TimeSpan.FromMinutes(11 * 60 + 30 * i).ToString(@"hh\:mm"))
                                        .ToArray();

            cmbStaff = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStaff.Items.AddRange(_context.Staffs.Select(s => s.StaffName).ToArray());

            datePicker = new DateTimePicker { Format = DateTimePickerFormat.Short };

            cmbStart = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStart.Items.AddRange(timeOptions);

            cmbEnd = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbEnd.Items.AddRange(timeOptions);

            txtNote = new TextBox();
            chkIsPaid = new CheckBox { Text = "Is Paid" };

            void AddRow(string label, Control ctrl)
            {
                ctrl.Dock = DockStyle.Fill;
                ctrl.Margin = new Padding(3, 5, 3, 5);
                leftPanel.Controls.Add(new Label
                {
                    Text = label,
                    TextAlign = ContentAlignment.MiddleRight,
                    Dock = DockStyle.Fill
                }, 0, leftPanel.RowCount - 1);
                leftPanel.Controls.Add(ctrl, 1, leftPanel.RowCount - 1);
                leftPanel.RowCount++;
            }

            AddRow("Staff:", cmbStaff);
            AddRow("Date:", datePicker);
            AddRow("Start:", cmbStart);
            AddRow("End:", cmbEnd);
            AddRow("Note:", txtNote);
            AddRow("", chkIsPaid);

            // === filter button ===
            btnFilter = new Button
            {
                Text = "Filter",
                Height = 40,
                BackColor = btnColor,
                ForeColor = textColor,
                Font = btnFont
            };
            btnFilter.Click += (s, e) => { isFiltering = true; LoadSchedules(); };
            leftPanel.Controls.Add(btnFilter);
            leftPanel.SetColumnSpan(btnFilter, 2);
            leftPanel.RowCount++;

            // === filter controls ===
            cmbFilterStaff = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbFilterStaff.Items.Add("All");
            cmbFilterStaff.Items.AddRange(_context.Staffs.Select(s => s.StaffName).ToArray());
            cmbFilterStaff.SelectedIndex = 0;

            dateFilterPicker = new DateTimePicker { Format = DateTimePickerFormat.Short, ShowCheckBox = true };

            AddRow("Filter Staff:", cmbFilterStaff);
            AddRow("Filter Date:", dateFilterPicker);

            mainLayout.Controls.Add(leftPanel, 0, 0);

            // === data grid ===
            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                ScrollBars = ScrollBars.Both
            };
            dgv.AutoGenerateColumns = true;
            dgv.CellClick += Dgv_CellClick;
            mainLayout.Controls.Add(dgv, 1, 0);
        }

        // ---------------- data loading ----------------
        private void LoadSchedules()
        {
            var query = _context.WorkSchedules.AsQueryable();

            if (isFiltering)
            {
                if (cmbFilterStaff.SelectedItem?.ToString() != "All")
                    query = query.Where(s => s.StaffName == cmbFilterStaff.SelectedItem.ToString());

                if (dateFilterPicker.Checked)
                {
                    var filterDate = dateFilterPicker.Value.Date;
                    query = query.Where(s => s.Date.Date == filterDate);
                }
            }

            var list = query
                .OrderByDescending(s => s.Date)
                .ThenBy(s => s.StaffName)
                .ToList();

            scheduleList = new BindingList<WorkSchedule>(list);
            dgv.DataSource = scheduleList;
        }

        // ---------------- CRUD events ----------------
        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var schedule = CreateScheduleFromInputs();
            _context.WorkSchedules.Add(schedule);
            _context.SaveChanges();
            isFiltering = false;
            LoadSchedules();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            var selected = (WorkSchedule)dgv.SelectedRows[0].DataBoundItem;
            var schedule = _context.WorkSchedules.Find(selected.Id);
            if (schedule == null) return;

            UpdateScheduleFromInputs(schedule);
            _context.SaveChanges();
            isFiltering = false;
            LoadSchedules();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            var selected = (WorkSchedule)dgv.SelectedRows[0].DataBoundItem;
            var schedule = _context.WorkSchedules.Find(selected.Id);
            if (schedule == null) return;

            _context.WorkSchedules.Remove(schedule);
            _context.SaveChanges();
            isFiltering = false;
            LoadSchedules();
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("TimeTable");
            ws.Cell(1, 1).InsertTable(scheduleList);

            using var dlg = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() == DialogResult.OK)
                workbook.SaveAs(dlg.FileName);
        }

        // ---------------- helper methods ----------------
        private WorkSchedule CreateScheduleFromInputs()
        {
            var schedule = new WorkSchedule
            {
                StaffName = cmbStaff.SelectedItem?.ToString(),
                Date = datePicker.Value.Date,
                StartTime = TimeSpan.Parse(cmbStart.SelectedItem.ToString()),
                EndTime = TimeSpan.Parse(cmbEnd.SelectedItem.ToString()),
                Note = txtNote.Text,
                IsPaid = chkIsPaid.Checked
            };

            schedule.WorkHours = (decimal)(schedule.EndTime - schedule.StartTime).TotalHours;
            var staff = _context.Staffs.FirstOrDefault(s => s.StaffName == schedule.StaffName);
            schedule.HourlyRate = staff?.HourlyRate ?? 0;
            schedule.WageAmount = schedule.HourlyRate * schedule.WorkHours;
            return schedule;
        }

        private void UpdateScheduleFromInputs(WorkSchedule schedule)
        {
            schedule.StaffName = cmbStaff.SelectedItem?.ToString();
            schedule.Date = datePicker.Value.Date;
            schedule.StartTime = TimeSpan.Parse(cmbStart.SelectedItem.ToString());
            schedule.EndTime = TimeSpan.Parse(cmbEnd.SelectedItem.ToString());
            schedule.Note = txtNote.Text;
            schedule.IsPaid = chkIsPaid.Checked;

            schedule.WorkHours = (decimal)(schedule.EndTime - schedule.StartTime).TotalHours;
            var staff = _context.Staffs.FirstOrDefault(s => s.StaffName == schedule.StaffName);
            schedule.HourlyRate = staff?.HourlyRate ?? 0;
            schedule.WageAmount = schedule.HourlyRate * schedule.WorkHours;
        }

        // ---------------- grid click ----------------
        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var selected = (WorkSchedule)dgv.Rows[e.RowIndex].DataBoundItem;

            cmbStaff.SelectedItem = selected.StaffName;
            datePicker.Value = selected.Date;
            cmbStart.SelectedItem = selected.StartTime.ToString(@"hh\:mm");
            cmbEnd.SelectedItem = selected.EndTime.ToString(@"hh\:mm");
            txtNote.Text = selected.Note;
            chkIsPaid.Checked = selected.IsPaid;
        }
    }
}

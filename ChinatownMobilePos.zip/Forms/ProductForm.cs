﻿using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;

namespace ChinatownMobilePos.Forms
{
    public partial class ProductForm : Form
    {
        private readonly AppDbContext db;
        private ComboBox cmbProductType;
        private TextBox txtProductName;
        private NumericUpDown numPrice;
        private Button btnAdd, btnDelete, btnUpdate;
        private ListBox listBox;

        public ProductForm()
        {
            db = DbContextHelper.GetContext();
            this.Text = "Products";
            this.Size = new Size(1200, 900);
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeLayout();
            LoadProductTypes();
        }

        private void InitializeLayout()
        {
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                RowCount = 3,
                ColumnCount = 1
            };

            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));

            listBox = new ListBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F)
            };
            listBox.SelectedIndexChanged += OnListItemSelected;
            mainLayout.Controls.Add(listBox, 0, 0);

            var inputLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 3,
                ColumnCount = 2,
                Padding = new Padding(0, 10, 0, 10)
            };

            inputLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            inputLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            inputLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 33));
            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            inputLayout.Controls.Add(new Label { Text = "PT:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            cmbProductType = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            cmbProductType.SelectedIndexChanged += (s, e) => LoadProducts();
            inputLayout.Controls.Add(cmbProductType, 1, 0);

            inputLayout.Controls.Add(new Label { Text = "Product:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            txtProductName = new TextBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F)
            };
            inputLayout.Controls.Add(txtProductName, 1, 1);

            inputLayout.Controls.Add(new Label { Text = "Price ($):", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 2);
            numPrice = new NumericUpDown
            {
                DecimalPlaces = 2,
                Maximum = 10000,
                Minimum = 0,
                Increment = 0.5M,
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F)
            };
            inputLayout.Controls.Add(numPrice, 1, 2);

            mainLayout.Controls.Add(inputLayout, 0, 1);

            var buttonPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                Dock = DockStyle.Fill,
                Padding = new Padding(0, 5, 0, 5),
                Height = 50
            };

            btnAdd = new Button { Text = "Add", Width = 90, Height = 40, BackColor = Color.SeaGreen, ForeColor = Color.White };
            btnAdd.Click += AddProduct;
            buttonPanel.Controls.Add(btnAdd);

            btnUpdate = new Button { Text = "Update", Width = 90, Height = 40, BackColor = Color.DodgerBlue, ForeColor = Color.White };
            btnUpdate.Click += UpdateProduct;
            buttonPanel.Controls.Add(btnUpdate);

            btnDelete = new Button { Text = "Delete", Width = 90, Height = 40, BackColor = Color.IndianRed, ForeColor = Color.White };
            btnDelete.Click += DeleteProduct;
            buttonPanel.Controls.Add(btnDelete);

            mainLayout.Controls.Add(buttonPanel, 0, 2);
            this.Controls.Add(mainLayout);
        }

        private void LoadProductTypes()
        {
            cmbProductType.Items.Clear();

            var types = db.ProductTypes
                .OrderBy(p => p.Name)
                .Select(p => new { p.Id, p.Name })
                .ToList();

            foreach (var t in types)
            {
                cmbProductType.Items.Add(new ComboBoxItem { Id = t.Id, Display = t.Name });
            }

            if (cmbProductType.Items.Count > 0)
                cmbProductType.SelectedIndex = 0;
        }

        private void LoadProducts()
        {
            listBox.Items.Clear();

            if (cmbProductType.SelectedItem is not ComboBoxItem selectedType)
                return;

            var products = db.Products
                .Where(p => p.ProductTypeId == selectedType.Id)
                .Include(p => p.ProductType)
                .OrderBy(p => p.Name)
                .ToList();

            foreach (var product in products)
            {
                listBox.Items.Add(new ProductDisplayItem
                {
                    Product = product,
                    Display = $"{product.Name} ({product.ProductType?.Name})"
                });
            }

            listBox.DisplayMember = "Display";
        }

        private void AddProduct(object sender, EventArgs e)
        {
            if (cmbProductType.SelectedItem is not ComboBoxItem selectedType)
            {
                MessageBox.Show("Please select a product type.");
                return;
            }

            string name = txtProductName.Text.Trim();
            decimal price = numPrice.Value;

            if (string.IsNullOrEmpty(name))
            {
                MessageBox.Show("Please enter a product name.");
                return;
            }

            if (db.Products.Any(p => p.Name == name && p.ProductTypeId == selectedType.Id))
            {
                MessageBox.Show("This product already exists.");
                return;
            }

            db.Products.Add(new Product
            {
                Name = name,
                ProductTypeId = selectedType.Id,
                Price = price
            });
            db.SaveChanges();
            LoadProducts();

            txtProductName.Clear();
            numPrice.Value = 0;
        }

        private void UpdateProduct(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is not ProductDisplayItem item || item.Product == null)
            {
                MessageBox.Show("Please select a product to update.");
                return;
            }

            string newName = txtProductName.Text.Trim();
            decimal newPrice = numPrice.Value;

            if (string.IsNullOrWhiteSpace(newName))
            {
                MessageBox.Show("Please enter a new name.");
                return;
            }

            if (db.Products.Any(p => p.Name == newName && p.ProductTypeId == item.Product.ProductTypeId && p.Id != item.Product.Id))
            {
                MessageBox.Show("Another product with the same name already exists.");
                return;
            }

            item.Product.Name = newName;
            item.Product.Price = newPrice;
            db.SaveChanges();
            LoadProducts();

            txtProductName.Clear();
            numPrice.Value = 0;
        }

        private void DeleteProduct(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is not ProductDisplayItem item || item.Product == null)
            {
                MessageBox.Show("Please select a product to delete.");
                return;
            }

            db.Products.Remove(item.Product);
            db.SaveChanges();
            LoadProducts();
        }

        private void OnListItemSelected(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is not ProductDisplayItem item || item.Product == null) return;

            txtProductName.Text = item.Product.Name;
            numPrice.Value = item.Product.Price;
        }

        private class ComboBoxItem
        {
            public int Id { get; set; }
            public string Display { get; set; }
            public override string ToString() => Display;
        }

        private class ProductDisplayItem
        {
            public Product Product { get; set; }
            public string Display { get; set; }
        }
    }
}

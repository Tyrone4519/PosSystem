﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Models;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Helpers;

namespace ChinatownMobilePos.Forms
{
    public partial class PrepaidStockForm : Form
    {
        private TableLayoutPanel brandLayoutPanel;
        private Button btnSave;
        private Button btnAddBrand;
        private Dictionary<string, BindingList<PrepaidStarterPack>> brandDataMap = new();

        public PrepaidStockForm()
        {
            InitializeComponent();
            InitializeLayout();
            LoadData();
        }

        private void InitializeLayout()
        {
            this.Text = "Prepaid Stock Management";
            this.BackColor = Color.FromArgb(245, 239, 220);

            Panel horizontalScrollWrapper = new Panel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                AutoScrollMinSize = new Size(2000, 0),
                BackColor = Color.FromArgb(245, 239, 220)
            };
            this.Controls.Add(horizontalScrollWrapper);

            Panel mainScrollPanel = new Panel
            {
                Dock = DockStyle.Top,
                AutoScroll = true,
                AutoSize = true,
                BackColor = Color.FromArgb(245, 239, 220)
            };
            horizontalScrollWrapper.Controls.Add(mainScrollPanel);

            Panel offsetPanel = new Panel
            {
                Dock = DockStyle.Top,
                Padding = new Padding(200, 60, 40, 40),
                BackColor = Color.FromArgb(245, 239, 220),
                AutoSize = true
            };
            mainScrollPanel.Controls.Add(offsetPanel);

            btnAddBrand = new Button
            {
                Text = "+ Add Brand",
                Height = 35,
                Width = 120,
                Dock = DockStyle.Top,
                BackColor = Color.DarkGoldenrod,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold),
                Margin = new Padding(10)
            };
            btnAddBrand.Click += (s, e) => AddNewBrandPanel(null);

            btnSave = new Button
            {
                Text = "Save All Changes",
                Height = 40,
                Dock = DockStyle.Bottom,
                BackColor = Color.DarkGoldenrod,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9F, FontStyle.Bold)
            };
            btnSave.Click += SaveChanges_Click;

            brandLayoutPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 3,
                AutoSize = true,
                BackColor = Color.FromArgb(245, 239, 220)
            };

            for (int i = 0; i < 3; i++)
                brandLayoutPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.33f));

            offsetPanel.Controls.Add(btnAddBrand);
            offsetPanel.Controls.Add(brandLayoutPanel);
            mainScrollPanel.Controls.Add(btnSave);
        }

        private void LoadData()
        {
            brandLayoutPanel.Controls.Clear();
            brandDataMap.Clear();

            using var db = AppDbContextFactory.CreateDbContext();
            var allData = db.PrepaidStarterPacks.ToList();

            var brandGroups = allData
                .Where(x => !string.IsNullOrWhiteSpace(x.Brand))
                .GroupBy(x => x.Brand);

            foreach (var brandGroup in brandGroups)
            {
                string brand = brandGroup.Key;
                var list = new BindingList<PrepaidStarterPack>(brandGroup.ToList());
                brandDataMap[brand] = list;

                AddNewBrandPanel(brand, list);
            }
        }

        private void AddNewBrandPanel(string? brand, BindingList<PrepaidStarterPack>? packList = null)
        {
            if (packList == null)
                packList = new BindingList<PrepaidStarterPack>();

            Panel panel = new Panel
            {
                Width = 400,
                Height = 320,
                BorderStyle = BorderStyle.FixedSingle,
                Margin = new Padding(15),
                BackColor = Color.White
            };

            Label brandLabel = new Label
            {
                Text = "Brand:",
                Font = new Font("Segoe UI", 10, FontStyle.Bold),
                Location = new Point(10, 10),
                AutoSize = true
            };

            TextBox brandTextBox = new TextBox
            {
                Text = brand ?? string.Empty,
                Font = new Font("Segoe UI", 10),
                Location = new Point(85, 7),
                Width = 250
            };

            DataGridView dgv = new DataGridView
            {
                Location = new Point(10, 40),
                Width = 370,
                Height = 210,
                AutoGenerateColumns = false,
                AllowUserToAddRows = true,
                AllowUserToDeleteRows = true,
                BackgroundColor = Color.White,
                RowHeadersVisible = false,
                BorderStyle = BorderStyle.Fixed3D,
                DataSource = packList,
                Font = new Font("Segoe UI", 9)
            };

            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.PlanName), HeaderText = "Plan", Width = 80 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.GST), HeaderText = "GST", Width = 60 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.RemainingStock), HeaderText = "Remain", Width = 80 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.Description), HeaderText = "Desc", Width = 100 });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.Brand), Visible = false });
            dgv.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = nameof(PrepaidStarterPack.LastUpdated), Visible = false });

            Button btnDeleteRow = new Button
            {
                Text = "Delete Selected Row",
                Width = 160,
                Height = 30,
                Location = new Point(10, 260),
                BackColor = Color.IndianRed,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 8F, FontStyle.Bold)
            };
            btnDeleteRow.Click += (s, e) =>
            {
                if (dgv.CurrentRow != null && !dgv.CurrentRow.IsNewRow)
                {
                    var item = dgv.CurrentRow.DataBoundItem as PrepaidStarterPack;
                    if (item != null && item.Id != 0)
                    {
                        using var db = AppDbContextFactory.CreateDbContext();
                        var existing = db.PrepaidStarterPacks.FirstOrDefault(x => x.Id == item.Id);
                        if (existing != null)
                        {
                            db.PrepaidStarterPacks.Remove(existing);
                            db.SaveChanges();
                        }
                    }
                    dgv.Rows.Remove(dgv.CurrentRow);
                }
            };

            panel.Controls.Add(brandLabel);
            panel.Controls.Add(brandTextBox);
            panel.Controls.Add(dgv);
            panel.Controls.Add(btnDeleteRow);

            brandLayoutPanel.Controls.Add(panel);
        }

        private void SaveChanges_Click(object? sender, EventArgs e)
        {
            using var db = AppDbContextFactory.CreateDbContext();

            foreach (Control panel in brandLayoutPanel.Controls)
            {
                if (panel is Panel brandPanel)
                {
                    var brandTextBox = brandPanel.Controls.OfType<TextBox>().FirstOrDefault();
                    var dgv = brandPanel.Controls.OfType<DataGridView>().FirstOrDefault();

                    if (brandTextBox == null || dgv == null) continue;

                    dgv.EndEdit();
                    dgv.CurrentCell = null;

                    string brandName = brandTextBox.Text.Trim();
                    var list = (BindingList<PrepaidStarterPack>)dgv.DataSource;

                    foreach (var item in list)
                    {
                        if (string.IsNullOrWhiteSpace(item.PlanName)) continue;
                        item.Brand = brandName;

                        if (item.Id == 0)
                        {
                            item.LastUpdated = DateTime.Now;
                            db.PrepaidStarterPacks.Add(item);
                        }
                        else
                        {
                            var existing = db.PrepaidStarterPacks.FirstOrDefault(p => p.Id == item.Id);
                            if (existing != null)
                            {
                                existing.RemainingStock = item.RemainingStock;
                                existing.PlanName = item.PlanName;
                                existing.GST = item.GST;
                                existing.Description = item.Description;
                                existing.Brand = item.Brand;
                                existing.LastUpdated = DateTime.Now;
                            }
                        }
                    }
                }
            }

            db.SaveChanges();
            MessageBox.Show("Save Success", "Success");
            LoadData();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using Microsoft.EntityFrameworkCore;

namespace ChinatownMobilePos.Forms
{
    public partial class AddSaleForm : Form
    {
        private readonly AppDbContext db;
        private readonly FlowLayoutPanel entryPanel;
        private readonly Button btnAddRow;
        private readonly Button btnSave;

        public List<DailySale> CreatedSales = new();

        public AddSaleForm()
        {
            db = DbContextHelper.GetContext();
            InitializeComponent();

            this.Text = "Add Sales";
            this.Size = new Size(600, 800);
            this.BackColor = Color.White;

            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 1
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 50));
            this.Controls.Add(mainLayout);

            entryPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoScroll = true,
                FlowDirection = FlowDirection.TopDown,
                WrapContents = false
            };
            mainLayout.Controls.Add(entryPanel, 0, 0);

            var btnPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(10)
            };

            btnSave = new Button
            {
                Text = "Save",
                Width = 100,
                Height = 30,
                BackColor = Color.SeaGreen,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnSave.Click += (s, e) => SaveAndClose();

            btnAddRow = new Button
            {
                Text = "Add",
                Width = 100,
                Height = 30,
                BackColor = Color.RoyalBlue,
                ForeColor = Color.White,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            };
            btnAddRow.Click += (s, e) => AddEntryRow();

            btnPanel.Controls.Add(btnSave);
            btnPanel.Controls.Add(btnAddRow);
            mainLayout.Controls.Add(btnPanel, 0, 1);

            AddEntryRow();
        }

        private void AddEntryRow()
        {
            var panel = new TableLayoutPanel
            {
                RowCount = 12,
                ColumnCount = 2,
                AutoSize = true,
                Padding = new Padding(10)
            };
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            var staffNames = db.Staffs.Where(s => s.IsActive).Select(s => s.StaffName).ToList();

            var productItems = db.Products
                .Include(p => p.ProductType)
                .ToList()
                .Select(p => new
                {
                    Product = p.Name,
                    ProductType = p.ProductType?.Name ?? "",
                    DisplayName = (p.ProductType?.Name ?? "") + " - " + p.Name
                })
                .ToList();

            ComboBox cmbStaff = new ComboBox
            {
                DataSource = staffNames,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Width = 300
            };

            TextBox txtProduct = new TextBox { Width = 300 };

            var productSearchPanel = new Panel
            {
                Width = 300,
                Height = 100,
                Visible = false,
                BorderStyle = BorderStyle.FixedSingle,
                AutoScroll = true
            };

            var listBox = new ListBox
            {
                Dock = DockStyle.Fill
            };
            productSearchPanel.Controls.Add(listBox);

            ComboBox cmbDescription = new ComboBox
            {
                Width = 300,
                DropDownStyle = ComboBoxStyle.DropDown,
                AutoCompleteMode = AutoCompleteMode.SuggestAppend,
                AutoCompleteSource = AutoCompleteSource.ListItems
            };

            TextBox txtQty = new TextBox { Width = 300 };
            TextBox txtIMEI = new TextBox { Width = 300, Multiline = true, Height = 40 };
            TextBox txtNote = new TextBox { Width = 300, Multiline = true, Height = 60 };
            TextBox txtEFT = new TextBox { Width = 300 };
            TextBox txtTT = new TextBox { Width = 300 };
            TextBox txtOMI = new TextBox { Width = 300 };
            TextBox txtCash = new TextBox { Width = 300 };
            TextBox txtOut = new TextBox { Width = 300 };

            // Auto-fill product from IMEI in stock
            txtIMEI.Leave += (s, e) =>
            {
                string imei = txtIMEI.Text.Trim();
                if (imei.Length < 5) return;

                var stockMatch = db.StockItems.AsNoTracking().FirstOrDefault(x => x.IMEI == imei);
                if (stockMatch != null && !string.IsNullOrWhiteSpace(stockMatch.DeviceName))
                {
                    var handsetType = db.ProductTypes.FirstOrDefault(p => p.Name == "Handset");
                    if (handsetType != null)
                    {
                        var deviceProduct = db.Products.FirstOrDefault(p => p.Name == stockMatch.DeviceName && p.ProductTypeId == handsetType.Id);
                        if (deviceProduct != null)
                        {
                            txtProduct.Text = $"Handset - {deviceProduct.Name}";
                            txtProduct.Focus();
                            txtProduct.SelectionStart = txtProduct.Text.Length;
                        }
                    }
                }
            };

            var productStack = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.TopDown,
                AutoSize = true,
                AutoSizeMode = AutoSizeMode.GrowAndShrink,
                WrapContents = false
            };
            productStack.Controls.Add(txtProduct);
            productStack.Controls.Add(productSearchPanel);

            txtProduct.TextChanged += (s, e) =>
            {
                string input = txtProduct.Text.Trim().ToLower();
                var matches = productItems
                    .Where(p => p.DisplayName.ToLower().Contains(input))
                    .Select(p => p.DisplayName)
                    .ToList();

                if (matches.Count > 0 && input.Length > 0)
                {
                    listBox.DataSource = matches;
                    productSearchPanel.Visible = true;
                }
                else
                {
                    productSearchPanel.Visible = false;
                }

                var selected = productItems.FirstOrDefault(p => p.DisplayName == txtProduct.Text.Trim());
                if (selected != null)
                {
                    var product = db.Products.Include(p => p.ProductDescriptions)
                                             .FirstOrDefault(p => p.Name == selected.Product);
                    if (product != null)
                    {
                        var descriptions = product.ProductDescriptions?.Select(d => d.DescriptionText).ToList();
                        cmbDescription.Items.Clear();
                        cmbDescription.Items.AddRange(descriptions?.ToArray() ?? Array.Empty<string>());
                    }
                }
            };

            listBox.Click += (s, e) =>
            {
                if (listBox.SelectedItem != null)
                {
                    txtProduct.Text = listBox.SelectedItem.ToString();
                    productSearchPanel.Visible = false;
                    txtProduct.Focus();
                    txtProduct.SelectionStart = txtProduct.Text.Length;
                }
            };

            void AddRow(string label, Control control)
            {
                panel.Controls.Add(new Label { Text = label, Anchor = AnchorStyles.Left, AutoSize = true }, 0, panel.RowCount - 1);
                panel.Controls.Add(control, 1, panel.RowCount - 1);
                panel.RowCount++;
            }

            AddRow("Staff", cmbStaff);
            AddRow("Product", productStack);
            AddRow("Description", cmbDescription);
            AddRow("Qty", txtQty);
            AddRow("IMEI", txtIMEI);
            AddRow("Note", txtNote);
            AddRow("EFT", txtEFT);
            AddRow("TT", txtTT);
            AddRow("OMI", txtOMI);
            AddRow("Cash", txtCash);
            AddRow("Out", txtOut);

            panel.Tag = new Dictionary<string, Control>
            {
                ["StaffName"] = cmbStaff,
                ["Product"] = txtProduct,
                ["Description"] = cmbDescription,
                ["Quantity"] = txtQty,
                ["IMEI"] = txtIMEI,
                ["Note"] = txtNote,
                ["PaymentEFT"] = txtEFT,
                ["PaymentTT"] = txtTT,
                ["PaymentOMI"] = txtOMI,
                ["PaymentCash"] = txtCash,
                ["PaymentCashout"] = txtOut
            };

            entryPanel.Controls.Add(panel);
        }

        private void SaveAndClose()
        {
            CreatedSales.Clear();
            var groupId = new Random().Next(100000, 999999);

            foreach (Control c in entryPanel.Controls)
            {
                if (c is not TableLayoutPanel row || row.Tag is not Dictionary<string, Control> map) continue;

                string staffName = ((ComboBox)map["StaffName"]).Text.Trim();
                string displayText = map["Product"].Text.Trim();

                string[] parts = displayText.Split(" - ");
                if (parts.Length < 2) continue;

                string productTypeName = parts[0].Trim();
                string productName = parts[1].Trim();

                var productQuery = db.Products
                    .Include(p => p.ProductType)
                    .FirstOrDefault(p => p.Name == productName && p.ProductType != null && p.ProductType.Name == productTypeName);

                if (productQuery == null) continue;

                string qtyStr = map["Quantity"].Text.Trim();
                string descriptionText = ((ComboBox)map["Description"]).Text?.Trim();

                if (string.IsNullOrWhiteSpace(staffName) || string.IsNullOrWhiteSpace(productName) || !int.TryParse(qtyStr, out int quantity))
                    continue;

                var sale = new DailySale
                {
                    Id = Guid.NewGuid().ToString(),
                    StaffName = staffName,
                    Quantity = quantity,
                    Product = productQuery.Name,
                    ProductDescriptionText = descriptionText,
                    IMEI = map["IMEI"].Text,
                    Note = map["Note"].Text,
                    PaymentEFT = ParseDecimal(map["PaymentEFT"].Text),
                    PaymentTT = ParseDecimal(map["PaymentTT"].Text),
                    PaymentOMI = ParseDecimal(map["PaymentOMI"].Text),
                    PaymentCash = ParseDecimal(map["PaymentCash"].Text),
                    PaymentCashout = ParseDecimal(map["PaymentCashout"].Text),
                    Date = DateTime.Today,
                    CreatedAt = DateTime.Now,
                    GroupId = groupId,
                    SaleType = productQuery.ProductType?.SaleType,
                    ProductType = productQuery.ProductType?.Name
                };

                CreatedSales.Add(sale);
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private decimal? ParseDecimal(string value)
        {
            return decimal.TryParse(value, out var result) ? result : null;
        }
    }
}

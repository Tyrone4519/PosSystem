﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using ClosedXML.Excel;
using Microsoft.EntityFrameworkCore;

namespace ChinatownMobilePos.Forms
{
    public partial class StockListForm : Form
    {
        private readonly AppDbContext db;
        private BindingList<StockItem> stockBindingList = new();
        private DataGridView dgv = new();
        private TextBox txtSearch = new();
        private TextBox txtSupplierSearch = new();
        private TextBox txtDeviceSearch = new();
        private ComboBox cmbContract = new();
        private ComboBox cmbOutright = new();
        private ComboBox cmbStaff = new();
        private List<string> deviceNames = new();
        private ListBox? deviceSuggestBox;
        private ListBox? dgvDeviceSuggestBox;
        private TextBox? dgvDeviceEditingTextBox;

        public StockListForm()
        {
            InitializeComponent();
            db = new AppDbContext();
            SetupLayout();
            LoadStockItems();
        }

        private void SetupLayout()
        {
            this.BackColor = Color.FromArgb(245, 239, 220);
            this.Padding = new Padding(200, 80, 40, 40);

            var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            this.Controls.Add(mainLayout);

            var leftPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                WrapContents = false
            };

            Color btnColor = Color.DarkGoldenrod;
            Font btnFont = new Font("Segoe UI", 9F, FontStyle.Bold);

            var btnAdd = new Button { Text = "Add", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnAdd.Click += (s, e) =>
            {
                var item = new StockItem
                {
                    DateIn = DateTime.Today,
                    ContractStatus = "Available",
                    OutrightStatus = "In Stock"
                };
                stockBindingList.Insert(0, item);
                dgv.DataSource = stockBindingList;
                dgv.CurrentCell = dgv.Rows[0].Cells[0];
                dgv.BeginEdit(true);
            };

            var btnDelete = new Button { Text = "Delete", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnDelete.Click += (s, e) =>
            {
                if (dgv.CurrentRow?.DataBoundItem is StockItem item)
                {
                    stockBindingList.Remove(item);
                    if (item.Id != null && item.Id > 0)
                    {
                        db.StockItems.Remove(item);
                        db.SaveChanges();
                        LoadStockItems();
                    }
                }
            };

            var btnSave = new Button { Text = "Save", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnSave.Click += (s, e) =>
            {
                dgv.EndEdit();

                foreach (var item in stockBindingList)
                {
                    if (string.IsNullOrWhiteSpace(item.StaffName) &&
                        string.IsNullOrWhiteSpace(item.Supplier) &&
                        string.IsNullOrWhiteSpace(item.DeviceName))
                    {
                        continue;
                    }

                    item.StaffName ??= "Unknown";
                    item.Supplier ??= "Unknown";
                    item.DeviceName ??= "Unknown";

                    if (item.Id == null || item.Id == 0)
                        db.StockItems.Add(item);
                    else
                        db.StockItems.Update(item);
                }

                db.SaveChanges();
                LoadStockItems();
                MessageBox.Show("Saved successfully.");
            };

            var btnExport = new Button { Text = "Export", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnExport.Click += (s, e) => ExportStock();

            var btnImport = new Button { Text = "Import", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnImport.Click += (s, e) => ImportStock();

            var btnSupplier = new Button { Text = "Supplier", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnSupplier.Click += (s, e) => new SupplierForm().ShowDialog();

            var btnDevice = new Button { Text = "Device", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            btnDevice.Click += (s, e) => new DeviceForm().ShowDialog();

            leftPanel.Controls.AddRange(new[] { btnAdd, btnDelete, btnSave, btnExport, btnImport, btnSupplier, btnDevice });

            var filterPanel = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40, AutoSize = true, FlowDirection = FlowDirection.LeftToRight };

            filterPanel.Controls.Add(new Label { Text = "Search:", AutoSize = true });
            txtSearch.Width = 200;
            filterPanel.Controls.Add(txtSearch);

            filterPanel.Controls.Add(new Label { Text = "Contract:", AutoSize = true });
            cmbContract.Width = 100;
            cmbContract.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbContract.Items.AddRange(new[] { "", "Contracted", "Available" });
            filterPanel.Controls.Add(cmbContract);

            filterPanel.Controls.Add(new Label { Text = "Outright:", AutoSize = true });
            cmbOutright.Width = 100;
            cmbOutright.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbOutright.Items.AddRange(new[] { "", "In Stock", "Sold" });
            filterPanel.Controls.Add(cmbOutright);

            filterPanel.Controls.Add(new Label { Text = "Staff:", AutoSize = true });
            cmbStaff.Width = 100;
            cmbStaff.DropDownStyle = ComboBoxStyle.DropDownList;
            var allStaffs = db.Staffs.Select(s => s.StaffName).Where(s => !string.IsNullOrWhiteSpace(s)).Distinct().ToList();
            allStaffs.Insert(0, "");
            cmbStaff.Items.AddRange(allStaffs.ToArray());
            filterPanel.Controls.Add(cmbStaff);

            filterPanel.Controls.Add(new Label { Text = "Supplier:", AutoSize = true });
            txtSupplierSearch.Width = 150;
            var supplierSource = new AutoCompleteStringCollection();
            supplierSource.AddRange(db.Suppliers.Select(x => x.Name).Where(x => x != null).ToArray());
            txtSupplierSearch.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtSupplierSearch.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtSupplierSearch.AutoCompleteCustomSource = supplierSource;
            filterPanel.Controls.Add(txtSupplierSearch);

            filterPanel.Controls.Add(new Label { Text = "Device:", AutoSize = true });
            txtDeviceSearch.Width = 150;
            txtDeviceSearch.TextChanged += TxtDeviceSearch_TextChanged;
            filterPanel.Controls.Add(txtDeviceSearch);

            deviceNames = db.Devices.Select(x => x.Name).Where(x => x != null).Distinct().ToList();

            deviceSuggestBox = new ListBox { Height = 100, Visible = false };
            deviceSuggestBox.Click += (s, e) =>
            {
                if (deviceSuggestBox.SelectedItem is string selected)
                {
                    txtDeviceSearch.Text = selected;
                    deviceSuggestBox.Visible = false;
                }
            };
            Controls.Add(deviceSuggestBox);

            var btnSearch = new Button { Text = "Search", Width = 90, Height = 35, BackColor = btnColor, Font = btnFont, ForeColor = Color.White };
            btnSearch.Click += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(btnSearch);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = true,
                AllowUserToResizeColumns = true,
                ScrollBars = ScrollBars.Both,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.Maroon,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
                EnableHeadersVisualStyles = false
            };

            dgv.CellFormatting += Dgv_CellFormatting;
            dgv.EditingControlShowing += Dgv_EditingControlShowing;
            dgv.DataError += (s, e) => e.Cancel = true;
            dgv.CellEndEdit += Dgv_CellEndEdit;
            SetupGridColumns();

            var rightPanel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2 };
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightPanel.Controls.Add(filterPanel, 0, 0);
            rightPanel.Controls.Add(dgv, 0, 1);

            mainLayout.Controls.Add(leftPanel, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);
        }


        private void TxtDeviceSearch_TextChanged(object? sender, EventArgs e)
        {
            string input = txtDeviceSearch.Text.Trim().ToLower();
            var matches = deviceNames.Where(name => name.ToLower().Contains(input)).Distinct().ToList();
            if (matches.Any() && !string.IsNullOrEmpty(input))
            {
                deviceSuggestBox.DataSource = matches;
                var pt = txtDeviceSearch.PointToScreen(Point.Empty);
                var relativePt = this.PointToClient(pt);
                deviceSuggestBox.SetBounds(relativePt.X, relativePt.Y + txtDeviceSearch.Height, txtDeviceSearch.Width, 100);
                deviceSuggestBox.BringToFront();
                deviceSuggestBox.Show();
            }
            else
            {
                deviceSuggestBox.Hide();
            }
        }

        private void Dgv_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgv.CurrentCell == null || dgv.CurrentCell.OwningColumn == null)
                return;

            string column = dgv.CurrentCell.OwningColumn.DataPropertyName;

            if (e.Control is TextBox tb)
            {
                // 通用清理
                tb.AutoCompleteMode = AutoCompleteMode.None;
                tb.AutoCompleteSource = AutoCompleteSource.None;
                tb.AutoCompleteCustomSource = null;

                // 清除旧的 DeviceName 事件绑定，防止干扰
                tb.TextChanged -= DgvDeviceEditingTextBox_TextChanged;

                if (column == "DeviceName")
                {
                    dgvDeviceEditingTextBox = tb;
                    tb.TextChanged += DgvDeviceEditingTextBox_TextChanged;
                    HideDgvDeviceSuggestBox();
                }
                else if (column == "StaffName")
                {
                    var activeStaffNames = db.Staffs
                        .Where(s => s.IsActive && !string.IsNullOrWhiteSpace(s.StaffName))
                        .Select(s => s.StaffName)
                        .Distinct()
                        .ToArray();

                    tb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    tb.AutoCompleteCustomSource = new AutoCompleteStringCollection();
                    tb.AutoCompleteCustomSource.AddRange(activeStaffNames);
                }
                else if (column == "Supplier")
                {
                    var supplierNames = db.Suppliers
                        .Where(s => !string.IsNullOrWhiteSpace(s.Name))
                        .Select(s => s.Name)
                        .Distinct()
                        .ToArray();

                    tb.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    tb.AutoCompleteCustomSource = new AutoCompleteStringCollection();
                    tb.AutoCompleteCustomSource.AddRange(supplierNames);
                }
                else if (column == "Notes")
                {
                    // 禁用 Notes 自动补全
                    tb.AutoCompleteMode = AutoCompleteMode.None;
                    tb.AutoCompleteSource = AutoCompleteSource.None;
                    tb.AutoCompleteCustomSource = null;
                }
            }
        }


        private void DgvDeviceEditingTextBox_TextChanged(object? sender, EventArgs e)
        {
            if (dgvDeviceEditingTextBox == null || dgv.CurrentCell == null) return;

            string input = dgvDeviceEditingTextBox.Text.Trim().ToLower();
            var matches = deviceNames.Where(name => name.ToLower().Contains(input)).Distinct().ToList();

            if (matches.Any() && !string.IsNullOrEmpty(input))
            {
                if (dgvDeviceSuggestBox == null)
                {
                    dgvDeviceSuggestBox = new ListBox { Height = 100, Width = dgv.CurrentCell.Size.Width, Font = dgv.Font };
                    dgvDeviceSuggestBox.Click += DgvDeviceSuggestBox_Click;
                    dgv.Controls.Add(dgvDeviceSuggestBox);
                }

                dgvDeviceSuggestBox.DataSource = matches;
                PositionDgvDeviceSuggestBox();
                dgvDeviceSuggestBox.Visible = true;
                dgvDeviceSuggestBox.BringToFront();
            }
            else
            {
                HideDgvDeviceSuggestBox();
            }
        }


        private void Dgv_CellEndEdit(object? sender, DataGridViewCellEventArgs e)
        {
            var columnName = dgv.Columns[e.ColumnIndex].DataPropertyName;
            if (columnName == "PurchasePrice")
            {
                if (dgv.Rows[e.RowIndex].DataBoundItem is StockItem item && item.PurchasePrice != null)
                {
                    item.GST = item.PurchasePrice.Value / 11m;
                    item.OriginalPrice = item.PurchasePrice.Value * 10 / 11m;
                    dgv.Refresh();
                }
            }
        }

        private void DgvDeviceSuggestBox_Click(object? sender, EventArgs e)
        {
            if (dgvDeviceSuggestBox?.SelectedItem is string selected && dgvDeviceEditingTextBox != null)
            {
                dgvDeviceEditingTextBox.Text = selected;
                dgvDeviceEditingTextBox.SelectionStart = selected.Length;
                HideDgvDeviceSuggestBox();
            }
        }

        private void PositionDgvDeviceSuggestBox()
        {
            if (dgvDeviceSuggestBox == null || dgv.CurrentCell == null) return;
            var rect = dgv.GetCellDisplayRectangle(dgv.CurrentCell.ColumnIndex, dgv.CurrentCell.RowIndex, true);
            dgvDeviceSuggestBox.SetBounds(rect.X, rect.Bottom, rect.Width, 100);
        }

        private void HideDgvDeviceSuggestBox()
        {
            if (dgvDeviceSuggestBox != null)
            {
                dgv.Controls.Remove(dgvDeviceSuggestBox);
                dgvDeviceSuggestBox.Dispose();
                dgvDeviceSuggestBox = null;
            }
        }

        private void SetupGridColumns()
        {
            dgv.Columns.Clear();

            void AddColumn(string name, string dataProperty, int width = 100)
            {
                dgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    HeaderText = name,
                    DataPropertyName = dataProperty,
                    Width = width
                });
            }

            AddColumn("Staff", "StaffName", 50);
            AddColumn("Date In", "DateIn", 80);
            AddColumn("Supplier", "Supplier", 80);
            AddColumn("Device", "DeviceName", 150);
            AddColumn("IMEI", "IMEI", 130);
            AddColumn("SIM/Serial", "SimOrSerialNumber", 200);
            AddColumn("Purchase Price", "PurchasePrice", 90);
            AddColumn("GST", "GST", 40);
            AddColumn("Original Price", "OriginalPrice", 80);

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "Contract",
                DataPropertyName = "ContractStatus",
                Width = 90,
                DataSource = new[] { "Available", "Contracted" },
                FlatStyle = FlatStyle.Flat
            });

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "Outright",
                DataPropertyName = "OutrightStatus",
                Width = 80,
                DataSource = new[] { "In Stock", "Sold" },
                FlatStyle = FlatStyle.Flat
            });

            AddColumn("Notes", "Notes", 400);
        }

        private void ApplyFilter()
        {
            string keyword = txtSearch.Text.ToLower();
            string supplierKeyword = txtSupplierSearch.Text.ToLower();
            string deviceKeyword = txtDeviceSearch.Text.ToLower();
            string contract = cmbContract.SelectedItem?.ToString();
            string outright = cmbOutright.SelectedItem?.ToString();
            string staff = cmbStaff.SelectedItem?.ToString();

            var filtered = db.StockItems.AsNoTracking().Where(item =>
                (string.IsNullOrEmpty(keyword) || item.DeviceName.ToLower().Contains(keyword) || item.IMEI.ToLower().Contains(keyword)) &&
                (string.IsNullOrEmpty(supplierKeyword) || item.Supplier.ToLower().Contains(supplierKeyword)) &&
                (string.IsNullOrEmpty(deviceKeyword) || item.DeviceName.ToLower().Contains(deviceKeyword)) &&
                (string.IsNullOrEmpty(contract) || item.ContractStatus == contract) &&
                (string.IsNullOrEmpty(outright) || item.OutrightStatus == outright) &&
                (string.IsNullOrEmpty(staff) || item.StaffName == staff)
            ).OrderByDescending(x => x.DateIn).ToList();

            stockBindingList = new BindingList<StockItem>(filtered);
            dgv.DataSource = stockBindingList;
        }

        private void LoadStockItems()
        {
            var stocks = db.StockItems.ToList();

            var imeisFromContract = db.Contracts.Select(c => c.IMEI).Where(i => !string.IsNullOrEmpty(i)).ToHashSet();
            var imeisFromSales = db.DailySales.Select(s => s.IMEI).Where(i => !string.IsNullOrEmpty(i)).ToHashSet();

            foreach (var item in stocks)
            {
                if (!string.IsNullOrEmpty(item.IMEI))
                {
                    if (!string.IsNullOrEmpty(item.ContractStatus) && item.ContractStatus == "Available")
                    {
                        if (imeisFromContract.Contains(item.IMEI))
                            item.ContractStatus = "Contracted";
                    }
                    if (!string.IsNullOrEmpty(item.OutrightStatus) && item.OutrightStatus == "In Stock")
                    {
                        if (imeisFromSales.Contains(item.IMEI))
                            item.OutrightStatus = "Sold";
                    }
                }
            }

            db.SaveChanges();

            stockBindingList = new BindingList<StockItem>(stocks.OrderByDescending(x => x.DateIn).ToList());
            dgv.DataSource = stockBindingList;
        }

        private void Dgv_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            if (dgv.Rows[e.RowIndex].DataBoundItem is StockItem item)
            {
                string col = dgv.Columns[e.ColumnIndex].DataPropertyName;
                if (col == "GST")
                    e.Value = item.PurchasePrice.HasValue ? (item.PurchasePrice.Value / 11m).ToString("0.00") : "";
                else if (col == "OriginalPrice")
                    e.Value = item.PurchasePrice.HasValue ? (item.PurchasePrice.Value * 10 / 11m).ToString("0.00") : "";
            }
        }

        private void ExportStock()
        {
            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("StockItems");
            ws.Cell(1, 1).InsertTable(stockBindingList);
            var dlg = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() == DialogResult.OK)
                workbook.SaveAs(dlg.FileName);
        }

        private void ImportStock()
        {
            var dlg = new OpenFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            using var workbook = new XLWorkbook(dlg.FileName);
            var table = workbook.Worksheet(1).Table(0);

            foreach (var row in table.DataRange.Rows())
            {
                var item = new StockItem
                {
                    StaffName = row.Field("StaffName").GetString(),
                    DateIn = DateTime.TryParse(row.Field("DateIn").GetString(), out var date) ? date : (DateTime?)null,
                    Supplier = row.Field("Supplier").GetString(),
                    DeviceName = row.Field("DeviceName").GetString(),
                    IMEI = row.Field("IMEI").GetString(),
                    SimOrSerialNumber = row.Field("SimOrSerialNumber").GetString(),
                    ContractStatus = "Available",
                    OutrightStatus = "In Stock",
                    Notes = row.Field("Notes").GetString(),
                    PurchasePrice = decimal.TryParse(row.Field("PurchasePrice").GetString(), out var pp) ? pp : null
                };
                db.StockItems.Add(item);
            }
            db.SaveChanges();
            LoadStockItems();
            MessageBox.Show("Import completed successfully.", "Import", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}


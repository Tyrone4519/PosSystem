﻿using ChinatownMobilePos.Data;
using ClosedXML.Excel;
using System.ComponentModel;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class ContractForm : Form
    {
        private readonly AppDbContext db;
        private BindingList<Contract> contractList = new();
        private DataGridView dgv;
        private TextBox txtSearch;
        private ComboBox cmbStaffFilter;
        private DateTimePicker dateFilter;
        private CheckBox chkUseDate;

        private List<string> deviceNames = new();
        private ListBox? deviceSuggestBox;
        private TextBox? deviceEditingTextBox;

        public ContractForm()
        {
            db = new AppDbContext();
            SetupLayout();
            LoadContracts();
        }

        private void SetupLayout()
        {
            this.BackColor = Color.FromArgb(245, 239, 220);
            this.Padding = new Padding(200, 80, 40, 40);

            var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 200));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            this.Controls.Add(mainLayout);

            var leftPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                WrapContents = false
            };

            Color btnColor = Color.DarkGoldenrod;
            Font btnFont = new Font("Segoe UI", 9F, FontStyle.Bold);

            var btnAdd = new Button { Text = "Add", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnDelete = new Button { Text = "Delete", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnSave = new Button { Text = "Save", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnExport = new Button { Text = "Export", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };
            var btnImport = new Button { Text = "Import", Width = 160, Height = 35, BackColor = btnColor, ForeColor = Color.White, Font = btnFont };

            btnAdd.Click += (s, e) =>
            {
                contractList.Insert(0, new Contract { ContractDate = DateTime.Today });
                dgv.CurrentCell = dgv.Rows[0].Cells[1];
                dgv.BeginEdit(true);
            };

            btnDelete.Click += (s, e) =>
            {
                if (dgv.CurrentRow?.DataBoundItem is Contract contract)
                {
                    contractList.Remove(contract);
                    db.Contracts.Remove(contract);
                    db.SaveChanges();
                }
            };

            btnSave.Click += (s, e) =>
            {
                db.Contracts.UpdateRange(contractList);
                db.SaveChanges();
                MessageBox.Show("Saved.");
            };

            btnExport.Click += (s, e) => ExportToExcel();
            btnImport.Click += (s, e) => ImportFromExcel();

            leftPanel.Controls.AddRange(new[] { btnAdd, btnDelete, btnSave, btnExport, btnImport });

            var filterPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 40,
                AutoSize = true,
                FlowDirection = FlowDirection.LeftToRight
            };

            filterPanel.Controls.Add(new Label { Text = "Search:", AutoSize = true });
            txtSearch = new TextBox { Width = 200 };
            filterPanel.Controls.Add(txtSearch);

            filterPanel.Controls.Add(new Label { Text = "Filter Staff:", AutoSize = true });
            cmbStaffFilter = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStaffFilter.Items.AddRange(db.Staffs.Select(s => s.StaffName).ToList().Prepend("All").ToArray());
            filterPanel.Controls.Add(cmbStaffFilter);

            chkUseDate = new CheckBox { Text = "Filter Date:", AutoSize = true, Checked = false };
            filterPanel.Controls.Add(chkUseDate);

            dateFilter = new DateTimePicker { Format = DateTimePickerFormat.Short, Width = 140 };
            filterPanel.Controls.Add(dateFilter);

            var btnSearch = new Button { Text = "Search", Width = 90, Height = 35, BackColor = btnColor, Font = btnFont, ForeColor = Color.White };
            btnSearch.Click += (s, e) => ApplyFilter();
            filterPanel.Controls.Add(btnSearch);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoGenerateColumns = false,
                AllowUserToAddRows = true,
                AllowUserToResizeColumns = true,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                BackgroundColor = Color.White,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.Maroon,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
                EnableHeadersVisualStyles = false
            };
            dgv.DataError += (s, e) => e.ThrowException = false;
            dgv.EditingControlShowing += Dgv_EditingControlShowing;

            SetupGridColumns();

            var rightPanel = new TableLayoutPanel { Dock = DockStyle.Fill, RowCount = 2 };
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
            rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            rightPanel.Controls.Add(filterPanel, 0, 0);
            rightPanel.Controls.Add(dgv, 0, 1);

            mainLayout.Controls.Add(leftPanel, 0, 0);
            mainLayout.Controls.Add(rightPanel, 1, 0);
        }


        private void SetupGridColumns()
        {
            void AddTextBox(string header, string property, int width)
            {
                dgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    HeaderText = header,
                    DataPropertyName = property,
                    Width = width
                });
            }

            dgv.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Id", DataPropertyName = "Id", Visible = false });
            AddTextBox("Date", "ContractDate", 70);

            var existingStaffs = db.Contracts.Select(c => c.StaffName).Distinct().ToList();
            var activeStaffs = db.Staffs.Where(s => s.IsActive).Select(s => s.StaffName).ToList();
            var staffList = activeStaffs.Union(existingStaffs).Distinct().ToList();

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "Staff",
                DataPropertyName = "StaffName",
                DataSource = staffList,
                Width = 60
            });

            AddTextBox("CustomerName", "CustomerName", 300);
            AddTextBox("Mobile #", "MobileNumber", 100);
            AddTextBox("Order #", "OrderNumber", 100);
            AddTextBox("PIN", "PIN", 40);
            AddTextBox("Plan", "PlanAmount", 40);
            AddTextBox("MPP", "MPP", 40);

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "Term",
                DataPropertyName = "TermMonths",
                DataSource = new[] { 0, 12, 24, 36 },
                Width = 70
            });

            AddTextBox("DST", "Discount", 30);

            dgv.Columns.Add(new DataGridViewComboBoxColumn
            {
                HeaderText = "ContractType",
                DataPropertyName = "ContractType",
                DataSource = new[] { "New", "Upgrade", "Pre to post", "Kickers", "MBB", "NBN", "FWA", "APP", "Vision" },
                Width = 100
            });

            AddTextBox("Device", "Device", 150);
            AddTextBox("IMEI", "IMEI", 100);
            AddTextBox("DOB", "DateOfBirth", 70);
            AddTextBox("Email", "Email", 100);
            AddTextBox("Note", "Note", 500);
            AddTextBox("Follow-up", "FollowUpNote", 150);
        }

        private void Dgv_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            if (dgv.CurrentCell.OwningColumn.HeaderText == "Staff" && e.Control is ComboBox cb)
            {
                cb.DataSource = db.Staffs.Where(s => s.IsActive).Select(s => s.StaffName).ToList();
            }

            if (dgv.CurrentCell.OwningColumn.HeaderText == "Device" && e.Control is TextBox tb)
            {
                deviceEditingTextBox = tb;
                tb.TextChanged -= DeviceEditingTextBox_TextChanged;
                tb.TextChanged += DeviceEditingTextBox_TextChanged;
                HideDeviceSuggestBox();
            }
        }

        private void DeviceEditingTextBox_TextChanged(object? sender, EventArgs e)
        {
            if (deviceEditingTextBox == null || dgv.CurrentCell == null) return;

            string input = deviceEditingTextBox.Text.Trim().ToLower();

            var matches = deviceNames
                .Where(name => name.ToLower().Contains(input))
                .Distinct()
                .ToList();

            if (matches.Any() && !string.IsNullOrEmpty(input))
            {
                if (deviceSuggestBox == null)
                {
                    deviceSuggestBox = new ListBox
                    {
                        Height = 100,
                        Width = dgv.CurrentCell.Size.Width,
                        Font = dgv.Font
                    };
                    deviceSuggestBox.Click += DeviceSuggestBox_Click;
                    dgv.Controls.Add(deviceSuggestBox);
                }

                deviceSuggestBox.DataSource = matches;
                PositionDeviceSuggestBox();
                deviceSuggestBox.Visible = true;
                deviceSuggestBox.BringToFront();
            }
            else
            {
                HideDeviceSuggestBox();
            }
        }

        private void DeviceSuggestBox_Click(object? sender, EventArgs e)
        {
            if (deviceSuggestBox?.SelectedItem is string selected && deviceEditingTextBox != null)
            {
                deviceEditingTextBox.Text = selected;
                deviceEditingTextBox.SelectionStart = selected.Length;
                HideDeviceSuggestBox();
            }
        }

        private void PositionDeviceSuggestBox()
        {
            if (deviceSuggestBox == null || dgv.CurrentCell == null) return;

            var rect = dgv.GetCellDisplayRectangle(dgv.CurrentCell.ColumnIndex, dgv.CurrentCell.RowIndex, true);
            deviceSuggestBox.SetBounds(rect.X, rect.Bottom, rect.Width, 100);
        }

        private void HideDeviceSuggestBox()
        {
            if (deviceSuggestBox != null)
            {
                dgv.Controls.Remove(deviceSuggestBox);
                deviceSuggestBox.Dispose();
                deviceSuggestBox = null;
            }
        }

        private void LoadContracts()
        {
            dateFilter.Value = DateTime.Today;
            chkUseDate.Checked = true;

            var sortedContracts = db.Contracts.OrderByDescending(c => c.ContractDate ?? DateTime.MinValue).ToList();
            contractList = new BindingList<Contract>(sortedContracts);
            dgv.DataSource = contractList;

            // 初始化设备名列表
            deviceNames = db.Devices.Select(d => d.Name).Distinct().ToList();
        }

        private void ApplyFilter()
        {
            var keyword = txtSearch.Text.ToLower();
            var staff = cmbStaffFilter.SelectedItem?.ToString();
            var useDate = chkUseDate.Checked;
            var selectedDate = dateFilter.Value.Date;

            var filtered = db.Contracts.AsEnumerable().Where(c =>
                (string.IsNullOrEmpty(keyword) ||
                    (c.CustomerName ?? "").ToLower().Contains(keyword) ||
                    (c.MobileNumber ?? "").ToLower().Contains(keyword) ||
                    (c.StaffName ?? "").ToLower().Contains(keyword) ||
                    (c.Device ?? "").ToLower().Contains(keyword) ||
                    (c.OrderNumber ?? "").ToLower().Contains(keyword) ||
                    (c.Email ?? "").ToLower().Contains(keyword)) &&
                (!useDate || c.ContractDate?.Date == selectedDate) &&
                (string.IsNullOrEmpty(staff) || staff == "All" || c.StaffName == staff)
            ).OrderByDescending(c => c.ContractDate).ToList();

            contractList = new BindingList<Contract>(filtered);
            dgv.DataSource = contractList;
        }

        private void ExportToExcel()
        {
            using var dlg = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                using var workbook = new XLWorkbook();
                var ws = workbook.Worksheets.Add("Contracts");

                var exportData = contractList.Select(c => new
                {
                    c.ContractDate,
                    c.StaffName,
                    c.CustomerName,
                    c.MobileNumber,
                    c.OrderNumber,
                    c.PIN,
                    c.PlanAmount,
                    c.MPP,
                    c.TermMonths,
                    c.Discount,
                    c.ContractType,
                    c.Device,
                    c.IMEI,
                    c.DateOfBirth,
                    c.Email,
                    c.Note,
                    c.FollowUpNote,
                    c.CreatedAt
                }).ToList();

                ws.Cell(1, 1).InsertTable(exportData);
                workbook.SaveAs(dlg.FileName);
                MessageBox.Show("Export completed successfully.", "Export", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Export failed: {ex.Message}", "Export Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void ImportFromExcel()
        {
            using var dlg = new OpenFileDialog { Filter = "Excel Files|*.xlsx" };
            if (dlg.ShowDialog() != DialogResult.OK) return;

            try
            {
                using var workbook = new XLWorkbook(dlg.FileName);
                var ws = workbook.Worksheet(1);
                var rows = ws.RangeUsed().RowsUsed().Skip(1); // Skip header

                var contracts = new List<Contract>();
                int successCount = 0, errorCount = 0;

                foreach (var row in rows)
                {
                    try
                    {
                        string? termText = row.Cell(9).GetString()?.Trim();
                        int? termMonths = int.TryParse(termText, out int tm) ? tm : (int?)null;

                        var contract = new Contract
                        {
                            // Id NOT SET because it's int auto-increment
                            ContractDate = row.Cell(1).TryGetValue(out DateTime cDate) ? cDate : (DateTime?)null,
                            StaffName = row.Cell(2).GetString()?.Trim(),
                            CustomerName = row.Cell(3).GetString()?.Trim(),
                            MobileNumber = row.Cell(4).GetString()?.Trim(),
                            OrderNumber = row.Cell(5).GetString()?.Trim(),
                            PIN = row.Cell(6).GetString()?.Trim(),
                            PlanAmount = row.Cell(7).GetString()?.Trim(),
                            MPP = row.Cell(8).GetString()?.Trim(),
                            TermMonths = termMonths,
                            Discount = row.Cell(10).GetString()?.Trim(),
                            ContractType = row.Cell(11).GetString()?.Trim(),
                            Device = row.Cell(12).GetString()?.Trim(),
                            IMEI = row.Cell(13).GetString()?.Trim(),
                            DateOfBirth = row.Cell(14).TryGetValue(out DateTime dob) ? dob : (DateTime?)null,
                            Email = row.Cell(15).GetString()?.Trim(),
                            Note = row.Cell(16).GetString()?.Trim(),
                            FollowUpNote = row.Cell(17).GetString()?.Trim(),
                            CreatedAt = DateTime.Now
                        };

                        // Skip rows that have no meaningful data
                        if (string.IsNullOrWhiteSpace(contract.CustomerName) &&
                            string.IsNullOrWhiteSpace(contract.MobileNumber) &&
                            string.IsNullOrWhiteSpace(contract.StaffName))
                        {
                            Console.WriteLine("Skipped empty row.");
                            continue;
                        }

                        contracts.Add(contract);
                        successCount++;
                    }
                    catch (Exception exRow)
                    {
                        errorCount++;
                        Console.WriteLine($"Row import error: {exRow.Message}");
                    }
                }

                if (contracts.Any())
                {
                    db.Contracts.AddRange(contracts);
                    db.SaveChanges(); // make sure it's called
                    LoadContracts();  // refresh UI
                    MessageBox.Show($"Import complete: {successCount} rows added, {errorCount} failed.", "Import Result",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                {
                    MessageBox.Show("No valid contracts found to import.", "Import Result", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Import failed: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;
using ChinatownMobilePos.Model;

namespace ChinatownMobilePos.Forms
{
    public partial class AddDailyTaskForm : Form
    {
        public DailyTask NewTask { get; private set; }

        public AddDailyTaskForm(List<string> staffNames)
        {
            InitializeComponent();
            this.Text = "Add Daily Task";
            this.Width = 400;
            this.Height = 450;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            var lblStaff = new Label { Text = "Staff", AutoSize = true };
            var cmbStaff = new ComboBox { Width = 200, DropDownStyle = ComboBoxStyle.DropDown };
            cmbStaff.Items.AddRange(staffNames.ToArray());

            var lblNote = new Label { Text = "Note", AutoSize = true };
            var txtNote = new TextBox { Width = 300, Height = 60, Multiline = true };

            var lblStatus = new Label { Text = "Status", AutoSize = true };
            var cmbStatus = new ComboBox { Width = 150, DropDownStyle = ComboBoxStyle.DropDownList };
            cmbStatus.Items.AddRange(new[] { "In Progress", "Finished", "Transfer" });
            cmbStatus.SelectedIndex = 0;

            var lblDate = new Label { Text = "Date", AutoSize = true };
            var dtpDate = new DateTimePicker { Width = 200 };

            var lblTransferDate = new Label { Text = "Transfer Date", AutoSize = true };
            var dtpTransferDate = new DateTimePicker { Width = 200, Enabled = false };

            cmbStatus.SelectedIndexChanged += (s, e) =>
            {
                dtpTransferDate.Enabled = cmbStatus.SelectedItem?.ToString() == "Transfer";
            };

            var btnSave = new Button { Text = "Save", Width = 120,Height = 30};
            btnSave.Click += (s, e) =>
            {
                if (cmbStatus.Text == "Transfer" && !dtpTransferDate.Enabled)
                {
                    MessageBox.Show("TransferDate is required for Transfer status.");
                    return;
                }

                NewTask = new DailyTask
                {
                    StaffName = cmbStaff.Text,
                    Note = txtNote.Text,
                    Status = cmbStatus.Text,
                    Date = dtpDate.Value.Date,
                    TransferDate = dtpTransferDate.Enabled ? dtpTransferDate.Value.Date : null,
                    CreatedAt = DateTime.Now
                };

                this.DialogResult = DialogResult.OK;
                this.Close();
            };

            var panel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.TopDown,
                AutoScroll = true,
                WrapContents = false
            };

            panel.Controls.AddRange(new Control[]
            {
                lblStaff, cmbStaff,
                lblNote, txtNote,
                lblStatus, cmbStatus,
                lblDate, dtpDate,
                lblTransferDate, dtpTransferDate,
                btnSave
            });

            this.Controls.Add(panel);
        }
    }
}

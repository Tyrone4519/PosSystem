﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Models;
using ChinatownMobilePos.Data;
using Microsoft.EntityFrameworkCore;
using ClosedXML.Excel;

namespace ChinatownMobilePos.Forms
{
    public partial class RepairForm : Form
    {
        private readonly AppDbContext _context;
        private ComboBox cmbRepairer, cmbSupplier, cmbFilterStaff;
        private DateTimePicker datePicker, dateFilterPicker;
        private TextBox txtDevice, txtPartsUsed, txtLaborCost, txtSalePrice, txtNote;
        private CheckBox chkIsPickedUp, chkIsPaid;
        private Button btnAdd, btnUpdate, btnDelete, btnExport, btnFilter;
        private DataGridView dgv;
        private BindingList<RepairRecord> repairList = new();
        private bool isFiltering = false;

        public RepairForm()
        {
            InitializeComponent();
            _context = new AppDbContext();
            SetupLayout();
            LoadRepairs();
        }

        private void SetupLayout()
        {
            this.BackColor = Color.FromArgb(245, 239, 220); // Unified background
            var offsetPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(200, 80, 40, 40) };
            this.Controls.Add(offsetPanel);

            var mainLayout = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 2 };
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 400));
            mainLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
            offsetPanel.Controls.Add(mainLayout);

            var leftPanel = new TableLayoutPanel { RowCount = 1, ColumnCount = 2, AutoSize = true, Dock = DockStyle.Top };
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 130));
            leftPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            var buttonPanel = new FlowLayoutPanel { FlowDirection = FlowDirection.LeftToRight, AutoSize = true };

            Font btnFont = new Font("Segoe UI", 9F, FontStyle.Bold);
            Color btnColor = Color.DarkGoldenrod;
            Color textColor = Color.White;

            btnAdd = new Button { Text = "Add", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnUpdate = new Button { Text = "Update", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnDelete = new Button { Text = "Delete", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };
            btnExport = new Button { Text = "Export", Width = 100, Height = 35, BackColor = btnColor, ForeColor = textColor, Font = btnFont };

            btnAdd.Click += BtnAdd_Click;
            btnUpdate.Click += BtnUpdate_Click;
            btnDelete.Click += BtnDelete_Click;
            btnExport.Click += BtnExport_Click;

            buttonPanel.Controls.AddRange(new[] { btnAdd, btnUpdate, btnDelete, btnExport });
            leftPanel.Controls.Add(buttonPanel);
            leftPanel.SetColumnSpan(buttonPanel, 2);
            leftPanel.RowCount++;

            cmbRepairer = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbRepairer.Items.AddRange(_context.Staffs.Select(s => s.StaffName).ToArray());

            datePicker = new DateTimePicker { Format = DateTimePickerFormat.Short };
            txtDevice = new TextBox();

            var deviceNames = _context.Devices.Select(d => d.Name).Where(name => !string.IsNullOrEmpty(name)).Distinct().ToArray();
            var autoCompleteSource = new AutoCompleteStringCollection();
            autoCompleteSource.AddRange(deviceNames);

            txtDevice.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            txtDevice.AutoCompleteSource = AutoCompleteSource.CustomSource;
            txtDevice.AutoCompleteCustomSource = autoCompleteSource;

            txtPartsUsed = new TextBox();
            cmbSupplier = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbSupplier.Items.AddRange(_context.Suppliers.Select(s => s.Name).ToArray());
            txtLaborCost = new TextBox();
            txtSalePrice = new TextBox();
            chkIsPickedUp = new CheckBox { Text = "Is Picked Up" };
            chkIsPaid = new CheckBox { Text = "Is Paid" };
            txtNote = new TextBox();

            void AddRow(string label, Control ctrl)
            {
                ctrl.Dock = DockStyle.Fill;
                ctrl.Margin = new Padding(3, 5, 3, 5);
                leftPanel.Controls.Add(new Label { Text = label, TextAlign = ContentAlignment.MiddleRight, Dock = DockStyle.Fill }, 0, leftPanel.RowCount - 1);
                leftPanel.Controls.Add(ctrl, 1, leftPanel.RowCount - 1);
                leftPanel.RowCount++;
            }

            AddRow("Repairer:", cmbRepairer);
            AddRow("Date:", datePicker);
            AddRow("Device:", txtDevice);
            AddRow("Parts Used:", txtPartsUsed);
            AddRow("Supplier:", cmbSupplier);
            AddRow("Labor Cost:", txtLaborCost);
            AddRow("Sale Price:", txtSalePrice);
            AddRow("", chkIsPickedUp);
            AddRow("", chkIsPaid);
            AddRow("Note:", txtNote);

            cmbFilterStaff = new ComboBox { DropDownStyle = ComboBoxStyle.DropDownList };
            cmbFilterStaff.Items.Add("All");
            cmbFilterStaff.Items.AddRange(_context.Staffs.Select(s => s.StaffName).ToArray());
            cmbFilterStaff.SelectedIndex = 0;

            dateFilterPicker = new DateTimePicker { Format = DateTimePickerFormat.Short, ShowCheckBox = true };
            btnFilter = new Button
            {
                Text = "Filter",
                Height = 40,
                BackColor = btnColor,
                ForeColor = textColor,
                Font = btnFont
            };
            btnFilter.Click += (s, e) => { isFiltering = true; LoadRepairs(); };

            AddRow("Filter Staff:", cmbFilterStaff);
            AddRow("Filter Date:", dateFilterPicker);
            leftPanel.Controls.Add(btnFilter);
            leftPanel.SetColumnSpan(btnFilter, 2);
            leftPanel.RowCount++;

            mainLayout.Controls.Add(leftPanel, 0, 0);

            dgv = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AllowUserToAddRows = false,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill
            };
            dgv.AutoGenerateColumns = true;
            dgv.CellClick += Dgv_CellClick;

            mainLayout.Controls.Add(dgv, 1, 0);
        }

        private void LoadRepairs()
        {
            var query = _context.RepairRecords.AsQueryable();

            if (isFiltering)
            {
                if (cmbFilterStaff.SelectedItem?.ToString() != "All")
                    query = query.Where(r => r.RepairerName == cmbFilterStaff.SelectedItem.ToString());

                if (dateFilterPicker.Checked)
                    query = query.Where(r => r.Date.Date == dateFilterPicker.Value.Date);
            }

            repairList = new BindingList<RepairRecord>(query.OrderByDescending(r => r.Date).ToList());
            dgv.DataSource = repairList;
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            var record = new RepairRecord
            {
                RepairerName = cmbRepairer.SelectedItem?.ToString(),
                Date = datePicker.Value.Date,
                Device = txtDevice.Text.Trim(),
                PartsUsed = txtPartsUsed.Text.Trim(),
                Supplier = cmbSupplier.SelectedItem?.ToString(),
                LaborCost = double.TryParse(txtLaborCost.Text, out double lc) ? lc : 0,
                SalePrice = double.TryParse(txtSalePrice.Text, out double sp) ? sp : 0,
                IsPickedUp = chkIsPickedUp.Checked,
                IsPaid = chkIsPaid.Checked,
                Note = txtNote.Text.Trim()
            };

            _context.RepairRecords.Add(record);
            _context.SaveChanges();
            isFiltering = false;
            LoadRepairs();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;

            var selected = (RepairRecord)dgv.SelectedRows[0].DataBoundItem;
            var record = _context.RepairRecords.Find(selected.Id);
            if (record == null) return;

            record.RepairerName = cmbRepairer.SelectedItem?.ToString();
            record.Date = datePicker.Value.Date;
            record.Device = txtDevice.Text.Trim();
            record.PartsUsed = txtPartsUsed.Text.Trim();
            record.Supplier = cmbSupplier.SelectedItem?.ToString();
            record.LaborCost = double.TryParse(txtLaborCost.Text, out double lc) ? lc : 0;
            record.SalePrice = double.TryParse(txtSalePrice.Text, out double sp) ? sp : 0;
            record.IsPickedUp = chkIsPickedUp.Checked;
            record.IsPaid = chkIsPaid.Checked;
            record.Note = txtNote.Text.Trim();

            _context.SaveChanges();
            isFiltering = false;
            LoadRepairs();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (dgv.SelectedRows.Count == 0) return;
            var selected = (RepairRecord)dgv.SelectedRows[0].DataBoundItem;
            var record = _context.RepairRecords.Find(selected.Id);
            if (record == null) return;

            _context.RepairRecords.Remove(record);
            _context.SaveChanges();
            isFiltering = false;
            LoadRepairs();
        }

        private void BtnExport_Click(object sender, EventArgs e)
        {
            using var workbook = new XLWorkbook();
            var ws = workbook.Worksheets.Add("Repairs");
            ws.Cell(1, 1).InsertTable(repairList);
            using var dlg = new SaveFileDialog { Filter = "Excel Workbook|*.xlsx" };
            if (dlg.ShowDialog() == DialogResult.OK)
                workbook.SaveAs(dlg.FileName);
        }

        private void Dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0) return;
            var selected = (RepairRecord)dgv.Rows[e.RowIndex].DataBoundItem;

            cmbRepairer.SelectedItem = selected.RepairerName;
            datePicker.Value = selected.Date;
            txtDevice.Text = selected.Device;
            txtPartsUsed.Text = selected.PartsUsed;
            cmbSupplier.SelectedItem = selected.Supplier;
            txtLaborCost.Text = selected.LaborCost.ToString("0.##");
            txtSalePrice.Text = selected.SalePrice.ToString("0.##");
            chkIsPickedUp.Checked = selected.IsPickedUp;
            chkIsPaid.Checked = selected.IsPaid;
            txtNote.Text = selected.Note;
        }
    }
}




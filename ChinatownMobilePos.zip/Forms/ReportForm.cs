﻿using System;
using System.Windows.Forms;

namespace ChinatownMobilePos.Forms
{
    public partial class ReportForm : Form
    {
        public ReportForm()
        {
            InitializeComponent();
        }
    }
}

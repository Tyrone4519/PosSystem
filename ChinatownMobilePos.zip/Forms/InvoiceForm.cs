﻿// InvoiceForm.cs

using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;

namespace ChinatownMobilePos.Forms
{
    public partial class InvoiceForm : Form
    {
        private TextBox txtCustomerName;
        private TextBox txtInvoiceNo;
        private DateTimePicker dtpDate;
        private TextBox txtAddress;
        private TextBox txtPhone;
        private TextBox txtEmail;

        private DataGridView dgvItems;
        private Label lblSubtotal;
        private Label lblGstTotal;
        private Label lblGrandTotal;
        private Button btnAddRow;
        private Button btnSave;
        private Button btnPrint;
        private Button btnCancel;
        private Button btnHistory;

        private readonly AppDbContext db;
        private PrintDocument printDocument;
        private Invoice currentInvoice;

        public InvoiceForm()
        {
            db = DbContextHelper.GetContext();
            InitializeComponent();
            InitializeLayout();
            currentInvoice = new Invoice();
        }

        private void InitializeLayout()
        {
            this.Text = "Invoice";
            this.BackColor = Color.FromArgb(245, 239, 220);
            this.Padding = new Padding(200, 80, 40, 40);
            this.Dock = DockStyle.Fill;
            this.FormBorderStyle = FormBorderStyle.None;

            System.Globalization.CultureInfo.DefaultThreadCurrentCulture = new System.Globalization.CultureInfo("en-US");
            System.Globalization.CultureInfo.DefaultThreadCurrentUICulture = new System.Globalization.CultureInfo("en-US");

            var mainPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10),
                ColumnCount = 1,
                RowCount = 3
            };
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
            this.Controls.Add(mainPanel);

            var headerPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                ColumnCount = 6,
                RowCount = 2,
                AutoSize = true
            };
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.AutoSize));
            headerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));

            txtCustomerName = new TextBox { Font = new Font("Segoe UI", 10), Width = 300 };
            txtInvoiceNo = new TextBox { Font = new Font("Segoe UI", 10), Width = 250 };
            dtpDate = new DateTimePicker { Format = DateTimePickerFormat.Short, Font = new Font("Segoe UI", 10), Width = 150 };
            txtAddress = new TextBox { Font = new Font("Segoe UI", 10), Width = 400 };
            txtPhone = new TextBox { Font = new Font("Segoe UI", 10), Width = 250 };
            txtEmail = new TextBox { Font = new Font("Segoe UI", 10), Width = 300 };

            headerPanel.Controls.Add(new Label { Text = "Invoiced To:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 0, 0);
            headerPanel.Controls.Add(txtCustomerName, 1, 0);
            headerPanel.Controls.Add(new Label { Text = "Invoice No:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 2, 0);
            headerPanel.Controls.Add(txtInvoiceNo, 3, 0);
            headerPanel.Controls.Add(new Label { Text = "Date:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 4, 0);
            headerPanel.Controls.Add(dtpDate, 5, 0);

            headerPanel.Controls.Add(new Label { Text = "Address:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 0, 1);
            headerPanel.Controls.Add(txtAddress, 1, 1);
            headerPanel.Controls.Add(new Label { Text = "Phone:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 2, 1);
            headerPanel.Controls.Add(txtPhone, 3, 1);
            headerPanel.Controls.Add(new Label { Text = "Email:", Font = new Font("Segoe UI", 10, FontStyle.Bold), AutoSize = true }, 4, 1);
            headerPanel.Controls.Add(txtEmail, 5, 1);

            mainPanel.Controls.Add(headerPanel);

            dgvItems = new DataGridView
            {
                Dock = DockStyle.Fill,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None,
                BackgroundColor = Color.White,
                ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
                {
                    BackColor = Color.Maroon,
                    ForeColor = Color.White,
                    Font = new Font("Segoe UI", 10, FontStyle.Bold),
                    Alignment = DataGridViewContentAlignment.MiddleCenter
                },
                EnableHeadersVisualStyles = false,
                Font = new Font("Segoe UI", 10),
                AllowUserToAddRows = true
            };
            dgvItems.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Item", Width = 900, Name = "Description" });
            dgvItems.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Qty", Width = 150, Name = "Quantity" });
            dgvItems.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Price", Width = 150, Name = "UnitPrice", DefaultCellStyle = new DataGridViewCellStyle { Format = "C2", FormatProvider = System.Globalization.CultureInfo.GetCultureInfo("en-US") } });
            dgvItems.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "GST", Width = 150, Name = "GST", DefaultCellStyle = new DataGridViewCellStyle { Format = "C2", FormatProvider = System.Globalization.CultureInfo.GetCultureInfo("en-US") } });
            dgvItems.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Total (Inc. GST)",
                Width = 250,
                Name = "Total",
                ReadOnly = false,
                DefaultCellStyle = new DataGridViewCellStyle
                {
                    Format = "C2",
                    FormatProvider = System.Globalization.CultureInfo.GetCultureInfo("en-US")
                }
            });


            dgvItems.CellValueChanged += DgvItems_CellValueChanged;
            dgvItems.EditingControlShowing += DgvItems_EditingControlShowing;

            mainPanel.Controls.Add(dgvItems);

            var footerPanel = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                Padding = new Padding(10)
            };
            footerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40));
            footerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            footerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
            footerPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));

            var buttonPanel = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight
            };

            btnAddRow = new Button { Text = "Add Row", Width = 120, Height = 40, Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.DarkOliveGreen, ForeColor = Color.White };
            btnSave = new Button { Text = "Save", Width = 120, Height = 40, Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.Teal, ForeColor = Color.White };
            btnPrint = new Button { Text = "Print", Width = 120, Height = 40, Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.SteelBlue, ForeColor = Color.White };
            btnCancel = new Button { Text = "Cancel", Width = 120, Height = 40, Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.Gray, ForeColor = Color.White };
            btnHistory = new Button { Text = "History", Width = 120, Height = 40, Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.DarkOrange, ForeColor = Color.White };

            btnAddRow.Click += (s, e) => dgvItems.Rows.Add();
            btnSave.Click += (s, e) => { SaveInvoice(); ShowInvoiceHistory(); };
            btnPrint.Click += (s, e) => PrintInvoice();
            btnCancel.Click += (s, e) => ResetForm();
            btnHistory.Click += (s, e) => ShowInvoiceHistory();

            buttonPanel.Controls.AddRange(new Control[] { btnAddRow, btnSave, btnPrint, btnCancel, btnHistory });

            footerPanel.Controls.Add(buttonPanel, 0, 0);

            lblSubtotal = new Label
            {
                Text = "Subtotal: $0.00",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            lblGstTotal = new Label
            {
                Text = "GST Total: $0.00",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };
            lblGrandTotal = new Label
            {
                Text = "Total: $0.00",
                Dock = DockStyle.Fill,
                TextAlign = ContentAlignment.MiddleRight,
                Font = new Font("Segoe UI", 10, FontStyle.Bold)
            };

            footerPanel.Controls.Add(lblSubtotal, 1, 0);
            footerPanel.Controls.Add(lblGstTotal, 2, 0);
            footerPanel.Controls.Add(lblGrandTotal, 3, 0);

            mainPanel.Controls.Add(footerPanel);
        }




        private void DgvItems_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex < 0 || e.ColumnIndex != 4) return;

            var row = dgvItems.Rows[e.RowIndex];

            if (decimal.TryParse(Convert.ToString(row.Cells[4].Value), out var total))
            {
                var gst = Math.Round(total / 11, 2);
                var price = Math.Round(total - gst, 2);

                row.Cells[2].Value = price;
                row.Cells[3].Value = gst;
            }

            RecalculateTotals();
        }

        private void DgvItems_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            e.Control.TextChanged += (s, args) => RecalculateTotals();
        }

        private void RecalculateTotals()
        {
            decimal subtotal = 0, gst = 0, total = 0;

            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.IsNewRow) continue;

                decimal.TryParse(Convert.ToString(row.Cells[2].Value), out var price);
                decimal.TryParse(Convert.ToString(row.Cells[3].Value), out var gstVal);
                decimal.TryParse(Convert.ToString(row.Cells[4].Value), out var totalVal);

                subtotal += price;
                gst += gstVal;
                total += totalVal;
            }

            lblSubtotal.Text = $"Subtotal: {subtotal:C}";
            lblGstTotal.Text = $"GST Total: {gst:C}";
            lblGrandTotal.Text = $"Total: {total:C}";
        }

        private void SaveInvoice()
        {
            if (string.IsNullOrWhiteSpace(txtInvoiceNo.Text) || string.IsNullOrWhiteSpace(txtCustomerName.Text))
            {
                MessageBox.Show("Please fill in Invoice No and Customer Name.");
                return;
            }

            currentInvoice.InvoiceNo = txtInvoiceNo.Text.Trim();
            currentInvoice.CustomerName = txtCustomerName.Text.Trim();
            currentInvoice.Date = dtpDate.Value.Date;
            currentInvoice.Items.Clear();

            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.IsNewRow) continue;

                var item = new InvoiceItem
                {
                    Description = row.Cells[0].Value?.ToString(),
                    Quantity = int.TryParse(Convert.ToString(row.Cells[1].Value), out var qty) ? qty : 0,
                    UnitPrice = decimal.TryParse(Convert.ToString(row.Cells[2].Value), out var price) ? price : 0,
                    InvoiceNo = currentInvoice.InvoiceNo
                };

                currentInvoice.Items.Add(item);
            }

            currentInvoice.Subtotal = currentInvoice.Items.Sum(i => i.Total);
            currentInvoice.GSTTotal = currentInvoice.Subtotal * 0.1m;
            currentInvoice.GrandTotal = currentInvoice.Subtotal + currentInvoice.GSTTotal;

            db.Invoices.Add(currentInvoice);
            db.SaveChanges();

            RecalculateTotals();

            MessageBox.Show("Invoice saved successfully.");
        }

        private void ResetForm()
        {
            txtInvoiceNo.Clear();
            txtCustomerName.Clear();
            txtAddress.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
            dtpDate.Value = DateTime.Today;
            dgvItems.Rows.Clear();
        }

        private void PrintInvoice()
        {
            printDocument = new PrintDocument
            {
                PrinterSettings = { PrinterName = "EPSON TM-T88V Receipt" },
                DefaultPageSettings =
                {
                    PaperSize = new PaperSize("Receipt", 280, 1000),
                    Margins = new Margins(5, 5, 5, 5)
                }
            };

            printDocument.PrintPage += PrintDocument_PrintPage;

            try
            {
                printDocument.Print();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Print Failed：" + ex.Message);
            }
        }

        private void PrintDocument_PrintPage(object sender, PrintPageEventArgs e)
        {
            float y = 10;
            float left = 10;
            float lineHeight = 18;
            Font titleFont = new Font("Consolas", 11, FontStyle.Bold);
            Font boldFont = new Font("Consolas", 9, FontStyle.Bold);
            Font textFont = new Font("Consolas", 9);
            Font smallFont = new Font("Consolas", 8);
            Brush brush = Brushes.Black;

            e.Graphics.DrawString("Chinatown Mobile", titleFont, brush, left + 50, y); y += lineHeight;
            e.Graphics.DrawString("ABN: 17 615 390 068", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("60 Dixon St, Sydney NSW 2000", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("(02) 9281 8808", textFont, brush, left, y); y += lineHeight * 2;

            e.Graphics.DrawString("TAX INVOICE", boldFont, brush, left + 60, y); y += lineHeight;
            e.Graphics.DrawLine(Pens.Black, left, y, left + 250, y); y += 5;

            e.Graphics.DrawString($"Name:     {txtCustomerName.Text}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString($"Address:  {txtAddress.Text}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString($"Phone:    {txtPhone.Text}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString($"Email:    {txtEmail.Text}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString($"Invoice #: {txtInvoiceNo.Text}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString($"Date:     {dtpDate.Value:dd/MM/yyyy}", textFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawLine(Pens.Black, left, y, left + 250, y); y += 5;

            e.Graphics.DrawString("Item", boldFont, brush, left, y);
            e.Graphics.DrawString("Qty", boldFont, brush, left + 220, y); y += lineHeight;

            int totalQty = 0;
            decimal subtotal = 0, gstTotal = 0;

            foreach (DataGridViewRow row in dgvItems.Rows)
            {
                if (row.IsNewRow) continue;

                string desc = (row.Cells[0].Value?.ToString() ?? "");
                int qty = int.TryParse(Convert.ToString(row.Cells[1].Value), out qty) ? qty : 0;
                decimal price = decimal.TryParse(Convert.ToString(row.Cells[2].Value), out price) ? price : 0;
                decimal gst = decimal.TryParse(Convert.ToString(row.Cells[3].Value), out gst) ? gst : 0;

                totalQty += qty;
                subtotal += price;
                gstTotal += gst;

                e.Graphics.DrawString(desc, textFont, brush, left, y);
                var formatRight = new StringFormat { Alignment = StringAlignment.Far };
                Rectangle qtyRect = new Rectangle((int)(left + 200), (int)y, 40, (int)lineHeight);
                e.Graphics.DrawString(qty.ToString(), textFont, brush, qtyRect, formatRight);

                y += lineHeight;
            }

            decimal grandTotal = subtotal + gstTotal;
            y += 5;
            e.Graphics.DrawLine(Pens.Black, left, y, left + 250, y); y += lineHeight;

            e.Graphics.DrawString("Total:", boldFont, brush, left, y);
            Rectangle totalBox = new Rectangle((int)(left + 160), (int)y, 80, (int)lineHeight);
            e.Graphics.DrawString($"${grandTotal:0.00}", boldFont, brush, totalBox, new StringFormat { Alignment = StringAlignment.Far });
            y += lineHeight;

            e.Graphics.DrawString("GST Included in Total:", smallFont, brush, left, y);
            Rectangle gstBox = new Rectangle((int)(left + 160), (int)y, 80, (int)lineHeight);
            e.Graphics.DrawString($"${gstTotal:0.00}", smallFont, brush, gstBox, new StringFormat { Alignment = StringAlignment.Far });
            y += lineHeight;

            e.Graphics.DrawLine(Pens.Black, left, y, left + 250, y); y += lineHeight;
            e.Graphics.DrawString("Please arrange payment to the following:", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("Chinatown Mobile", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("BSB : 062006", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("Account Number: 12720793", smallFont, brush, left, y); y += lineHeight;

            y += 10;
            e.Graphics.DrawString("Terms & Conditions:", boldFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("We do not accept refund or exchange", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("if you simply change your mind.", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("Exchange only with proof of purchase.", smallFont, brush, left, y); y += lineHeight;
            e.Graphics.DrawString("12 months warranty from purchase date.", smallFont, brush, left, y);
        }

        private void ShowInvoiceHistory()
        {
            var historyForm = new Form
            {
                Text = "Invoice History",
                Size = new Size(800, 400),
                StartPosition = FormStartPosition.CenterParent
            };

            var dgvHistory = new DataGridView
            {
                Dock = DockStyle.Fill,
                ReadOnly = true,
                AutoGenerateColumns = false,
                AllowUserToAddRows = false,
                DataSource = db.Invoices
                    .OrderByDescending(i => i.Date)
                    .Select(i => new
                    {
                        i.InvoiceNo,
                        i.CustomerName,
                        i.Date,
                        i.GrandTotal
                    })
                    .ToList()
            };

            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Invoice No", DataPropertyName = "InvoiceNo", Width = 150 });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Customer", DataPropertyName = "CustomerName", Width = 200 });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Date", DataPropertyName = "Date", Width = 150 });
            dgvHistory.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Total", DataPropertyName = "GrandTotal", Width = 150 });

            dgvHistory.CellDoubleClick += (s, e) =>
            {
                if (e.RowIndex >= 0)
                {
                    var selectedInvoiceNo = dgvHistory.Rows[e.RowIndex].Cells[0].Value?.ToString();
                    var invoice = db.Invoices.FirstOrDefault(inv => inv.InvoiceNo == selectedInvoiceNo);
                    if (invoice != null)
                    {
                        MessageBox.Show($"Invoice #: {invoice.InvoiceNo}\nCustomer: {invoice.CustomerName}\nDate: {invoice.Date:yyyy-MM-dd}\nTotal: {invoice.GrandTotal:C}", "Invoice Detail");
                    }
                }
            };

            historyForm.Controls.Add(dgvHistory);
            historyForm.ShowDialog();
        }

    }
}

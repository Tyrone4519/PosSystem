﻿using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ChinatownMobilePos.Forms
{
    public partial class ProductDescriptionForm : Form
    {
        private readonly AppDbContext db;
        private ComboBox cmbProduct;
        private TextBox txtDescription;
        private Button btnAdd, btnUpdate, btnDelete;
        private ListBox listBox;

        public ProductDescriptionForm()
        {
            db = DbContextHelper.GetContext();
            this.Text = "Product Descriptions";
            this.Size = new Size(1000, 800);
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeLayout();
            LoadProducts();
        }

        private void InitializeLayout()
        {
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                RowCount = 3,
                ColumnCount = 1
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 130));
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60));

            // === ListBox ===
            listBox = new ListBox
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 10F)
            };
            listBox.SelectedIndexChanged += ListBox_SelectedIndexChanged;
            mainLayout.Controls.Add(listBox, 0, 0);

            // === Input Panel ===
            var inputLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                RowCount = 2,
                ColumnCount = 2,
                Padding = new Padding(0, 10, 0, 10)
            };

            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            // Product Dropdown
            inputLayout.Controls.Add(new Label { Text = "Product:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            cmbProduct = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList,
                Font = new Font("Segoe UI", 10F)
            };
            cmbProduct.SelectedIndexChanged += (s, e) => LoadDescriptions();
            inputLayout.Controls.Add(cmbProduct, 1, 0);

            // Description input
            inputLayout.Controls.Add(new Label { Text = "DESC:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            txtDescription = new TextBox { Dock = DockStyle.Fill, Font = new Font("Segoe UI", 10F) };
            inputLayout.Controls.Add(txtDescription, 1, 1);

            mainLayout.Controls.Add(inputLayout, 0, 1);

            // === Buttons ===
            var buttonLayout = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                FlowDirection = FlowDirection.LeftToRight
            };

            btnAdd = new Button
            {
                Text = "Add",
                Width = 90,
                Height = 40,
                BackColor = Color.SeaGreen,
                ForeColor = Color.White
            };
            btnAdd.Click += BtnAdd_Click;
            buttonLayout.Controls.Add(btnAdd);

            btnUpdate = new Button
            {
                Text = "Update",
                Width = 90,
                Height = 40,
                BackColor = Color.DodgerBlue,
                ForeColor = Color.White
            };
            btnUpdate.Click += BtnUpdate_Click;
            buttonLayout.Controls.Add(btnUpdate);

            btnDelete = new Button
            {
                Text = "Delete",
                Width = 90,
                Height = 40,
                BackColor = Color.IndianRed,
                ForeColor = Color.White
            };
            btnDelete.Click += BtnDelete_Click;
            buttonLayout.Controls.Add(btnDelete);

            mainLayout.Controls.Add(buttonLayout, 0, 2);

            this.Controls.Add(mainLayout);
        }

        private void LoadProducts()
        {
            var products = db.Products
                .OrderBy(p => p.Name)
                .ToList();

            cmbProduct.DataSource = products;
            cmbProduct.DisplayMember = "Name";
            cmbProduct.ValueMember = "Id";

            if (cmbProduct.Items.Count > 0)
                cmbProduct.SelectedIndex = 0;
        }

        private void LoadDescriptions()
        {
            listBox.DataSource = null;

            if (cmbProduct.SelectedItem is not Product selectedProduct)
                return;

            var descs = db.ProductDescriptions
                .Where(d => d.ProductId == selectedProduct.Id)
                .OrderBy(d => d.DescriptionText)
                .ToList();

            if (descs.Any())
            {
                listBox.DataSource = descs;
                listBox.DisplayMember = "DescriptionText";
                listBox.ValueMember = "Id";
            }

            txtDescription.Clear();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            if (cmbProduct.SelectedItem is not Product product || string.IsNullOrWhiteSpace(txtDescription.Text))
            {
                MessageBox.Show("Please select a product and enter a description.");
                return;
            }

            string desc = txtDescription.Text.Trim();

            if (db.ProductDescriptions.Any(d => d.ProductId == product.Id && d.DescriptionText == desc))
            {
                MessageBox.Show("This description already exists for this product.");
                return;
            }

            db.ProductDescriptions.Add(new ProductDescription
            {
                ProductId = product.Id,
                DescriptionText = desc
            });

            db.SaveChanges();
            LoadDescriptions();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is not ProductDescription selected ||
                cmbProduct.SelectedItem is not Product product)
            {
                MessageBox.Show("Please select a description to update.");
                return;
            }

            string newDesc = txtDescription.Text.Trim();

            if (string.IsNullOrWhiteSpace(newDesc))
            {
                MessageBox.Show("Please enter a description.");
                return;
            }

            if (db.ProductDescriptions.Any(d =>
                d.ProductId == product.Id &&
                d.DescriptionText == newDesc &&
                d.Id != selected.Id))
            {
                MessageBox.Show("Another description with the same text already exists.");
                return;
            }

            selected.ProductId = product.Id;
            selected.DescriptionText = newDesc;

            db.ProductDescriptions.Update(selected);
            db.SaveChanges();
            LoadDescriptions();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is ProductDescription selected)
            {
                db.ProductDescriptions.Remove(selected);
                db.SaveChanges();
                LoadDescriptions();
            }
        }

        private void ListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox.SelectedItem is ProductDescription selected)
            {
                txtDescription.Text = selected.DescriptionText;
                cmbProduct.SelectedValue = selected.ProductId;
            }
        }
    }
}

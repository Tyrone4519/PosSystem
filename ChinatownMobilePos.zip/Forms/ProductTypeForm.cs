﻿using ChinatownMobilePos.Data;
using ChinatownMobilePos.Models;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ChinatownMobilePos.Forms
{
    public partial class ProductTypeForm : Form
    {
        private readonly AppDbContext db;
        private Dictionary<string, ListBox> categoryListBoxes = new();
        private TextBox txtName;
        private ComboBox cmbSaleType;
        private Button btnAdd;
        private Button btnDelete;
        private Button btnUpdate;

        private readonly string[] saleTypeOptions = new[]
        {
            "Simcard", "Recharge", "Accessories", "Handset", "Repair", "Other"
        };

        public ProductTypeForm()
        {
            db = DbContextHelper.GetContext();
            this.Text = "Product Types";
            this.Size = new Size(1500, 1000);
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeLayout();
            LoadProductTypes();
        }

        private void InitializeLayout()
        {
            var mainLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(20),
                RowCount = 3,
                ColumnCount = 1
            };
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 100)); // top section for list
            mainLayout.RowStyles.Add(new RowStyle(SizeType.AutoSize));     // middle for input
            mainLayout.RowStyles.Add(new RowStyle(SizeType.Absolute, 60)); // bottom for buttons

            // === Category Grid (6 Columns) ===
            var categoryGrid = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 6,
                RowCount = 1,
                AutoSize = false
            };

            for (int i = 0; i < 6; i++)
                categoryGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f / 6));

            foreach (string saleType in saleTypeOptions)
            {
                var groupBox = new GroupBox
                {
                    Text = saleType,
                    Dock = DockStyle.Fill,
                    Font = new Font("Segoe UI", 10F, FontStyle.Bold)
                };

                var list = new ListBox
                {
                    Dock = DockStyle.Fill,
                    Tag = saleType,
                    Font = new Font("Segoe UI", 10F)
                };
                list.SelectedIndexChanged += OnListBoxSelected;

                groupBox.Controls.Add(list);
                categoryListBoxes[saleType] = list;
                categoryGrid.Controls.Add(groupBox);
            }

            mainLayout.Controls.Add(categoryGrid);

            // === Input Panel ===
            var inputLayout = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 2,
                RowCount = 2,
                Padding = new Padding(0, 10, 0, 10),
                Height = 90
            };

            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
            inputLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

            inputLayout.Controls.Add(new Label { Text = "Name:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 0);
            txtName = new TextBox { Dock = DockStyle.Fill };
            inputLayout.Controls.Add(txtName, 1, 0);

            inputLayout.Controls.Add(new Label { Text = "Sale Type:", TextAlign = ContentAlignment.MiddleLeft, Dock = DockStyle.Fill }, 0, 1);
            cmbSaleType = new ComboBox
            {
                Dock = DockStyle.Fill,
                DropDownStyle = ComboBoxStyle.DropDownList
            };
            cmbSaleType.Items.AddRange(saleTypeOptions);
            inputLayout.Controls.Add(cmbSaleType, 1, 1);

            mainLayout.Controls.Add(inputLayout);

            // === Button Panel ===
            var buttonPanel = new FlowLayoutPanel
            {
                FlowDirection = FlowDirection.LeftToRight,
                Dock = DockStyle.Fill,
                Padding = new Padding(0, 5, 0, 5),
                Height = 50
            };

            btnAdd = new Button
            {
                Text = "Add",
                Width = 90,
                Height = 40,
                BackColor = Color.SeaGreen,
                ForeColor = Color.White
            };
            btnAdd.Click += AddProductType;
            buttonPanel.Controls.Add(btnAdd);

            btnUpdate = new Button
            {
                Text = "Update",
                Width = 90,
                Height = 40,
                BackColor = Color.DodgerBlue,
                ForeColor = Color.White
            };
            btnUpdate.Click += UpdateProductType;
            buttonPanel.Controls.Add(btnUpdate);

            btnDelete = new Button
            {
                Text = "Delete",
                Width = 90,
                Height = 40,
                BackColor = Color.IndianRed,
                ForeColor = Color.White
            };
            btnDelete.Click += DeleteProductType;
            buttonPanel.Controls.Add(btnDelete);

            mainLayout.Controls.Add(buttonPanel);

            this.Controls.Add(mainLayout);
        }


        private void LoadProductTypes()
        {
            foreach (var list in categoryListBoxes.Values)
                list.Items.Clear();

            var items = db.ProductTypes
                .OrderBy(p => p.SaleType)
                .ThenBy(p => p.Name)
                .ToList();

            foreach (var item in items)
            {
                if (categoryListBoxes.TryGetValue(item.SaleType, out var list))
                {
                    list.Items.Add(item.Name);
                }
            }

            txtName.Clear();
            cmbSaleType.SelectedIndex = -1;
        }

        private void AddProductType(object sender, EventArgs e)
        {
            var name = txtName.Text.Trim();
            var saleType = cmbSaleType.SelectedItem?.ToString();

            if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(saleType))
            {
                MessageBox.Show("Please enter a name and select Sale Type.");
                return;
            }

            if (db.ProductTypes.Any(p => p.Name == name && p.SaleType == saleType))
            {
                MessageBox.Show("This ProductType already exists.");
                return;
            }

            db.ProductTypes.Add(new ProductType { Name = name, SaleType = saleType });
            db.SaveChanges();
            LoadProductTypes();
        }

        private void DeleteProductType(object sender, EventArgs e)
        {
            foreach (var kvp in categoryListBoxes)
            {
                var saleType = kvp.Key;
                var listBox = kvp.Value;
                if (listBox.SelectedIndex >= 0)
                {
                    string name = listBox.SelectedItem.ToString();

                    var item = db.ProductTypes.FirstOrDefault(p => p.Name == name && p.SaleType == saleType);
                    if (item != null)
                    {
                        db.ProductTypes.Remove(item);
                        db.SaveChanges();
                        LoadProductTypes();
                    }
                    return;
                }
            }

            MessageBox.Show("Please select a ProductType to delete.");
        }

        private void UpdateProductType(object sender, EventArgs e)
        {
            string newName = txtName.Text.Trim();
            string newSaleType = cmbSaleType.SelectedItem?.ToString();

            if (string.IsNullOrWhiteSpace(newName) || string.IsNullOrWhiteSpace(newSaleType))
            {
                MessageBox.Show("Please enter new name and sale type.");
                return;
            }

            foreach (var kvp in categoryListBoxes)
            {
                var oldSaleType = kvp.Key;
                var listBox = kvp.Value;

                if (listBox.SelectedIndex >= 0)
                {
                    string oldName = listBox.SelectedItem.ToString();
                    var existing = db.ProductTypes.FirstOrDefault(p => p.Name == oldName && p.SaleType == oldSaleType);

                    if (existing != null)
                    {
                        if (db.ProductTypes.Any(p => p.Name == newName && p.SaleType == newSaleType && p.Id != existing.Id))
                        {
                            MessageBox.Show("Another item with same name and type already exists.");
                            return;
                        }

                        existing.Name = newName;
                        existing.SaleType = newSaleType;
                        db.SaveChanges();
                        LoadProductTypes();
                        return;
                    }
                }
            }

            MessageBox.Show("Please select an item to update.");
        }

        private void OnListBoxSelected(object sender, EventArgs e)
        {
            var listBox = sender as ListBox;
            if (listBox != null && listBox.SelectedItem != null)
            {
                txtName.Text = listBox.SelectedItem.ToString();
                cmbSaleType.SelectedItem = listBox.Tag.ToString();
            }
        }
    }
}
